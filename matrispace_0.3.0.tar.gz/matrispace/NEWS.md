# matrispace 0.3.0 (JoVE protocol release)

## Matrisome-pair terminology and data (ported from 0.1.x)

- Pair co-expression uses matrisome-pair names: `score_matrisome_pair_coexpression()`,
  `get_matrisome_pair_coexpression()`, `find_matrisome_pair_enrichment()` and
  `missing_matrisome_pairs()`. Pair tables use `gene_1`/`gene_2` columns; legacy
  `ligand`/`receptor` columns are still accepted. The score is unchanged:
  `gene_2` at a spot times weighted `gene_1` in its neighbours. It measures
  co-expression, not signalling direction.
- `score_lr_activity()`, `get_lr_activity()`, `find_lr_enrichment()` and
  `lr_missing_pairs()` are deprecated aliases.
- `lr_database` is replaced by `matrisome_pairs`: one alphabetically ordered row
  per unique heterotypic MatriComDB pair, with reciprocal records collapsed and
  homomeric records removed (16,348 pairs). Homomeric rows in user tables are
  dropped before scoring.
- The six category signatures exclude F8 and USH2A, matching the MatriSpace app;
  both genes remain in `matrisome_db` and the functional signatures.

## Figure plotting options

- `plot_sample_comparison()`: sample-level box plots by group with points,
  range whiskers and optional P-value brackets.
- `plot_spatial()` gains `colour_scale = "spectral"`, `title`, `legend_title`,
  and a `scale_bar`.
- `plot_heatmap()` gains `colours`, `legend_title`, `row_labels`,
  `column_labels`, `italic`, `x_angle` and `legend_position`;
  `palette_diverging()` gives the red-blue figure scale.

# matrispace 0.3.0 (spatial extensions)

Spatial analysis extensions on top of the 0.2.0 clean-architecture rewrite. All
0.2.0 contracts remain backward compatible.

## New features

- **Delaunay spatial graphs.** `build_spatial_graph(method = "delaunay")` builds
  the undirected Delaunay triangulation per image/partition block via
  `geometry::delaunayn` (Qhull, now an `Imports` dependency), with optional
  absolute `max_edge_distance` pruning of long edges. Duplicate, `< 3`-point, and
  collinear blocks are rejected with spot-named, actionable errors.
- **Distance-binned categorical co-occurrence.** `compute_cooccurrence()` reports
  the Squidpy-compatible ratio `P(to | from, distance) / P(to | distance)` in
  annular or cumulative distance bins in stored or explicitly scaled common
  coordinate units, with strict per-image isolation, the
  `pooled_pairs`/`equal_image` estimands, a bounded-memory chunked kernel, and an
  optional within-image label-permutation null (`n_perm > 0`) giving one-sided
  enrichment/depletion p-values (plus-one correction, BH over the defined
  family). `plot_cooccurrence()` renders the result as a pure consumer.
- **ECM spatial variability.** `find_spatially_variable_ecm()` is an optional
  adapter to **nnSVG** (a `Suggests`) for residual continuous spatial variation,
  with mandatory explicit assay, single-image semantics, custom/bundled feature
  selection, covariate designs, a stable status/provenance schema, and BH over
  successfully tested features. It is spatial variability, not group DE.
- **Discoverability.** `list_matrisome_signatures()`, `list_ecm_niches()`, and the
  bundled `matrisome_signature_manifest` catalog the bundled signatures/niches;
  `score_*`/`annotate_ecm_niches()` gained `include`/`niches` selectors, subset
  getters, and a definition+parameter overwrite guard.
- **Histology rendering.** `plot_spatial(image = TRUE, ...)` draws the histology
  raster underneath (per-image scale factor, `image_scale`, `image_alpha`,
  `crop`), composing multiple images with `patchwork`; coordinate-only remains
  the default.

## Changes

- Spatial maps now infer y orientation by technology (Visium/image coordinates
  are reversed; Seurat FOV/plain Cartesian coordinates are not) with an explicit
  `flip_y` override. Feature, blend, and LISA maps share image-aware point,
  palette, crop, facet, and legend controls; dense maps auto-size points.
- Heatmaps use conventional top-to-bottom row orientation, explicitly complete
  missing matrix cells, automatically center signed values at zero, and support
  row/column scaling. LISA/co-occurrence significance prefers adjusted p-values;
  dense co-occurrence plots require an explicit category selection.
- Blend plots use robust quantile scaling and an explanatory four-corner legend;
  dot plots offer within-feature scaling; violins offer optional box/jitter/n
  summaries without a redundant group legend.
- Grouped plots and neighborhood enrichment preserve natural factor/numeric
  category ordering; spatial/blend/LISA plots and heatmaps use a cleaner theme.
- Absent assay/layer errors now list the valid choices.
- The ECM-niche classification label column is `matrispace_ecm_niche_classification`.
- LR heatmaps prefer the readable `pair` label over `pair_id`.

## Non-goals

- No confirmatory spatially-corrected group differential-expression test:
  single-section data lacks the biological replication it requires.
  `compare_ecm_groups()` stays descriptive; `test_ecm_pseudobulk()` stays
  confirmatory for replicated designs.
