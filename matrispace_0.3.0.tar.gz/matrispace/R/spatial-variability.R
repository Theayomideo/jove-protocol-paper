# ECM spatial variability via nnSVG (SPATIAL_EXTENSIONS_IMPLEMENTATION_SPEC s5).
# This answers whether ECM features show residual CONTINUOUS spatial variation
# (a nearest-neighbor Gaussian process, gene-specific length scales, an LR
# statistic, and the prop_sv effect size). It is NOT a group-marker / differential
# expression test and must never be documented as one. nnSVG is an optional
# Suggests dependency reached ONLY through the adapter below; the function never
# normalizes, converts counts, or guesses scale semantics.

.spatial_variability_version <- "1.0.0"

# Is the optional nnSVG dependency available? (Isolated so tests can mock it.)
.nnsvg_installed <- function() requireNamespace("nnSVG", quietly = TRUE)

# Pull one nnSVG output column by any of its version-specific names; fail loudly
# if none is present (a changed upstream schema must not silently produce NA).
.nnsvg_col <- function(df, what, cands) {
  hit <- intersect(cands, colnames(df))
  if (!length(hit)) {
    stop("matrispace: nnSVG output is missing the '", what, "' field (looked for: ",
         paste(cands, collapse = ", "), "); the installed nnSVG version may be ",
         "incompatible.", call. = FALSE)
  }
  v <- df[[hit[1]]]
  # Required statistics must be genuinely numeric -- reject a non-numeric upstream
  # field rather than validating it by silent coercion later.
  if (!is.numeric(v)) {
    stop("matrispace: nnSVG output field '", hit[1], "' (", what, ") is not ",
         "numeric", call. = FALSE)
  }
  v
}

# The ONLY function that touches nnSVG. Runs it on a genes x spots matrix with
# aligned spatial coordinates (+ optional covariate design X) and normalizes the
# version-specific output into the stable matrispace schema. Isolated so the full
# pipeline can be tested by mocking this binding without a long model fit.
.nnsvg_bpparam <- function(n_threads) {
  # nnSVG otherwise selects MulticoreParam on Windows, where BiocParallel warns
  # and falls back. Choose an explicit supported backend so a valid fit is quiet
  # and `n_threads` has the same meaning on every platform.
  if (n_threads == 1L) {
    BiocParallel::SerialParam(progressbar = FALSE)
  } else if (.Platform$OS.type == "windows") {
    BiocParallel::SnowParam(workers = n_threads, progressbar = FALSE)
  } else {
    BiocParallel::MulticoreParam(workers = n_threads, progressbar = FALSE)
  }
}

.run_nnsvg <- function(mat, coords, X, n_neighbors, order, n_threads) {
  bpparam <- .nnsvg_bpparam(n_threads)
  res <- as.data.frame(nnSVG::nnSVG(
    mat, spatial_coords = coords, X = X, n_neighbors = n_neighbors,
    order = order, n_threads = n_threads, BPPARAM = bpparam))
  out <- data.frame(
    feature = rownames(res),
    rank = .nnsvg_col(res, "rank", c("rank")),
    sigma_sq = .nnsvg_col(res, "sigma_sq", c("sigma.sq", "sigma_sq")),
    tau_sq = .nnsvg_col(res, "tau_sq", c("tau.sq", "tau_sq")),
    length_scale = .nnsvg_col(res, "length_scale", c("phi", "length_scale")),
    prop_sv = .nnsvg_col(res, "prop_sv", c("prop_sv", "prop.sv")),
    lr_statistic = .nnsvg_col(res, "lr_statistic", c("LR_stat", "lr_stat")),
    p_value = .nnsvg_col(res, "p_value", c("pval", "p_value", "pvalue")),
    stringsAsFactors = FALSE, row.names = NULL)
  # Structural guarantee: nnSVG must return exactly one row per submitted feature,
  # uniquely. A missing/extra/duplicated feature is a hard error (a later status
  # is derived from pre-fit eligibility and must not be trusted otherwise).
  submitted <- rownames(mat)
  if (anyDuplicated(out$feature) || !setequal(out$feature, submitted) ||
      nrow(out) != length(submitted)) {
    stop("matrispace: nnSVG returned a feature set that does not exactly match the ",
         "submitted features (missing/extra/duplicated rows)", call. = FALSE)
  }
  out[match(submitted, out$feature), , drop = FALSE]      # submitted order
}

#' Find spatially variable ECM features with nnSVG.
#'
#' Tests whether ECM features exhibit residual continuous spatial variation using
#' nnSVG (a nearest-neighbor Gaussian process with gene-specific length scales).
#' This is spatial VARIABILITY, not group differential expression, and does not
#' identify marker genes. Returns a standalone table (one row per requested
#' feature) and never writes results into the object.
#'
#' Supply exactly one of `features` (custom genes, order preserved) or `include`
#' (bundled [matrisome_signatures] keys, resolved to their ordered gene union);
#' omit both to test only the bundled matrisome genes present in the expression
#' source (present-only; no `absent` rows). An explicit `include` keeps `absent`
#' rows for its requested genes that are not in the data.
#'
#' @param object A Seurat or SpatialExperiment object.
#' @param features Custom character vector of genes (mutually exclusive with
#'   `include`); missing genes are an error.
#' @param include Bundled matrisome signature keys (mutually exclusive with
#'   `features`).
#' @param image_id Required for a multi-image object (exactly one image); optional
#'   for a single-image object. Coordinate frames are never concatenated.
#' @param assay Mandatory assay naming the expression source (a normalized,
#'   continuous scale appropriate for nnSVG); never inferred or converted.
#' @param layer Expression layer. Required for Seurat (real per-assay layers);
#'   ignored for SpatialExperiment (one matrix per assay), where it may be `NULL`
#'   and is recorded as `NA`. The resolved source is what appears in the output.
#' @param covariates Optional character vector of spot-metadata columns adjusting
#'   the mean model (via [stats::model.matrix()]); their inclusion does not make
#'   this a test of a group coefficient.
#' @param n_neighbors,order,n_threads Passed to nnSVG exactly.
#' @param ... Must be empty; unknown arguments are rejected.
#' @return A `data.frame` with columns `feature`, `image_id`, `rank`, `sigma_sq`,
#'   `tau_sq`, `length_scale`, `prop_sv`, `lr_statistic`, `p_value`,
#'   `p_adjusted`, `status`, `assay`, `layer`, `n_spots`, `n_neighbors`, `order`,
#'   and a `matrispace` provenance attribute.
#' @export
find_spatially_variable_ecm <- function(object, features = NULL, include = NULL,
                                        image_id = NULL, assay, layer = NULL,
                                        covariates = NULL, n_neighbors = 10L,
                                        order = "AMMD", n_threads = 1L, ...) {
  dots <- list(...)
  if (length(dots)) {
    stop("matrispace: unknown argument(s): ",
         paste(names(dots) %||% "", collapse = ", "), call. = FALSE)
  }
  # Dependency gate + failure semantics FIRST.
  if (!.nnsvg_installed()) {
    stop("matrispace: find_spatially_variable_ecm() requires the optional 'nnSVG' ",
         "package. Install it with BiocManager::install('nnSVG').", call. = FALSE)
  }
  if (missing(assay) || !.is_nonempty_scalar_chr(assay)) {
    stop("matrispace: `assay` is required (no default; the expression source must ",
         "be explicit)", call. = FALSE)
  }
  # `layer` is required for Seurat (which has real per-assay layers) but has no
  # meaning for SpatialExperiment (one matrix per assay), where it may be NULL.
  kind <- .container_kind(object)
  if (kind == "seurat" && !.is_nonempty_scalar_chr(layer)) {
    stop("matrispace: `layer` is required for Seurat objects (the expression ",
         "source must be explicit)", call. = FALSE)
  }
  if (!.is_pos_whole(n_neighbors)) {
    stop("matrispace: `n_neighbors` must be a positive whole number", call. = FALSE)
  }
  n_neighbors <- as.integer(n_neighbors)
  if (!.is_pos_whole(n_threads)) {
    stop("matrispace: `n_threads` must be a positive whole number", call. = FALSE)
  }
  n_threads <- as.integer(n_threads)
  if (!.is_nonempty_scalar_chr(order)) {
    stop("matrispace: `order` must be a single non-empty string", call. = FALSE)
  }
  if (!is.null(features) && !is.null(include)) {
    stop("matrispace: supply exactly one of `features` or `include`, not both",
         call. = FALSE)
  }

  # Single-image rule (nnSVG models one tissue section; frames never concatenated).
  membership <- .get_image_membership(object)
  all_images <- unique(unname(membership))
  if (length(all_images) > 1L) {
    if (is.null(image_id) || !.is_nonempty_scalar_chr(image_id) ||
        !(image_id %in% all_images)) {
      stop("matrispace: a multi-image object requires exactly one valid ",
           "`image_id`; available: ", paste(all_images, collapse = ", "),
           call. = FALSE)
    }
    sel_image <- image_id
  } else {
    if (!is.null(image_id) && !identical(as.character(image_id), all_images[1])) {
      stop("matrispace: unknown image_id '", image_id, "'; available: ",
           all_images[1], call. = FALSE)
    }
    sel_image <- all_images[1]
  }

  # Resolve the expression source per container and record the RESOLVED values
  # (Seurat: the real layer; SPE: no layer concept -> NA), never a placeholder.
  src <- .resolve_expression_source(object, assay = assay, layer = layer)
  resolved_layer <- if (kind == "spe") NA_character_ else src$layer
  expr <- .get_expression(object, assay = src$assay, layer = src$layer)
  expr_genes <- rownames(expr)
  # Feature selection.
  if (!is.null(features)) {
    if (!is.character(features) || !length(features)) {
      stop("matrispace: `features` must be a non-empty character vector", call. = FALSE)
    }
    if (anyDuplicated(features)) {
      stop("matrispace: `features` must not contain duplicates", call. = FALSE)
    }
    requested <- features
    miss <- setdiff(requested, expr_genes)
    if (length(miss)) {
      stop("matrispace: feature(s) not found in assay '", src$assay, "': ",
           paste(miss, collapse = ", "), call. = FALSE)
    }
    selection <- "features"
  } else {
    sigs <- .select_bundled(NULL, include, matrisome_signatures,
                            "features", "include", "matrisome signature")
    requested <- unique(unlist(sigs, use.names = FALSE))
    selection <- if (is.null(include)) "bundled_all" else "include"
  }
  present <- requested[requested %in% expr_genes]        # requested order
  absent <- requested[!(requested %in% expr_genes)]
  if (!length(present)) {
    stop("matrispace: no selected gene is present in assay '", src$assay, "'",
         call. = FALSE)
  }
  # Default (no selector) is PRESENT-ONLY: omitting both selectors tests only the
  # bundled genes actually present, with no `absent` rows. Absent rows are kept
  # only for an explicit `include`.
  if (selection == "bundled_all") {
    requested <- present
    absent <- character(0)
  }

  # Coordinates for the chosen image; align matrix/coords/covariates by spot id.
  coords <- .get_coordinates(object, image_id = sel_image)
  common <- intersect(rownames(coords), colnames(expr))
  if (length(common) < 2L) {
    stop("matrispace: image '", sel_image, "' has fewer than 2 aligned spots",
         call. = FALSE)
  }
  mat <- as.matrix(expr[present, common, drop = FALSE])
  coord_mat <- as.matrix(coords[common, , drop = FALSE])
  storage.mode(coord_mat) <- "double"
  # Non-finite expression is a hard error with feature/spot diagnostics.
  if (any(!is.finite(mat))) {
    bad <- which(!is.finite(mat), arr.ind = TRUE)[1, ]
    stop("matrispace: non-finite expression for feature '", rownames(mat)[bad[1]],
         "' at spot '", colnames(mat)[bad[2]], "' (assay '", src$assay, "')",
         call. = FALSE)
  }
  # Aligned coordinates must be finite (the Seurat accessor does not guarantee
  # it), and nnSVG/BRISC require n_neighbors < n_spots -- validate both here so a
  # malformed coordinate or a tiny image gives an actionable matrispace error
  # rather than an opaque upstream BRISC failure.
  if (any(!is.finite(coord_mat))) {
    bad <- rownames(coord_mat)[!is.finite(coord_mat[, 1L]) |
                                 !is.finite(coord_mat[, 2L])]
    stop("matrispace: non-finite coordinates in image '", sel_image, "' (e.g. ",
         "spot '", bad[1], "')", call. = FALSE)
  }
  if (n_neighbors >= length(common)) {
    stop("matrispace: `n_neighbors` (", n_neighbors, ") must be less than the ",
         "number of spots (", length(common), ") in image '", sel_image, "'",
         call. = FALSE)
  }
  # Constant (zero-variance) features are UNFIT: recorded with a status, not
  # silently omitted and not passed to nnSVG.
  row_var <- apply(mat, 1L, stats::var)
  fit <- present[is.finite(row_var) & row_var > 0]
  constant <- present[!(present %in% fit)]

  # Optional covariate design (mean-model only), aligned to `common`.
  X <- NULL; cov_terms <- character(0)
  if (!is.null(covariates)) {
    if (!is.character(covariates) || !length(covariates)) {
      stop("matrispace: `covariates` must be a non-empty character vector",
           call. = FALSE)
    }
    if (anyDuplicated(covariates)) {
      stop("matrispace: `covariates` has duplicate term(s)", call. = FALSE)
    }
    md <- .get_spot_metadata(object)
    miss <- setdiff(covariates, colnames(md))
    if (length(miss)) {
      stop("matrispace: covariate column(s) not found: ",
           paste(miss, collapse = ", "), call. = FALSE)
    }
    cov_df <- md[common, covariates, drop = FALSE]
    if (anyNA(cov_df)) {
      stop("matrispace: covariate(s) contain missing values in image '", sel_image,
           "'", call. = FALSE)
    }
    for (cv in covariates) {
      v <- cov_df[[cv]]
      # anyNA() above catches NA/NaN but not Inf in a numeric covariate, which
      # would otherwise leak into qr()/BRISC as an opaque failure.
      if (is.numeric(v) && any(!is.finite(v))) {
        stop("matrispace: covariate '", cv, "' has non-finite values in image '",
             sel_image, "'", call. = FALSE)
      }
      if (length(unique(v)) < 2L) {
        stop("matrispace: covariate '", cv, "' has only one level in image '",
             sel_image, "'", call. = FALSE)
      }
    }
    form <- stats::as.formula(
      paste("~", paste(sprintf("`%s`", covariates), collapse = " + ")))
    # Pass the FULL model.matrix design INCLUDING the intercept: nnSVG 1.14.0
    # passes X straight to BRISC and fits the null mean model as `y ~ X - 1`, so
    # dropping `(Intercept)` would fit a no-intercept model and change the test.
    mm <- stats::model.matrix(form, data = cov_df)
    if (qr(mm)$rank < ncol(mm)) {
      stop("matrispace: covariate design is rank-deficient", call. = FALSE)
    }
    X <- mm; cov_terms <- colnames(mm)
  }

  # Fit nnSVG on the fit-eligible features only.
  tested <- if (length(fit)) {
    .run_nnsvg(mat[fit, , drop = FALSE], coord_mat, X, n_neighbors, order, n_threads)
  } else {
    data.frame(feature = character(0), rank = numeric(0), sigma_sq = numeric(0),
               tau_sq = numeric(0), length_scale = numeric(0), prop_sv = numeric(0),
               lr_statistic = numeric(0), p_value = numeric(0),
               stringsAsFactors = FALSE)
  }

  # One row per REQUESTED feature. Status:
  #  - a fit-eligible feature with finite key statistics -> "tested";
  #  - a fit-eligible feature whose nnSVG fit produced non-finite statistics
  #    -> "failed" (with NA statistics, excluded from BH);
  #  - a zero-variance feature -> "constant"; a not-in-data feature -> "absent".
  mi <- match(requested, tested$feature)
  # A fit counts as "tested" only if EVERY required statistic is a valid number:
  # all finite; variances non-negative; length scale positive; p_value and
  # prop_sv in [0, 1]. Anything else -> "failed" (NA stats, excluded from BH).
  nz <- function(v) suppressWarnings(as.numeric(v))
  tv <- if (nrow(tested)) with(tested, {
    rk <- nz(rank); sig <- nz(sigma_sq); tau <- nz(tau_sq); ls <- nz(length_scale)
    ps <- nz(prop_sv); lr <- nz(lr_statistic); pv <- nz(p_value)
    is.finite(rk) & is.finite(sig) & sig >= 0 & is.finite(tau) & tau >= 0 &
      is.finite(ls) & ls > 0 & is.finite(ps) & ps >= 0 & ps <= 1 &
      is.finite(lr) & is.finite(pv) & pv >= 0 & pv <= 1
  }) else logical(0)
  submitted <- requested %in% fit
  valid_fit <- submitted & !is.na(mi)
  valid_fit[valid_fit] <- tv[mi[valid_fit]]
  status <- ifelse(submitted, ifelse(valid_fit, "tested", "failed"),
                   ifelse(requested %in% constant, "constant", "absent"))
  # Statistics are carried ONLY for genuinely tested features; the stable schema
  # columns are always numeric (never inherit an upstream non-numeric type).
  stat_of <- function(col) {
    v <- rep(NA_real_, length(requested))
    keep <- status == "tested"
    v[keep] <- as.numeric(tested[[col]][mi[keep]])
    v
  }
  df <- data.frame(
    feature = requested, image_id = sel_image,
    rank = stat_of("rank"), sigma_sq = stat_of("sigma_sq"),
    tau_sq = stat_of("tau_sq"), length_scale = stat_of("length_scale"),
    prop_sv = stat_of("prop_sv"), lr_statistic = stat_of("lr_statistic"),
    p_value = stat_of("p_value"), p_adjusted = NA_real_,
    status = status, assay = src$assay, layer = resolved_layer,
    n_spots = length(common), n_neighbors = n_neighbors, order = order,
    stringsAsFactors = FALSE, row.names = NULL)
  # BH over every successfully tested feature in this invocation.
  ok <- df$status == "tested"
  if (any(ok)) df$p_adjusted[ok] <- stats::p.adjust(df$p_value[ok], "BH")

  attr(df, "matrispace") <- list(
    producer = "find_spatially_variable_ecm",
    version = .spatial_variability_version, image_id = sel_image,
    assay = src$assay, layer = resolved_layer, selection = selection,
    requested = requested, n_present = length(present), n_absent = length(absent),
    n_tested = sum(df$status == "tested"), n_failed = sum(df$status == "failed"),
    n_constant = length(constant),
    covariates = covariates %||% character(0), covariate_terms = cov_terms,
    n_spots = length(common), n_neighbors = n_neighbors, order = order,
    n_threads = n_threads,
    nnSVG_version = as.character(utils::packageVersion("nnSVG")),
    BRISC_version = tryCatch(as.character(utils::packageVersion("BRISC")),
                             error = function(e) NA_character_))
  df
}
