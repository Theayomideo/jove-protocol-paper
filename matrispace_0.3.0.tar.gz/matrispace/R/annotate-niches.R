# ECM niche annotation (SPEC s8). A fully specified ScType-style scoring kernel
# (independently testable, hand-oracle verified) plus host storage: the niche
# score matrix is a feature-result artifact and the winning label is mirrored
# into spot metadata under a namespaced key.

# Row-wise z-scaling; a zero-variance gene contributes 0 (not NaN).
.zscale_rows <- function(m) {
  m <- as.matrix(m)
  mu <- rowMeans(m)
  sdv <- apply(m, 1, stats::sd)
  z <- sweep(sweep(m, 1, mu, "-"), 1, sdv, "/")
  z[!is.finite(z)] <- 0
  z
}

# Pure ScType scoring kernel (SPEC s8). Returns niches x spots `scores` (full,
# pos - neg) and `positive` (positive-only, for tie-breaking). Sensitivity
# weight = 1/sqrt(occurrence across BOTH roles) (so a negative-only marker is
# never 1/sqrt(0)); each role sum is normalized by sqrt(#matched markers).
#' @keywords internal
.sctype_scores <- function(expr, markers) {
  niches <- names(markers)
  if (is.null(niches) || any(!nzchar(niches)) || anyDuplicated(niches)) {
    stop("matrispace: `markers` must be a uniquely-named list of niches",
         call. = FALSE)
  }
  for (nm in niches) {
    pos <- markers[[nm]]$positive
    neg <- markers[[nm]]$negative %||% character(0)
    if (!is.character(pos) || (length(neg) && !is.character(neg))) {
      stop("matrispace: niche '", nm, "' markers must be character vectors",
           call. = FALSE)
    }
    if (length(pos) == 0L) {
      stop("matrispace: niche '", nm, "' has an empty positive marker list",
           call. = FALSE)
    }
    if (anyNA(c(pos, neg)) || any(!nzchar(c(pos, neg)))) {
      stop("matrispace: niche '", nm, "' markers contain NA or empty gene names",
           call. = FALSE)
    }
  }
  genes <- rownames(expr)
  # Occurrence = number of NICHES listing a gene (each niche contributes at most
  # once, across both roles) -- NOT raw marker-entry counts.
  occ <- table(unlist(lapply(markers,
                             function(m) unique(c(m$positive, m$negative)))))
  # Subset to the matched MARKER genes before z-scaling: never densify the whole
  # transcriptome when only a handful of marker rows are used.
  used <- intersect(unique(unlist(lapply(markers,
                    function(m) c(m$positive, m$negative)))), genes)
  z <- .zscale_rows(expr[used, , drop = FALSE])
  ns <- ncol(expr)
  scores <- matrix(NA_real_, length(niches), ns,
                   dimnames = list(niches, colnames(expr)))
  positive <- scores
  unavailable <- character(0)
  for (nm in niches) {
    pos <- intersect(unique(markers[[nm]]$positive), genes)
    neg <- intersect(unique(markers[[nm]]$negative %||% character(0)), genes)
    if (length(pos) == 0L) {                           # unavailable -> NA row
      unavailable <- c(unavailable, nm)
      next
    }
    wpos <- 1 / sqrt(as.numeric(occ[pos]))
    pos_term <- colSums(wpos * z[pos, , drop = FALSE]) / sqrt(length(pos))
    neg_term <- rep(0, ns)
    if (length(neg) > 0L) {
      wneg <- 1 / sqrt(as.numeric(occ[neg]))
      neg_term <- colSums(wneg * z[neg, , drop = FALSE]) / sqrt(length(neg))
    }
    positive[nm, ] <- pos_term
    scores[nm, ] <- pos_term - neg_term
  }
  # Error (no warning) if nothing is classifiable; otherwise warn about the
  # unavailable subset.
  if (all(is.na(scores))) {
    stop("matrispace: no niche has any matched positive markers in the dataset",
         call. = FALSE)
  }
  if (length(unavailable)) {
    warning("matrispace: niche(s) with no matched positive markers scored as NA: ",
            paste(unavailable, collapse = ", "), call. = FALSE)
  }
  list(scores = scores, positive = positive)
}

# Winning niche per spot: argmax score above `threshold`; ties broken by larger
# positive-only score, then by sorted niche name. NA when no niche qualifies.
#' @keywords internal
.sctype_call <- function(scores, positive, threshold = 0) {
  niches <- rownames(scores)
  vapply(seq_len(ncol(scores)), function(j) {
    s <- scores[, j]
    if (all(is.na(s))) return(NA_character_)
    mx <- max(s, na.rm = TRUE)
    if (mx <= threshold) return(NA_character_)
    win <- which(!is.na(s) & s == mx)
    if (length(win) == 1L) return(niches[win])
    pw <- positive[win, j]
    win <- win[pw == max(pw)]
    sort(niches[win])[1]
  }, character(1))
}

#' Annotate ECM niches by ScType-style marker scoring.
#'
#' Supply exactly one of `markers` (custom definitions) or `niches` (bundled
#' [ecm_markers] keys); omit both to classify against every bundled niche.
#' See [list_ecm_niches()] for which niches support classification (`vascular`
#' is classification-only).
#'
#' @param object A Seurat or SpatialExperiment object.
#' @param markers Named list of custom niches, each `list(positive=, negative=)`.
#'   Mutually exclusive with `niches`.
#' @param niches Character vector of bundled classification-niche keys to use, in
#'   the requested order. Mutually exclusive with `markers`.
#' @param assay,layer Explicit expression source (`layer = NULL` uses the
#'   container's default expression layer).
#' @param not_assigned_threshold Minimum winning score to assign a niche
#'   (otherwise the spot is unassigned, `NA`).
#' @param overwrite Replace an existing `ecm_niche_classification_scores`
#'   artifact produced from a different definition/parameters. Default `FALSE`
#'   errors instead of silently clobbering the earlier classification.
#' @param ... Unused.
#' @return The object with an `ecm_niche_classification_scores` artifact and a
#'   `matrispace_ecm_niche_classification` label column in spot metadata (the
#'   discrete ScType-style call, not a continuous niche score).
#' @export
annotate_ecm_niches <- function(object, markers = NULL, niches = NULL,
                                assay, layer = NULL,
                                not_assigned_threshold = 0,
                                overwrite = FALSE, ...) {
  markers <- .select_bundled(markers, niches, ecm_markers,
                             "markers", "niches", "ECM niche")
  if (!is.list(markers) || length(markers) == 0L || is.null(names(markers)) ||
      any(!nzchar(names(markers)))) {
    stop("matrispace: `markers` must be a named list of niches", call. = FALSE)
  }
  for (nm in names(markers)) {
    if (!is.list(markers[[nm]]) || is.null(markers[[nm]]$positive)) {
      stop("matrispace: niche '", nm, "' must have a $positive gene vector",
           call. = FALSE)
    }
  }
  if (missing(assay)) stop("matrispace: `assay` is required", call. = FALSE)
  if (length(not_assigned_threshold) != 1L || !is.finite(not_assigned_threshold)) {
    stop("matrispace: `not_assigned_threshold` must be a single finite number",
         call. = FALSE)
  }

  # Fingerprint the FULL computation (markers + resolved assay/layer + threshold)
  # and decide before scoring: an identical prior classification is returned
  # untouched; a different one requires overwrite = TRUE.
  src <- .resolve_expression_source(object, assay = assay, layer = layer)
  fp <- .computation_fingerprint(
    markers, src$assay, src$layer,
    params = list(not_assigned_threshold = not_assigned_threshold))
  decision <- .overwrite_decision(object, "ecm_niche_classification_scores", fp,
                                  overwrite, "annotate_ecm_niches")
  if (identical(decision, "skip")) return(object)

  expr <- .get_expression(object, assay = assay, layer = layer)
  .validate_nonneg_finite(expr, "expression")
  sc <- .sctype_scores(expr, markers)
  calls <- .sctype_call(sc$scores, sc$positive, not_assigned_threshold)
  names(calls) <- colnames(sc$scores)

  # The score artifact and the label mirror must have distinct physical names:
  # on Seurat, assays and metadata columns share the `[[ ]]` namespace, so the
  # score assay (`..._classification_scores`) is deliberately distinct from the
  # `matrispace_ecm_niche_classification` label column.
  object <- .set_feature_result(
    object, "ecm_niche_classification_scores", sc$scores, type = "score",
    context = list(producer = "annotate_ecm_niches",
                   input_assay = assay %||% NA_character_,
                   input_layer = layer %||% NA_character_,
                   parameters = list(
                     niches = names(markers),
                     # Distinguish identical niche names with different markers.
                     marker_digest = .definition_digest(markers),
                     # Complete computation fingerprint used by the overwrite
                     # guard (markers + resolved assay/layer + threshold).
                     fingerprint = fp,
                     not_assigned_threshold = not_assigned_threshold)))
  # Mirror the winning label into spot metadata under a collision-resistant key
  # that names it as the discrete classification (not a continuous score).
  .set_spot_metadata(object, "matrispace_ecm_niche_classification",
                     calls[colnames(object)])
}

#' Retrieve ScType ECM-niche classification scores
#' @param object A Seurat or SpatialExperiment object.
#' @return A niche x spot classification-score matrix.
#' @export
get_ecm_niche_classification_scores <- function(object) {
  reg <- .get_registry(object)
  if (is.null(reg) ||
      !("ecm_niche_classification_scores" %in% names(reg$artifacts))) {
    stop("matrispace: object has no ECM-niche classification scores; run ",
         "annotate_ecm_niches() first", call. = FALSE)
  }
  .get_feature_result(object, "ecm_niche_classification_scores")
}

#' Retrieve the per-spot ECM niche calls.
#' @param object A Seurat or SpatialExperiment object.
#' @return A character vector of niche labels named by spot id (NA = unassigned).
#' @export
get_ecm_niches <- function(object) {
  md <- .get_spot_metadata(object)
  if (!("matrispace_ecm_niche_classification" %in% colnames(md))) {
    stop("matrispace: object has no ECM niche annotation; run ",
         "annotate_ecm_niches() first", call. = FALSE)
  }
  stats::setNames(as.character(md[["matrispace_ecm_niche_classification"]]),
                  rownames(md))
}
