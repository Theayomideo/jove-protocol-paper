# Differential expression (SPEC s10). Two public entry points:
#   compare_ecm_groups() - within-object, container-independent Wilcoxon over the
#     accessor expression matrix, restricted to matrisome genes (FDR over that
#     family), annotated with matrisome category.
#   test_ecm_pseudobulk() - cross-REPLICATE pseudobulk DESeq2. Normalization and
#     dispersions are fit on the FULL count matrix; the explicit contrast result
#     is then subset to matrisome genes with BH over that restricted family.

# Matrisome genes / category map from a character vector or a gene+category df.
.matrisome_genes <- function(matrisome) {
  if (is.data.frame(matrisome)) as.character(matrisome[[1]]) else as.character(matrisome)
}
.matrisome_category_map <- function(matrisome) {
  if (is.data.frame(matrisome) && ncol(matrisome) >= 2L) {
    stats::setNames(as.character(matrisome[[2]]), as.character(matrisome[[1]]))
  } else {
    NULL
  }
}
.annotate_category <- function(genes, matrisome) {
  map <- .matrisome_category_map(matrisome)
  if (is.null(map)) rep(NA_character_, length(genes)) else unname(map[genes])
}
# Association-preserving digest: for a gene+category df, hash sorted per-row
# (gene, category) tuples so a changed category assignment changes the digest.
.matrisome_digest <- function(matrisome) {
  if (is.data.frame(matrisome) && ncol(matrisome) >= 2L) {
    g <- as.character(matrisome[[1]]); k <- as.character(matrisome[[2]])
    ids <- vapply(seq_along(g),
                  function(i) digest::digest(list(g[i], k[i]), algo = "xxhash64"),
                  character(1))
    # unique() so allowed redundant (identical) rows do not change provenance.
    digest::digest(sort(unique(ids)), algo = "xxhash64")
  } else {
    digest::digest(sort(unique(.matrisome_genes(matrisome))), algo = "xxhash64")
  }
}

# Structural validation of a matrisome definition, shared by both DE functions:
# a character vector of genes, or a data.frame whose first column is genes and
# (optionally) second column is category. Genes must be non-empty and non-NA;
# a gene must not carry two conflicting categories.
.validate_matrisome <- function(matrisome, what = "matrisome") {
  if (is.data.frame(matrisome)) {
    if (ncol(matrisome) < 1L || nrow(matrisome) == 0L) {
      stop("matrispace: `", what, "` data.frame must have >=1 row and a gene column",
           call. = FALSE)
    }
    g <- as.character(matrisome[[1]])
  } else if (is.character(matrisome) || is.factor(matrisome)) {
    g <- as.character(matrisome)
  } else {
    stop("matrispace: `", what, "` must be a character vector or a gene+category ",
         "data.frame", call. = FALSE)
  }
  if (length(g) == 0L) {
    stop("matrispace: `", what, "` is empty", call. = FALSE)
  }
  if (anyNA(g) || any(!nzchar(g))) {
    stop("matrispace: `", what, "` gene names must be non-empty and non-NA",
         call. = FALSE)
  }
  if (is.data.frame(matrisome) && ncol(matrisome) >= 2L) {
    k <- as.character(matrisome[[2]])
    if (anyNA(k) || any(!nzchar(k))) {
      stop("matrispace: `", what, "` categories must be non-empty and non-NA",
           call. = FALSE)
    }
    n_cat <- vapply(split(k, g), function(v) length(unique(v)), integer(1))
    if (any(n_cat > 1L)) {
      bad <- names(n_cat)[n_cat > 1L]
      stop("matrispace: `", what, "` assigns conflicting categories to gene(s): ",
           paste(utils::head(bad, 5L), collapse = ", "), call. = FALSE)
    }
  } else if (anyDuplicated(g)) {
    stop("matrispace: `", what, "` gene names must be unique", call. = FALSE)
  }
  invisible(TRUE)
}

# Sparse-safe validation of raw counts: finite, non-negative, whole numbers.
.validate_counts <- function(m, what = "counts") {
  vals <- if (methods::is(m, "sparseMatrix")) m@x else as.numeric(m)
  if (any(!is.finite(vals))) {
    stop("matrispace: ", what, " contain non-finite values (NA/NaN/Inf)", call. = FALSE)
  }
  if (any(vals < 0)) {
    stop("matrispace: ", what, " must be non-negative", call. = FALSE)
  }
  if (any(vals != round(vals))) {
    stop("matrispace: ", what, " must be whole numbers (raw counts)", call. = FALSE)
  }
  invisible(TRUE)
}

# Availability seam for the optional DESeq2 dependency, isolated so tests can
# exercise the missing-dependency branch by mocking it (rather than leaving a
# permanently-unreachable skip when DESeq2 happens to be installed).
.has_deseq2 <- function() requireNamespace("DESeq2", quietly = TRUE)

.expm1_sparse <- function(m) {
  m <- methods::as(m, "CsparseMatrix"); m@x <- expm1(m@x); m
}

.wilcox_de <- function(expr, labels, ident1, ident2) {
  g1 <- which(!is.na(labels) & labels == ident1)
  g2 <- if (is.null(ident2)) which(!is.na(labels) & nzchar(labels) & labels != ident1)
        else which(!is.na(labels) & labels == ident2)
  if (length(g1) < 1L || length(g2) < 1L) {
    stop("matrispace: both groups must be non-empty (ident.1='", ident1, "')",
         call. = FALSE)
  }
  genes <- rownames(expr)
  x1 <- expr[, g1, drop = FALSE]; x2 <- expr[, g2, drop = FALSE]
  m1 <- as.numeric(Matrix::rowMeans(.expm1_sparse(x1)))
  m2 <- as.numeric(Matrix::rowMeans(.expm1_sparse(x2)))
  avg_log2FC <- log2(m1 + 1) - log2(m2 + 1)
  pct.1 <- as.numeric(Matrix::rowMeans(x1 > 0))
  pct.2 <- as.numeric(Matrix::rowMeans(x2 > 0))
  x1m <- as.matrix(x1); x2m <- as.matrix(x2)
  p_value <- vapply(seq_along(genes), function(i) {
    suppressWarnings(stats::wilcox.test(x1m[i, ], x2m[i, ])$p.value)
  }, numeric(1))
  data.frame(feature = genes, group = ident1, avg_log2FC = avg_log2FC,
             pct.1 = pct.1, pct.2 = pct.2, p_value = p_value,
             stringsAsFactors = FALSE)
}

#' Descriptively compare ECM expression between spot groups
#'
#' This is a spot-level Wilcoxon comparison for descriptive within-object
#' marker discovery. It is not replicate-level confirmatory inference; use
#' [test_ecm_pseudobulk()] for that purpose.
#' @param object A Seurat or SpatialExperiment object.
#' @param group_by Spot-metadata column of group labels.
#' @param ident.1 Group of interest; `NULL` runs all-vs-all with global FDR.
#' @param ident.2 Comparison group (`NULL` = the rest).
#' @param assay,layer Expression source; `layer` must hold `log1p` expression.
#' @param matrisome Character vector of matrisome genes, or gene + category df.
#' @param ... Unused.
#' @return A data.frame of per-gene DE statistics (matrisome genes), with
#'   `feature`, `matrisome_category`, and BH over the tested family.
#' @export
compare_ecm_groups <- function(object, group_by, ident.1, ident.2 = NULL,
                             assay, layer = NULL, matrisome = matrisome_db, ...) {
  if (missing(assay)) stop("matrispace: `assay` is required", call. = FALSE)
  if (!.is_nonempty_scalar_chr(group_by)) {
    stop("matrispace: `group_by` must be a single column name", call. = FALSE)
  }
  if (!is.null(ident.1) && !.is_nonempty_scalar_chr(ident.1)) {
    stop("matrispace: `ident.1` must be NULL or a single non-empty label", call. = FALSE)
  }
  if (!is.null(ident.2) && !.is_nonempty_scalar_chr(ident.2)) {
    stop("matrispace: `ident.2` must be NULL or a single non-empty label", call. = FALSE)
  }
  if (!is.null(ident.1) && !is.null(ident.2) && identical(ident.1, ident.2)) {
    stop("matrispace: `ident.1` and `ident.2` must differ", call. = FALSE)
  }
  if (is.null(ident.1) && !is.null(ident.2)) {
    stop("matrispace: `ident.2` is ignored unless `ident.1` is supplied", call. = FALSE)
  }
  .validate_matrisome(matrisome)
  md <- .get_spot_metadata(object)
  if (!(group_by %in% colnames(md))) {
    stop("matrispace: group_by column '", group_by, "' not found", call. = FALSE)
  }
  labels <- as.character(md[colnames(object), group_by])

  expr <- .get_expression(object, assay = assay, layer = layer)
  .validate_nonneg_finite(expr, "expression")         # necessary log1p check
  genes <- intersect(.matrisome_genes(matrisome), rownames(expr))
  if (length(genes) == 0L) {
    stop("matrispace: no matrisome genes found in the data", call. = FALSE)
  }
  expr <- expr[genes, , drop = FALSE]

  if (is.null(ident.1)) {
    idents <- sort(unique(labels[!is.na(labels) & nzchar(labels)]))
    if (length(idents) < 2L) {
      stop("matrispace: all-vs-all requires at least two non-empty groups in '",
           group_by, "'", call. = FALSE)
    }
    res <- do.call(rbind, lapply(idents, function(id) .wilcox_de(expr, labels, id, NULL)))
  } else {
    res <- .wilcox_de(expr, labels, ident.1, ident.2)
  }
  res$p_adjusted <- stats::p.adjust(res$p_value, "BH")  # BH over matrisome family
  res$matrisome_category <- .annotate_category(res$feature, matrisome)
  rownames(res) <- NULL
  attr(res, "matrispace") <- list(
    producer = "compare_ecm_groups", group_by = group_by,
    ident.1 = ident.1 %||% NA_character_, ident.2 = ident.2 %||% NA_character_,
    assay = assay %||% NA_character_, layer = layer %||% NA_character_,
    matrisome_digest = .matrisome_digest(matrisome))
  res
}

#' Compatibility name for [compare_ecm_groups()]
#' @inheritParams compare_ecm_groups
#' @return The same result as [compare_ecm_groups()].
#' @export
find_ecm_markers <- compare_ecm_groups

# Collision-resistant per-spot group key: length-prefixed serialization of the
# group columns (injective, unlike a plain "__" join).
.group_key <- function(gdf) {
  do.call(paste0, lapply(gdf, function(v) paste0(nchar(v), ":", v)))
}

#' @keywords internal
.pseudobulk <- function(object, group, assay = "counts") {
  counts <- .get_counts(object, assay)
  md <- .get_spot_metadata(object)
  spots <- colnames(object)
  counts <- counts[, spots, drop = FALSE]
  gdf <- data.frame(lapply(group, function(g) as.character(md[spots, g])),
                    stringsAsFactors = FALSE)
  names(gdf) <- group
  enc <- .group_key(gdf)
  ui <- !duplicated(enc)
  uenc <- enc[ui]
  ind <- Matrix::sparseMatrix(i = match(enc, uenc), j = seq_along(enc),
                              x = 1, dims = c(length(uenc), length(enc)))
  pb <- counts %*% Matrix::t(ind)
  colnames(pb) <- uenc
  attr(pb, "groups") <- gdf[ui, , drop = FALSE]       # unique group combinations
  pb
}

#' Test replicate-level ECM differential expression by pseudobulk
#'
#' Biological replicates are the inferential units. Raw counts are aggregated
#' by replicate and tested with an explicit DESeq2 condition contrast.
#' @param object A Seurat or SpatialExperiment object.
#' @param condition Spot-metadata column naming the biological condition.
#' @param replicate Spot-metadata column naming the biological replicate.
#' @param counts_assay Assay of raw (integer) counts to aggregate.
#' @param matrisome Matrisome genes (vector or gene + category df).
#' @param condition.1 Numerator condition (default: the second sorted level).
#' @param condition.2 Reference condition (default: the first sorted level).
#' @param ... Unused.
#' @return A data.frame of pseudobulk DE results (matrisome genes), annotated,
#'   with BH over the matrisome family and a `matrispace` provenance attribute.
#' @export
test_ecm_pseudobulk <- function(object, condition, replicate, counts_assay = "counts",
                        matrisome = matrisome_db,
                        condition.1 = NULL, condition.2 = NULL, ...) {
  .validate_matrisome(matrisome)
  for (nm in c("condition", "replicate", "counts_assay")) {
    if (!.is_nonempty_scalar_chr(get(nm))) {
      stop("matrispace: `", nm, "` must be a single non-empty string", call. = FALSE)
    }
  }
  for (nm in c("condition.1", "condition.2")) {
    v <- get(nm)
    if (!is.null(v) && !.is_nonempty_scalar_chr(v)) {
      stop("matrispace: `", nm, "` must be NULL or a single non-empty string",
           call. = FALSE)
    }
  }
  md <- .get_spot_metadata(object)
  for (col in c(condition, replicate)) {
    if (!(col %in% colnames(md))) {
      stop("matrispace: column '", col, "' not found", call. = FALSE)
    }
  }
  spots <- colnames(object)
  cond <- as.character(md[spots, condition])
  rep  <- as.character(md[spots, replicate])
  if (anyNA(cond) || anyNA(rep) || any(!nzchar(cond)) || any(!nzchar(rep))) {
    stop("matrispace: condition/replicate must be non-missing, non-empty for all spots",
         call. = FALSE)
  }

  # Condition is a property of the replicate.
  rc <- unique(data.frame(rep = rep, cond = cond, stringsAsFactors = FALSE))
  if (anyDuplicated(rc$rep)) {
    stop("matrispace: condition varies within a replicate (spot-level ",
         "pseudoreplication); condition must be constant per replicate.",
         call. = FALSE)
  }
  rep_cond <- stats::setNames(rc$cond, rc$rep)
  conds <- sort(unique(rep_cond))
  if (length(conds) != 2L) {
    stop("matrispace: test_ecm_pseudobulk requires exactly two conditions in 0.2.0 (found ",
         length(conds), ")", call. = FALSE)
  }
  if (any(table(rep_cond) < 2L)) {
    stop("matrispace: each condition needs at least 2 independent replicates.",
         call. = FALSE)
  }
  condition.2 <- condition.2 %||% conds[1]            # reference
  condition.1 <- condition.1 %||% conds[2]            # numerator
  if (!all(c(condition.1, condition.2) %in% conds)) {
    stop("matrispace: condition.1/condition.2 must be among the observed conditions",
         call. = FALSE)
  }
  if (identical(condition.1, condition.2)) {
    stop("matrispace: numerator and reference conditions must differ", call. = FALSE)
  }

  # Validate raw counts BEFORE aggregation; never silently round.
  .validate_counts(.get_counts(object, counts_assay), "counts")

  # Pseudobulk the FULL count matrix (all genes) so DESeq2 normalizes on the
  # whole transcriptome, not the ECM target family.
  pb <- .pseudobulk(object, group = replicate, assay = counts_assay)
  reps <- attr(pb, "groups")[[replicate]]
  coldata <- data.frame(
    condition = factor(rep_cond[reps], levels = c(condition.2, condition.1)),
    row.names = colnames(pb))
  mm <- stats::model.matrix(~ condition, coldata)
  if (qr(mm)$rank < ncol(mm)) {
    stop("matrispace: the condition design is rank-deficient", call. = FALSE)
  }

  if (!.has_deseq2()) {
    stop("matrispace: test_ecm_pseudobulk() requires the optional 'DESeq2' package; ",
         "install it or use compare_ecm_groups() for descriptive spot-level comparison.",
         call. = FALSE)
  }
  if (max(pb) > .Machine$integer.max) {
    stop("matrispace: pseudobulk totals exceed R's integer range; aggregate fewer ",
         "spots per replicate or downsample counts.", call. = FALSE)
  }
  cnt <- as.matrix(pb); storage.mode(cnt) <- "integer"
  dds <- suppressMessages(DESeq2::DESeqDataSetFromMatrix(
    countData = cnt, colData = coldata, design = ~ condition))
  dds <- suppressMessages(DESeq2::DESeq(dds, quiet = TRUE))
  # Explicit contrast: log2FC = condition.1 (numerator) vs condition.2 (reference).
  res_full <- as.data.frame(DESeq2::results(dds,
    contrast = c("condition", condition.1, condition.2)))
  res_full$feature <- rownames(res_full)

  genes <- intersect(.matrisome_genes(matrisome), res_full$feature)
  if (length(genes) == 0L) {
    stop("matrispace: no matrisome genes found in the data", call. = FALSE)
  }
  res <- res_full[res_full$feature %in% genes, , drop = FALSE]
  # Standardize the schema: expose a single, unambiguous p-value pair. DESeq2's
  # own `padj` uses independent filtering over ALL genes, which is NOT the locked
  # contract, so it is dropped; `p_value` is the raw DESeq2 pvalue and
  # `p_adjusted` is BH over the matrisome-restricted output family.
  res$p_value <- res$pvalue
  res$pvalue <- NULL
  res$padj <- NULL
  res$p_adjusted <- stats::p.adjust(res$p_value, "BH")
  res$matrisome_category <- .annotate_category(res$feature, matrisome)
  res <- res[, c("feature", "baseMean", "log2FoldChange", "lfcSE", "stat",
                 "p_value", "p_adjusted", "matrisome_category")]
  rownames(res) <- NULL
  attr(res, "matrispace") <- list(
    producer = "test_ecm_pseudobulk", condition = condition, replicate = replicate,
    design = "~ condition", counts_assay = counts_assay,
    numerator = condition.1, reference = condition.2,
    levels = c(condition.2, condition.1),
    replicates_per_condition = as.list(table(rep_cond)),
    matrisome_digest = .matrisome_digest(matrisome))
  res
}


#' Compatibility name for [test_ecm_pseudobulk()]
#' @inheritParams test_ecm_pseudobulk
#' @return The same result as [test_ecm_pseudobulk()].
#' @export
find_ecm_de <- test_ecm_pseudobulk
