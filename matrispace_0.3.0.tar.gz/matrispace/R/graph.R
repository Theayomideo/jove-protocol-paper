# Spatial graph foundation (SPEC s3.2, s5). build_spatial_graph() constructs a
# named `matrispace_graph`, partitioned by image_id (coordinate frame), stored in
# the registry, and consumed by every spatial analysis. Neighbor search uses a
# kd-tree (dbscan) so no dense n x n distance matrix is ever allocated, and tie
# resolution never expands to a global radius.

.graph_schema_current <- "1.1.0"

.is_finite_pos_scalar <- function(x) {
  is.numeric(x) && length(x) == 1L && is.finite(x) && x > 0
}

# Canonical fingerprint over ordered spot ids, EXACT coordinate doubles, image
# membership, and the coordinate system (SPEC s3.2). No rounding: any real
# coordinate change (however small) invalidates the graph. Coordinates read back
# from the same host are bit-stable, so identity validation needs no tolerance.
.coordinate_fingerprint <- function(spots, coords, images, coordinate_system,
                                    partition_ids = NULL,
                                    partition_within_image = NULL) {
  ord <- order(spots)
  payload <- list(
    spot_ids          = spots[ord],
    coords            = coords[ord, , drop = FALSE],
    images            = as.character(images[ord]),
    partition_ids     = if (is.null(partition_ids)) NULL else
                          as.character(partition_ids[ord]),
    partition_within_image = partition_within_image,
    coordinate_system = coordinate_system
  )
  digest::digest(payload, algo = "xxhash64")
}

#' @keywords internal
.new_matrispace_graph <- function(connectivities, distances, spot_ids, image_ids,
                                  replicate_ids, partition_ids,
                                  partition_within_image, method, parameters, directed,
                                  symmetrize, coordinate_system,
                                  coordinate_fingerprint) {
  structure(list(
    schema_version         = .graph_schema_current,
    connectivities         = connectivities,
    distances              = distances,
    spot_ids               = spot_ids,
    image_ids              = image_ids,
    replicate_ids          = replicate_ids,
    partition_ids          = partition_ids,
    partition_within_image = partition_within_image,
    method                 = method,
    parameters             = parameters,
    directed               = directed,
    symmetrize             = symmetrize,
    weight                 = "none",
    coordinate_system      = coordinate_system,
    coordinate_fingerprint = coordinate_fingerprint
  ), class = "matrispace_graph")
}

# ---- Structural validation (SPEC s3.2), container-independent ----------------

.graph_required_fields <- c("schema_version", "connectivities", "distances",
                            "spot_ids", "image_ids", "replicate_ids", "method",
                            "partition_ids", "partition_within_image",
                            "parameters", "directed", "symmetrize", "weight",
                            "coordinate_system", "coordinate_fingerprint")

#' @keywords internal
.validate_matrispace_graph <- function(g) {
  if (!inherits(g, "matrispace_graph")) {
    stop("matrispace: not a matrispace_graph", call. = FALSE)
  }
  missing <- setdiff(.graph_required_fields, names(g))
  if (length(missing)) {
    stop("matrispace: graph missing field(s): ", paste(missing, collapse = ", "),
         call. = FALSE)
  }
  if (!.is_nonempty_scalar_chr(g$schema_version) ||
      utils::compareVersion(g$schema_version, .graph_schema_current) > 0) {
    stop("matrispace: graph schema '", g$schema_version, "' is invalid or newer ",
         "than supported (", .graph_schema_current, ")", call. = FALSE)
  }
  # Identity / domain fields.
  .validate_spot_ids(g$spot_ids)                       # unique, non-NA, non-empty
  n <- length(g$spot_ids)
  if (n == 0L) stop("matrispace: graph has zero nodes", call. = FALSE)
  if (!is.character(g$image_ids) || length(g$image_ids) != n ||
      anyNA(g$image_ids) || any(!nzchar(g$image_ids))) {
    stop("matrispace: image_ids must be a non-empty, non-NA character vector of ",
         "length n", call. = FALSE)
  }
  if (!is.character(g$replicate_ids) || length(g$replicate_ids) != n) {
    stop("matrispace: replicate_ids must be a character vector of length n (NA ",
         "allowed)", call. = FALSE)
  }
  if (!is.character(g$partition_ids) || length(g$partition_ids) != n) {
    stop("matrispace: partition_ids must be a character vector of length n",
         call. = FALSE)
  }
  if (!(length(g$partition_within_image) == 1L &&
        (is.na(g$partition_within_image) ||
         .is_nonempty_scalar_chr(g$partition_within_image)))) {
    stop("matrispace: partition_within_image must be NA or one non-empty column name",
         call. = FALSE)
  }
  if (is.na(g$partition_within_image)) {
    if (any(!is.na(g$partition_ids))) {
      stop("matrispace: partition_ids must be NA when no within-image partition is used",
           call. = FALSE)
    }
  } else {
    if (!.is_nonempty_scalar_chr(g$partition_within_image) ||
        anyNA(g$partition_ids) || any(!nzchar(g$partition_ids))) {
      stop("matrispace: a within-image partition requires a column name and one ",
           "non-empty partition id per spot", call. = FALSE)
    }
  }
  # Missing replicate identity is represented ONLY by NA, never "".
  if (any(!is.na(g$replicate_ids) & !nzchar(g$replicate_ids))) {
    stop("matrispace: replicate_ids must not contain empty strings; use NA for ",
         "missing identity", call. = FALSE)
  }
  if (!(length(g$method) == 1L && g$method %in% c("knn", "radius", "delaunay"))) {
    stop("matrispace: graph method must be 'knn', 'radius', or 'delaunay'",
         call. = FALSE)
  }
  if (!identical(g$weight, "none")) {
    stop("matrispace: a stored base graph must have weight = 'none'", call. = FALSE)
  }
  if (!is.list(g$parameters) || !is.list(g$coordinate_system)) {
    stop("matrispace: graph parameters and coordinate_system must be lists",
         call. = FALSE)
  }
  if (!.is_nonempty_scalar_chr(g$coordinate_fingerprint)) {
    stop("matrispace: graph coordinate_fingerprint must be a non-empty string",
         call. = FALSE)
  }
  if (!is.logical(g$directed) || length(g$directed) != 1L || is.na(g$directed)) {
    stop("matrispace: graph 'directed' must be TRUE or FALSE", call. = FALSE)
  }
  # Matrices.
  C <- g$connectivities; D <- g$distances
  if (!methods::is(C, "CsparseMatrix") || !methods::is(D, "CsparseMatrix")) {
    stop("matrispace: connectivities/distances must be CsparseMatrix", call. = FALSE)
  }
  if (!identical(dim(C), c(n, n)) || !identical(dim(D), c(n, n))) {
    stop("matrispace: graph matrices must be n x n over spot_ids", call. = FALSE)
  }
  if (!identical(rownames(C), g$spot_ids) || !identical(colnames(C), g$spot_ids) ||
      !identical(rownames(D), g$spot_ids) || !identical(colnames(D), g$spot_ids)) {
    stop("matrispace: graph matrix dimnames must equal spot_ids", call. = FALSE)
  }
  if (any(Matrix::diag(C) != 0) || any(Matrix::diag(D) != 0)) {
    stop("matrispace: graph must have a zero diagonal", call. = FALSE)
  }
  if (!identical(C@i, D@i) || !identical(C@p, D@p)) {
    stop("matrispace: connectivity and distance matrices must share an edge pattern",
         call. = FALSE)
  }
  # Stored base connectivity is binary; spatial statistics trust these values.
  if (length(C@x) && any(C@x != 1)) {
    stop("matrispace: base connectivity values must all be 1 (weight = 'none')",
         call. = FALSE)
  }
  if (any(!is.finite(D@x)) || any(D@x < 0)) {
    stop("matrispace: edge distances must be finite and non-negative", call. = FALSE)
  }
  # Delaunay edges join distinct points (duplicates rejected at construction), so
  # every stored edge length is strictly positive.
  if (g$method == "delaunay" && length(D@x) && any(D@x <= 0)) {
    stop("matrispace: delaunay edge distances must be strictly positive",
         call. = FALSE)
  }
  # Direction / symmetrization consistency.
  if (g$directed) {
    if (!is.na(g$symmetrize)) {
      stop("matrispace: a directed graph must have symmetrize = NA", call. = FALSE)
    }
  } else {
    if (!Matrix::isSymmetric(C) || !Matrix::isSymmetric(D)) {
      stop("matrispace: an undirected graph must be symmetric", call. = FALSE)
    }
    if (g$method == "knn") {
      if (!(length(g$symmetrize) == 1L &&
            g$symmetrize %in% c("union", "mutual"))) {
        stop("matrispace: an undirected knn graph must record symmetrize as ",
             "'union' or 'mutual'",
             call. = FALSE)
      }
    } else if (!is.na(g$symmetrize)) {
      stop("matrispace: a ", g$method, " graph must have symmetrize = NA",
           call. = FALSE)
    }
  }
  # Delaunay-specific parameter shape.
  if (g$method == "delaunay") {
    p <- g$parameters
    if (!all(c("max_edge_distance", "engine", "engine_version") %in% names(p))) {
      stop("matrispace: a delaunay graph must record max_edge_distance, engine, ",
           "and engine_version parameters", call. = FALSE)
    }
    if (!identical(p$engine, "geometry::delaunayn")) {
      stop("matrispace: delaunay engine must be 'geometry::delaunayn'", call. = FALSE)
    }
    if (!.is_nonempty_scalar_chr(p$engine_version)) {
      stop("matrispace: delaunay engine_version must be a non-empty string",
           call. = FALSE)
    }
    med <- p$max_edge_distance
    if (!(length(med) == 1L && (is.na(med) || .is_finite_pos_scalar(med)))) {
      stop("matrispace: delaunay max_edge_distance must be NA or one finite ",
           "positive number", call. = FALSE)
    }
  }
  # Image blocking: no edge crosses an image boundary.
  if (length(C@x)) {
    img <- stats::setNames(as.character(g$image_ids), g$spot_ids)
    ij <- Matrix::which(C != 0, arr.ind = TRUE)
    if (any(img[g$spot_ids[ij[, 1]]] != img[g$spot_ids[ij[, 2]]])) {
      stop("matrispace: graph contains an edge crossing an image boundary",
           call. = FALSE)
    }
    if (!is.na(g$partition_within_image)) {
      part <- stats::setNames(g$partition_ids, g$spot_ids)
      if (any(part[g$spot_ids[ij[, 1]]] != part[g$spot_ids[ij[, 2]]])) {
        stop("matrispace: graph contains an edge crossing a within-image partition",
             call. = FALSE)
      }
    }
  }
  invisible(g)
}

# ---- Per-block neighbor search ----------------------------------------------

# Directed KNN within one coordinate frame, exact and near-linear. Ties at the
# k-th boundary are resolved by (distance, spot id) using ONE frNN query per
# tied-radius group, each at that group's own LOCAL radius -- never a single
# global tissue-spanning eps. Returns local edge triplets (i, j, d) in the input
# row indexing.
.knn_block <- function(coords, k) {
  n <- nrow(coords)
  k <- min(k, n - 1L)
  if (k < 1L) return(list(i = integer(0), j = integer(0), d = numeric(0)))
  ids <- rownames(coords)

  # k == n-1: every point connects to all others (kd-tree, no dense matrix).
  if (k == n - 1L) {
    knn <- dbscan::kNN(coords, k = k, sort = TRUE)
    ii <- rep.int(seq_len(n), rep.int(k, n))
    jj <- as.integer(t(knn$id))
    dd <- as.numeric(t(knn$dist))
    return(list(i = ii, j = jj, d = dd))
  }

  kq <- min(k + 1L, n - 1L)
  knn <- dbscan::kNN(coords, k = kq, sort = TRUE)
  dk <- knn$dist[, k]
  # A row is boundary-tied when its (k+1)-th distance equals its k-th distance.
  tied <- knn$dist[, k + 1L] == dk

  ii <- integer(0); jj <- integer(0); dd <- numeric(0)

  # Non-tied rows: the first k neighbors are the unambiguous nearest set.
  nt <- which(!tied)
  if (length(nt)) {
    idm <- knn$id[nt, seq_len(k), drop = FALSE]
    dm  <- knn$dist[nt, seq_len(k), drop = FALSE]
    ii <- c(ii, rep(nt, each = k))
    jj <- c(jj, as.integer(t(idm)))
    dd <- c(dd, as.numeric(t(dm)))
  }

  # Tied rows: group by their OWN k-th distance and run one frNN per radius
  # group, each at that group's LOCAL radius. This prevents a single isolated
  # tied row (huge k-th distance) from expanding every other tied query to a
  # tissue-spanning radius (which would be O(n^2) candidate storage). Then
  # select k per row by (distance, spot id).
  tr <- which(tied)
  if (length(tr)) {
    dk_tr <- dk[tr]
    radii <- unique(dk_tr)
    grp_id <- match(dk_tr, radii)
    for (gid in seq_along(radii)) {
      rows <- tr[grp_id == gid]
      eps <- radii[gid] * (1 + 1e-9)
      fr <- dbscan::frNN(coords, eps = eps, query = coords[rows, , drop = FALSE],
                         sort = TRUE)
      for (t in seq_along(rows)) {
        p <- rows[t]
        cand <- fr$id[[t]]; cd <- fr$dist[[t]]
        # frNN with a query returns the query's own point (distance 0) when it
        # coincides with a data point; exclude self.
        self <- cand != p
        cand <- cand[self]; cd <- cd[self]
        within <- cd <= dk[p] * (1 + 1e-12)
        cand <- cand[within]; cd <- cd[within]
        o <- order(cd, ids[cand])          # exact distance, then canonical id
        sel <- utils::head(o, k)
        ii <- c(ii, rep.int(p, length(sel)))
        jj <- c(jj, cand[sel])
        dd <- c(dd, cd[sel])
      }
    }
  }
  list(i = ii, j = jj, d = dd)
}

# Fixed-radius neighbors within one coordinate frame (naturally symmetric).
.radius_block <- function(coords, radius) {
  fr <- dbscan::frNN(coords, eps = radius, sort = FALSE)
  ii <- integer(0); jj <- integer(0); dd <- numeric(0)
  for (p in seq_along(fr$id)) {
    cand <- fr$id[[p]]
    if (!length(cand)) next
    ii <- c(ii, rep.int(p, length(cand)))
    jj <- c(jj, cand)
    dd <- c(dd, fr$dist[[p]])
  }
  list(i = ii, j = jj, d = dd)
}

# Delaunay neighbors within one coordinate frame (SPEC-EXT s3.2). Qhull via
# geometry::delaunayn returns triangle vertex indices; edges are the unique
# triangle sides. The caller passes a block already ordered by spot id, so the
# triangulation input is deterministic. Duplicate coordinates, degenerate
# (< 3-point or collinear) blocks are rejected with actionable, spot-named errors
# BEFORE calling Qhull. Returns BOTH directions of each retained undirected edge
# (like .radius_block) so the assembled matrix is symmetric with no dedup step.
.delaunay_block <- function(coords, max_edge_distance) {
  ids <- rownames(coords)
  n <- nrow(coords)
  # Distinct coordinates required: Qhull cannot triangulate coincident points,
  # and a zero-length Delaunay edge is meaningless. Name the first conflict.
  key <- paste0(coords[, 1], "\r", coords[, 2])
  dup <- which(duplicated(key))
  if (length(dup)) {
    first <- which(key == key[dup[1]])[1]
    stop("matrispace: delaunay requires distinct coordinates; spots '",
         ids[first], "' and '", ids[dup[1]], "' share the same coordinates",
         call. = FALSE)
  }
  if (n < 3L) {
    stop("matrispace: delaunay requires at least 3 spots per image/partition ",
         "block (got ", n, ")", call. = FALSE)
  }
  # A 2-D triangulation needs full column rank after centering; a collinear block
  # would otherwise silently switch to a degenerate definition or a Qhull error.
  if (qr(sweep(coords, 2, colMeans(coords)))$rank < 2L) {
    stop("matrispace: delaunay requires 2-D (non-collinear) coordinates in each ",
         "image/partition block", call. = FALSE)
  }
  # Use geometry::delaunayn's own documented default options (supplying an
  # options string would REPLACE, not extend, them). The default yields a
  # deterministic triangulated result.
  tri <- geometry::delaunayn(coords)
  ee <- rbind(tri[, c(1L, 2L)], tri[, c(1L, 3L)], tri[, c(2L, 3L)])
  a <- pmin.int(ee[, 1L], ee[, 2L]); b <- pmax.int(ee[, 1L], ee[, 2L])
  keep <- !duplicated(paste(a, b, sep = ":"))         # unique undirected edges
  a <- a[keep]; b <- b[keep]
  d <- sqrt((coords[a, 1L] - coords[b, 1L])^2 + (coords[a, 2L] - coords[b, 2L])^2)
  if (!is.null(max_edge_distance)) {
    within <- d <= max_edge_distance
    a <- a[within]; b <- b[within]; d <- d[within]
  }
  list(i = c(a, b), j = c(b, a), d = c(d, d))          # both directions
}

#' Build a spatial neighbor graph, partitioned by image, and store it.
#'
#' @param object A Seurat or SpatialExperiment object.
#' @param method `"knn"`, `"radius"`, or `"delaunay"`. Delaunay builds the
#'   undirected triangulation per image/partition block via `geometry::delaunayn`
#'   (Qhull) and ignores `k`/`radius`/`directed`/`symmetrize`.
#' @param k Number of neighbors (knn); a positive whole number.
#' @param radius Neighborhood radius (radius); a positive number.
#' @param graph_name Name to store the graph under.
#' @param directed knn only; if FALSE (default) the graph is union-symmetrized.
#' @param symmetrize Undirected knn only: `"union"` (default) or `"mutual"`.
#' @param partition_within_image Optional spot-metadata column used to split each
#'   image into smaller graph blocks. `image_id` always remains the outer safety
#'   boundary, so this can never connect different coordinate frames.
#' @param coordinate_units Optional single coordinate-units string.
#' @param max_edge_distance `delaunay` only: optional single finite positive
#'   distance; Delaunay edges longer than this are pruned (in `coordinate_units`).
#' @param ... Unused.
#' @return The object with the graph stored in its registry.
#' @export
build_spatial_graph <- function(object, method = c("knn", "radius", "delaunay"),
                                k = NULL, radius = NULL, graph_name,
                                directed = FALSE, symmetrize = "union",
                                partition_within_image = NULL,
                                coordinate_units = NULL,
                                max_edge_distance = NULL, ...) {
  method <- match.arg(method)
  if (missing(graph_name) || !.is_nonempty_scalar_chr(graph_name)) {
    stop("matrispace: build_spatial_graph() requires a single non-empty graph_name",
         call. = FALSE)
  }
  if (!is.logical(directed) || length(directed) != 1L || is.na(directed)) {
    stop("matrispace: 'directed' must be TRUE or FALSE", call. = FALSE)
  }
  if (!(is.character(symmetrize) && length(symmetrize) == 1L &&
        !is.na(symmetrize) && symmetrize %in% c("union", "mutual"))) {
    stop("matrispace: 'symmetrize' must be 'union' or 'mutual'", call. = FALSE)
  }
  symmetrize_explicit <- !missing(symmetrize)
  if (!is.null(partition_within_image) &&
      !.is_nonempty_scalar_chr(partition_within_image)) {
    stop("matrispace: 'partition_within_image' must be NULL or one metadata column",
         call. = FALSE)
  }
  if (!is.null(coordinate_units) && !.is_nonempty_scalar_chr(coordinate_units)) {
    stop("matrispace: 'coordinate_units' must be NULL or a single string", call. = FALSE)
  }
  if (method == "knn") {
    if (is.null(k) || length(k) != 1L || !is.finite(k) || k < 1 || k != round(k)) {
      stop("matrispace: knn graphs require a single whole-number k >= 1", call. = FALSE)
    }
    k <- as.integer(k)
  }
  if (method == "radius") {
    if (!.is_finite_pos_scalar(radius)) {
      stop("matrispace: radius graphs require a single positive radius", call. = FALSE)
    }
    if (directed) {
      stop("matrispace: radius graphs are naturally undirected; directed = TRUE ",
           "is not allowed.", call. = FALSE)
    }
    if (symmetrize_explicit) {
      stop("matrispace: radius graphs do not use knn symmetrization", call. = FALSE)
    }
  }
  if (method == "knn" && directed && symmetrize_explicit) {
    stop("matrispace: directed knn graphs cannot request symmetrization",
         call. = FALSE)
  }
  if (method == "delaunay") {
    if (!is.null(k)) {
      stop("matrispace: delaunay graphs do not use `k`", call. = FALSE)
    }
    if (!is.null(radius)) {
      stop("matrispace: delaunay graphs do not use `radius`", call. = FALSE)
    }
    if (directed) {
      stop("matrispace: delaunay graphs are undirected; directed = TRUE is not ",
           "allowed.", call. = FALSE)
    }
    if (symmetrize_explicit) {
      stop("matrispace: delaunay graphs do not use knn symmetrization", call. = FALSE)
    }
    if (!is.null(max_edge_distance) && !.is_finite_pos_scalar(max_edge_distance)) {
      stop("matrispace: 'max_edge_distance' must be NULL or one finite positive ",
           "number", call. = FALSE)
    }
  } else if (!is.null(max_edge_distance)) {
    stop("matrispace: 'max_edge_distance' is only valid for method = 'delaunay'",
         call. = FALSE)
  }

  spots <- colnames(object)
  if (is.null(spots) || length(spots) == 0L) {
    stop("matrispace: object has zero spots", call. = FALSE)
  }
  .validate_spot_ids(spots)
  membership <- .get_image_membership(object)[spots]   # errors on no/bad image
  coords <- .get_coordinates(object)[spots, , drop = FALSE]
  if (any(!is.finite(coords))) {
    stop("matrispace: coordinates contain non-finite values", call. = FALSE)
  }
  md <- .get_spot_metadata(object)
  partition_ids <- if (is.null(partition_within_image)) {
    rep(NA_character_, length(spots))
  } else {
    if (!(partition_within_image %in% colnames(md))) {
      stop("matrispace: partition column '", partition_within_image,
           "' not found in spot metadata", call. = FALSE)
    }
    x <- as.character(md[spots, partition_within_image])
    if (anyNA(x) || any(!nzchar(x))) {
      stop("matrispace: partition column '", partition_within_image,
           "' contains NA or empty labels", call. = FALSE)
    }
    x
  }
  replicate_ids <- if ("replicate_id" %in% colnames(md)) {
    as.character(md[spots, "replicate_id"])
  } else {
    rep(NA_character_, length(spots))
  }

  n <- length(spots)
  gi <- integer(0); gj <- integer(0); gd <- numeric(0)
  # The effective block is always image_id, optionally subdivided by a metadata
  # label. Length prefixes make the key injective without delimiter collisions.
  block_key <- paste0(nchar(membership), ":", membership)
  if (!is.null(partition_within_image)) {
    block_key <- paste0(block_key, "|", nchar(partition_ids), ":", partition_ids)
  }
  block_sizes <- integer(0)
  for (bk in unique(block_key)) {
    idx <- which(block_key == bk)
    # Delaunay: order the block by spot id so the Qhull input (and thus the
    # triangulation) is deterministic regardless of host ordering.
    if (method == "delaunay") idx <- idx[order(spots[idx])]
    block_sizes <- c(block_sizes, length(idx))
    block <- coords[idx, , drop = FALSE]
    e <- switch(method,
      knn      = .knn_block(block, k),
      radius   = .radius_block(block, radius),
      delaunay = .delaunay_block(block, max_edge_distance))
    if (length(e$i)) {
      gi <- c(gi, idx[e$i]); gj <- c(gj, idx[e$j]); gd <- c(gd, e$d)
    }
  }

  # Symmetrization. Union keeps either directed relation; mutual keeps only
  # reciprocal KNN relations. Integer-pair keys avoid string collisions.
  if (method == "knn" && !directed) {
    if (symmetrize == "union") {
      ai <- c(gi, gj); aj <- c(gj, gi); ad <- c(gd, gd)
      keep <- !duplicated(paste(ai, aj, sep = ":"))
      gi <- ai[keep]; gj <- aj[keep]; gd <- ad[keep]
    } else {
      key <- paste(gi, gj, sep = ":")
      reciprocal <- paste(gj, gi, sep = ":") %in% key
      gi <- gi[reciprocal]; gj <- gj[reciprocal]; gd <- gd[reciprocal]
    }
  } else {
    # radius and delaunay blocks already emit both directions (symmetric).
    symmetrize <- NA_character_
    directed <- if (method %in% c("radius", "delaunay")) FALSE else directed
  }

  connectivities <- Matrix::sparseMatrix(i = gi, j = gj, x = rep(1, length(gi)),
                                         dims = c(n, n),
                                         dimnames = list(spots, spots))
  distances <- Matrix::sparseMatrix(i = gi, j = gj, x = gd, dims = c(n, n),
                                    dimnames = list(spots, spots))

  coordinate_system <- list(units = coordinate_units %||% NA_character_,
                            axes = colnames(coords), source = .container_kind(object))
  fp <- .coordinate_fingerprint(
    spots, coords, membership, coordinate_system,
    partition_ids = if (is.null(partition_within_image)) NULL else partition_ids,
    partition_within_image = partition_within_image)

  k_capped <- method == "knn" && k > (min(block_sizes) - 1L)
  parameters <- switch(method,
    knn    = list(k = k, k_capped = k_capped),
    radius = list(radius = radius),
    delaunay = list(
      max_edge_distance = max_edge_distance %||% NA_real_,
      engine = "geometry::delaunayn",
      engine_version = as.character(utils::packageVersion("geometry"))))

  graph <- .new_matrispace_graph(
    connectivities = connectivities, distances = distances, spot_ids = spots,
    image_ids = unname(membership), replicate_ids = replicate_ids,
    partition_ids = partition_ids,
    partition_within_image = partition_within_image %||% NA_character_,
    method = method, parameters = parameters, directed = directed,
    symmetrize = symmetrize, coordinate_system = coordinate_system,
    coordinate_fingerprint = fp)
  .validate_matrispace_graph(graph)   # validate BEFORE storage

  reg <- .get_registry(object) %||% .new_registry()
  reg$graphs[[graph_name]] <- graph
  reg <- .registry_append_history(reg, "build_spatial_graph",
    list(method = method, k = if (method == "knn") k else NA_integer_,
         radius = if (method == "radius") radius else NA_real_,
         max_edge_distance = if (method == "delaunay") (max_edge_distance %||% NA_real_)
                             else NA_real_,
         directed = directed, symmetrize = symmetrize,
         partition_within_image = partition_within_image %||% NA_character_,
         coordinate_units = coordinate_units %||% NA_character_,
         n_images = length(unique(membership)), n_blocks = length(unique(block_key)),
         k_capped = isTRUE(k_capped),
         graph_name = graph_name))
  .set_registry(object, reg)
}

#' Retrieve a stored matrispace spatial graph by name (structurally validated).
#' @param object A Seurat or SpatialExperiment object.
#' @param name Graph name.
#' @return A `matrispace_graph` object.
#' @export
get_matrispace_graph <- function(object, name) {
  reg <- .get_registry(object)
  g <- if (is.null(reg)) NULL else reg$graphs[[name]]
  if (is.null(g)) {
    stop("matrispace: no spatial graph named '", name, "'. Available: ",
         paste(matrispace_graphs(object), collapse = ", "), call. = FALSE)
  }
  .validate_matrispace_graph(g)
  g
}

# Validate a graph structurally AND against the current host state. Every
# spatial analysis consumer should call this before using a graph.
#' @keywords internal
.validate_graph_against <- function(graph, object) {
  .validate_matrispace_graph(graph)
  spots <- colnames(object)
  membership <- .get_image_membership(object)[spots]
  coords <- .get_coordinates(object)[spots, , drop = FALSE]
  partition_ids <- NULL
  partition_name <- graph$partition_within_image
  if (!is.na(partition_name)) {
    md <- .get_spot_metadata(object)
    if (!(partition_name %in% colnames(md))) {
      stop("matrispace: graph is stale -- partition column '", partition_name,
           "' is absent from the object", call. = FALSE)
    }
    partition_ids <- as.character(md[spots, partition_name])
  }
  fp <- .coordinate_fingerprint(
    spots, coords, membership, graph$coordinate_system,
    partition_ids = partition_ids,
    partition_within_image = if (is.na(partition_name)) NULL else partition_name)
  if (!identical(fp, graph$coordinate_fingerprint)) {
    stop("matrispace: graph is stale -- the coordinate/spot fingerprint does not ",
         "match the object (coordinates changed, image membership changed, or ",
         "the object was subset).", call. = FALSE)
  }
  invisible(TRUE)
}

# ---- Weight transforms (SPEC s5.2) ------------------------------------------

# Validate that a distance matrix shares W's dimensions, dimnames, and edge
# pattern, and that its distances are finite and non-negative.
.validate_distance_against <- function(W, D) {
  if (!identical(dim(W), dim(D))) {
    stop("matrispace: distances must have the same dimensions as connectivity",
         call. = FALSE)
  }
  if (!identical(dimnames(W), dimnames(D))) {
    stop("matrispace: distances and connectivity must share dimnames", call. = FALSE)
  }
  if (!identical(W@i, D@i) || !identical(W@p, D@p)) {
    stop("matrispace: distances and connectivity must share the same edge pattern",
         call. = FALSE)
  }
  if (any(!is.finite(D@x)) || any(D@x < 0)) {
    stop("matrispace: edge distances must be finite and non-negative", call. = FALSE)
  }
  invisible(TRUE)
}

#' Transform a base connectivity graph into weighted edges.
#' @param W A sparse connectivity matrix.
#' @param distances A sparse edge-distance matrix (required for distance methods).
#' @param method "binary", "row_standardize", "inverse_distance", or "gaussian".
#' @param sigma Gaussian kernel bandwidth (required, positive, for "gaussian").
#' @param eps Optional positive epsilon for inverse-distance on zero-distance edges.
#' @return A sparse weighted matrix with the same nonzero pattern.
#' @export
transform_weights <- function(W, distances = NULL,
                              method = c("binary", "row_standardize",
                                         "inverse_distance", "gaussian"),
                              sigma = NULL, eps = NULL) {
  method <- match.arg(method)
  W <- methods::as(W, "CsparseMatrix")

  if (method == "binary") {
    W@x <- rep(1, length(W@x))
    return(W)
  }
  if (method == "row_standardize") {
    rs <- Matrix::rowSums(W)
    rs[rs == 0] <- 1
    return(methods::as(Matrix::Diagonal(x = 1 / rs) %*% W, "CsparseMatrix"))
  }

  # Distance-based methods: validate D against W first.
  if (is.null(distances)) {
    stop("matrispace: method '", method, "' requires `distances`", call. = FALSE)
  }
  D <- methods::as(distances, "CsparseMatrix")
  .validate_distance_against(W, D)
  d <- D@x

  if (method == "inverse_distance") {
    if (is.null(eps)) {
      # No regularization: every edge distance must be strictly positive.
      if (any(d <= 0)) {
        stop("matrispace: inverse_distance requires strictly positive edge ",
             "distances; pass `eps` to regularize.", call. = FALSE)
      }
      D@x <- 1 / d
    } else {
      # Regularized: apply 1/(d + eps) to EVERY edge so the parameter's meaning
      # does not depend on whether some edge happens to be zero.
      if (!.is_finite_pos_scalar(eps)) {
        stop("matrispace: `eps` must be a single positive number", call. = FALSE)
      }
      D@x <- 1 / (d + eps)
    }
    return(D)
  }

  # gaussian
  if (!.is_finite_pos_scalar(sigma)) {
    stop("matrispace: gaussian weighting requires a single positive `sigma`",
         call. = FALSE)
  }
  # Clamp to the smallest positive double so large d/sigma does not underflow to
  # zero and silently drop edges (SPEC s6.5: the edge pattern is preserved).
  D@x <- pmax(exp(-(d^2) / (2 * sigma^2)), .Machine$double.xmin)
  D
}
