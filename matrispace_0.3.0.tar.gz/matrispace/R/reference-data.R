# Bundled reference data. These objects are generated deterministically by
# data-raw/build-reference-data.R from a commit-pinned snapshot of the
# authoritative MatriSpace application repository. Runtime code never reads
# Excel files or contacts the network.

# Package data referenced in public function defaults are resolved from the
# lazy-data database at runtime. Declare them for static code analysis.
utils::globalVariables(c(
  "matrisome_db", "matrisome_signatures", "ecm_markers", "ecm_signatures",
  "matrisome_pairs", "reference_data_manifest", "matrisome_signature_manifest"))

#' Human matrisome reference
#'
#' A cleaned, one-row-per-gene human matrisome definition. The first two
#' columns (`gene`, `category`) intentionally match the differential-expression
#' reference contract; remaining columns retain useful source annotation.
#'
#' @format A data frame with columns `gene`, `category`, `division`,
#'   `subcategory`, `gene_name`, `synonyms`, `hgnc_id`, `uniprot_ids`, and
#'   `refseq_ids`.
#' @source [MatriSpace authoritative repository](https://github.com/Theayomideo/matrispace-app)
#' @usage matrisome_db
"matrisome_db"

#' Matrisome scoring signatures
#'
#' Deterministically derived category, subcategory, and family signatures from
#' `matrisome_db`. Names are stable snake_case machine keys.
#'
#' @format A uniquely named list of character vectors containing HGNC symbols.
#' @source Derived from `matrisome_db`.
#' @usage matrisome_signatures
"matrisome_signatures"

#' Matrisome signature discoverability manifest
#'
#' One row per bundled [matrisome_signatures] key, distinguishing the six broad
#' ECM categories (`level = "category"`) from the narrower families/programs
#' (`level = "subcategory"`). Query it through [list_matrisome_signatures()] and
#' use the `key` values with `score_matrisome(include = ...)`. Generated
#' deterministically by `data-raw/build-signature-manifest.R` from the sealed
#' reference objects.
#'
#' @format A data frame with columns `key`, `label`, `level`, `category`,
#'   `n_genes`, and `reference_version`.
#' @source Derived from `matrisome_signatures` and `matrisome_db`.
#' @usage matrisome_signature_manifest
"matrisome_signature_manifest"

#' ECM niche markers
#'
#' ScType-style ECM niche marker definitions. Each niche contains `positive`
#' and `negative` HGNC-symbol vectors. Negative vectors are intentionally empty
#' in this reference version.
#'
#' @format A named list (`interstitial`, `basement`, `vascular`), each containing
#'   `positive` and `negative` character vectors.
#' @source [MatriSpace authoritative repository](https://github.com/Theayomideo/matrispace-app)
#' @usage ecm_markers
"ecm_markers"

#' ECM niche scoring signatures
#'
#' Curated continuous-scoring signatures supplied by the authoritative app.
#' Vascular is a classification marker set, not a continuous signature, in the
#' current source snapshot.
#'
#' @format A named list with `interstitial` and `basement` HGNC-symbol vectors.
#' @source [MatriSpace authoritative repository](https://github.com/Theayomideo/matrispace-app)
#' @usage ecm_signatures
"ecm_signatures"

#' MatriComDB matrisome pairs
#'
#' One row per unique heterotypic pair from MatriComDB in which at least one
#' member is a matrisome gene. Reciprocal records are collapsed to one
#' alphabetically ordered pair (`gene_1` < `gene_2`), homomeric records are
#' excluded, and evidence from collapsed records is aggregated without losing
#' source attribution. The source data include ligand-receptor relationships and
#' structural ECM interactions; a row should not be read as signalling unless
#' its annotation supports that.
#'
#' @format A data frame with columns `gene_1`, `gene_2`, `interaction_type`,
#'   `source`, `database_score`, `evidence_count`, and `source_count`.
#' @source MatriComDB snapshot distributed by the
#'   [MatriSpace authoritative repository](https://github.com/Theayomideo/matrispace-app).
#' @usage matrisome_pairs
"matrisome_pairs"

#' Reference-data provenance manifest
#'
#' Build provenance for every bundled reference object, including the pinned
#' source commit and checksums, species, identifier convention, transformation
#' version, schema, and row-count audit.
#'
#' @format A data frame with one row per bundled reference object.
#' @usage reference_data_manifest
"reference_data_manifest"
