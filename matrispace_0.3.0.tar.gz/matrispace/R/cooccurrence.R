# Distance-binned categorical co-occurrence (SPATIAL_EXTENSIONS_IMPLEMENTATION
# _SPEC s4). A Squidpy-compatible descriptive association ratio
# P(to | from, distance) / P(to | distance), extended with annular bins, strict
# image isolation, physical-unit scaling, and two explicit multi-image estimands.
# This file implements the DESCRIPTIVE kernel (n_perm = 0); within-image
# permutation inference and plotting arrive in the next checkpoint.

.cooccurrence_version <- "1.0.0"

# Per-image ANNULAR count array C[a, b, m] (K x K x B) of ordered distinct-spot
# pairs with focal category a, neighbor b, and Euclidean distance in annular bin
# m = (breaks[m], breaks[m+1]]. Every eligible unordered pair contributes BOTH
# directions (so a self-category pair increments C[a,a] twice). Memory is bounded
# to a chunk x chunk working block -- never an n x n or condensed distance object.
.cooccurrence_counts_image <- function(coords, cat_int, breaks, K, chunk_size) {
  n <- nrow(coords)
  B <- length(breaks) - 1L
  counts <- array(0, dim = c(K, K, B))
  maxd <- breaks[length(breaks)]
  x <- coords[, 1L]; y <- coords[, 2L]
  starts <- seq.int(1L, n, by = chunk_size)
  for (bi in starts) {
    I <- bi:min(bi + chunk_size - 1L, n)
    for (bj in starts) {
      if (bj < bi) next                              # upper-triangle blocks only
      J <- bj:min(bj + chunk_size - 1L, n)
      # |I| x |J| working distance block (bounded by chunk_size^2).
      D <- sqrt(outer(x[I], x[J], "-")^2 + outer(y[I], y[J], "-")^2)
      if (bi == bj) {
        sel <- which(upper.tri(D) & D > 0 & D <= maxd) # local p < q, no self-pair
      } else {
        sel <- which(D > 0 & D <= maxd)                # every I<J pair
      }
      if (!length(sel)) next
      rc <- arrayInd(sel, dim(D))
      cp <- cat_int[I[rc[, 1L]]]; cq <- cat_int[J[rc[, 2L]]]
      m <- findInterval(D[sel], breaks, left.open = TRUE)   # 1..B
      # Accumulate both ordered directions via a compact linear-index tabulation.
      lin1 <- cp + (cq - 1L) * K + (m - 1L) * K * K
      lin2 <- cq + (cp - 1L) * K + (m - 1L) * K * K
      counts <- counts + array(tabulate(c(lin1, lin2), K * K * B),
                               dim = c(K, K, B))
    }
  }
  counts
}

# Annular -> reported bins: identity for "annular"; cumulative prefix sum along
# the bin axis for "cumulative" (bin r covers (0, breaks[r+1]]).
.cooccurrence_apply_mode <- function(arr, mode, B) {
  if (mode == "annular" || B < 2L) return(arr)
  for (r in 2:B) arr[, , r] <- arr[, , r] + arr[, , r - 1L]
  arr
}

# Descriptive quantities from a (mode-applied) count array: conditional[a,b,r] =
# C[a,b,r]/C[a,.,r]; marginal[b,r] = C[.,b,r]/C[.,.,r]; ratio = conditional /
# marginal. Undefined denominators -> NA; a zero conditional over a positive
# marginal -> ratio 0 (log2 = -Inf downstream), never coerced to a finite value.
.cooccurrence_stats <- function(cm, K, B) {
  Crow <- apply(cm, c(1L, 3L), sum)                  # K x B  (C[a,.,r])
  Ccol <- apply(cm, c(2L, 3L), sum)                  # K x B  (C[.,b,r])
  Ctot <- apply(cm, 3L, sum)                         # B      (C[.,.,r])
  cond <- array(NA_real_, dim = c(K, K, B))
  marg <- array(NA_real_, dim = c(K, K, B))
  for (r in seq_len(B)) {
    for (a in seq_len(K)) {
      if (Crow[a, r] > 0) cond[a, , r] <- cm[a, , r] / Crow[a, r]
    }
    if (Ctot[r] > 0) {
      mr <- Ccol[, r] / Ctot[r]
      for (a in seq_len(K)) marg[a, , r] <- mr
    }
  }
  ratio <- cond / marg
  ratio[is.nan(ratio)] <- NA_real_                   # 0/0 (undefined marginal)
  ratio[is.infinite(ratio)] <- NA_real_             # guard positive/0
  list(conditional = cond, marginal = marg, ratio = ratio,
       Crow = Crow, Ctot = Ctot)
}

# Mean / SD / count across the image axis (margin 4) ignoring NA; an all-NA cell
# yields NA mean and NA SD (< 2 defined images).
.cooccurrence_across_images <- function(stack) {
  mean_na <- function(v) { u <- v[!is.na(v)]; if (!length(u)) NA_real_ else mean(u) }
  sd_na   <- function(v) { u <- v[!is.na(v)]; if (length(u) < 2L) NA_real_ else stats::sd(u) }
  list(
    mean  = apply(stack, c(1L, 2L, 3L), mean_na),
    sd    = apply(stack, c(1L, 2L, 3L), sd_na),
    n_def = apply(stack, c(1L, 2L, 3L), function(v) sum(!is.na(v))))
}

# Aggregated ratio array (K x K x B) under the chosen mode + aggregation. Used
# for the observed statistic AND for each permutation, so both go through exactly
# the same estimand path.
.cooccurrence_ratio_array <- function(counts_by_image, mode, aggregation, K, B) {
  if (aggregation == "pooled_pairs") {
    cm <- .cooccurrence_apply_mode(Reduce(`+`, counts_by_image), mode, B)
    return(.cooccurrence_stats(cm, K, B)$ratio)
  }
  n <- length(counts_by_image)
  stack <- array(NA_real_, dim = c(K, K, B, n))
  for (t in seq_len(n)) {
    stack[, , , t] <-
      .cooccurrence_stats(.cooccurrence_apply_mode(counts_by_image[[t]], mode, B),
                          K, B)$ratio
  }
  .cooccurrence_across_images(stack)$mean
}

#' Distance-binned categorical co-occurrence.
#'
#' Computes the Squidpy-compatible association ratio
#' `P(to | from, distance) / P(to | distance)` for a spot-metadata grouping,
#' in annular or cumulative distance bins, with strict per-image isolation and
#' two explicit multi-image estimands. Returns a tidy `data.frame` and never
#' mutates the object. With `n_perm > 0` a within-image label-permutation null
#' (random labeling at fixed locations) adds empirical p-values.
#'
#' @param object A Seurat or SpatialExperiment object.
#' @param group_by One spot-metadata column naming the categories.
#' @param distance_breaks Numeric, finite, strictly increasing, non-negative
#'   breaks with at least two values; the first must be `0`.
#' @param image_id `NULL` (all images) or one image to restrict to.
#' @param mode `"annular"` (default) bins are `(break[r], break[r+1]]`;
#'   `"cumulative"` bins are `(0, break[r+1]]`.
#' @param aggregation `"pooled_pairs"` (default) sums counts across images before
#'   forming the ratio; `"equal_image"` averages per-image ratios equally.
#' @param distance_scale `NULL` (scale 1, single image) or a named positive
#'   numeric vector with one entry per analyzed image, mapping stored coordinates
#'   into a common physical unit. Stored coordinates are never modified.
#' @param coordinate_units Required whenever `distance_scale` is supplied or more
#'   than one image is analyzed.
#' @param n_perm Non-negative whole number of within-image label permutations
#'   (`0` = descriptive only). The null shuffles labels within each image
#'   (preserving per-image category counts and geometry) and yields one-sided
#'   enrichment/depletion empirical p-values using the plus-one correction
#'   `(extreme + 1)/(n_perm + 1)`. A cell's p-values are reported only when the
#'   observed ratio and every permuted ratio for that cell are defined; otherwise
#'   they are `NA`, so the denominator is always exactly `n_perm` plus one.
#' @param seed Single whole number seeding the permutation stream (reproducible,
#'   independent of `chunk_size`).
#' @param chunk_size Positive whole number; the pair-counting block size.
#' @param ... Must be empty; unknown arguments are rejected.
#' @return A tidy `data.frame` (one row per ordered category pair and reported
#'   bin) with a `matrispace` provenance attribute.
#' @export
compute_cooccurrence <- function(object, group_by, distance_breaks,
                                 image_id = NULL,
                                 mode = c("annular", "cumulative"),
                                 aggregation = c("pooled_pairs", "equal_image"),
                                 distance_scale = NULL, coordinate_units = NULL,
                                 n_perm = 0L, seed = 1L, chunk_size = 512L, ...) {
  mode <- match.arg(mode)
  aggregation <- match.arg(aggregation)
  dots <- list(...)
  if (length(dots)) {
    stop("matrispace: unknown argument(s): ",
         paste(names(dots) %||% "", collapse = ", "), call. = FALSE)
  }
  if (!.is_nonempty_scalar_chr(group_by)) {
    stop("matrispace: `group_by` must be a single metadata column name", call. = FALSE)
  }
  # distance_breaks
  if (!(is.numeric(distance_breaks) && length(distance_breaks) >= 2L &&
        all(is.finite(distance_breaks)))) {
    stop("matrispace: `distance_breaks` must be a finite numeric vector with at ",
         "least two values", call. = FALSE)
  }
  if (is.unsorted(distance_breaks, strictly = TRUE)) {
    stop("matrispace: `distance_breaks` must be strictly increasing", call. = FALSE)
  }
  if (any(distance_breaks < 0)) {
    stop("matrispace: `distance_breaks` must be non-negative", call. = FALSE)
  }
  if (distance_breaks[1] != 0) {
    stop("matrispace: the first distance break must be 0", call. = FALSE)
  }
  breaks <- as.numeric(distance_breaks)
  B <- length(breaks) - 1L
  # n_perm / seed / chunk_size: range-safe whole-number scalars (reject
  # logical/list/character and out-of-integer-range values before as.integer()).
  if (!.is_whole_scalar(n_perm, min = 0)) {
    stop("matrispace: `n_perm` must be a non-negative whole number", call. = FALSE)
  }
  n_perm <- as.integer(n_perm)
  if (!.is_whole_scalar(seed)) {
    stop("matrispace: `seed` must be a single whole number", call. = FALSE)
  }
  if (!.is_pos_whole(chunk_size)) {
    stop("matrispace: `chunk_size` must be a positive whole number", call. = FALSE)
  }
  chunk_size <- as.integer(chunk_size)

  # Images to analyze.
  membership <- .get_image_membership(object)
  all_images <- unique(unname(membership))
  if (!is.null(image_id)) {
    if (!.is_nonempty_scalar_chr(image_id) || !(image_id %in% all_images)) {
      stop("matrispace: unknown image_id '", image_id, "'; available: ",
           paste(all_images, collapse = ", "), call. = FALSE)
    }
    analyzed_images <- image_id
  } else {
    analyzed_images <- all_images
  }
  n_analyzed <- length(analyzed_images)

  # distance_scale + coordinate_units.
  if (is.null(distance_scale)) {
    if (n_analyzed > 1L) {
      stop("matrispace: `distance_scale` is required when analyzing more than one ",
           "image; supply a named positive numeric vector over: ",
           paste(analyzed_images, collapse = ", "), call. = FALSE)
    }
    scale_vec <- stats::setNames(1, analyzed_images)
  } else {
    if (!(is.numeric(distance_scale) && length(distance_scale) == n_analyzed &&
          !is.null(names(distance_scale)) && all(is.finite(distance_scale)) &&
          all(distance_scale > 0))) {
      stop("matrispace: `distance_scale` must be a named positive finite numeric ",
           "vector with one entry per analyzed image", call. = FALSE)
    }
    if (anyDuplicated(names(distance_scale)) ||
        !setequal(names(distance_scale), analyzed_images)) {
      stop("matrispace: `distance_scale` names must be exactly the analyzed ",
           "image(s), each once: ", paste(analyzed_images, collapse = ", "),
           call. = FALSE)
    }
    scale_vec <- distance_scale[analyzed_images]
  }
  if ((!is.null(distance_scale) || n_analyzed > 1L) &&
      !.is_nonempty_scalar_chr(coordinate_units)) {
    stop("matrispace: `coordinate_units` is required whenever `distance_scale` is ",
         "supplied or more than one image is analyzed", call. = FALSE)
  }
  units_out <- coordinate_units %||% NA_character_

  # Categories: global (numeric-aware, blank/NA-excluded) order over analyzed
  # spots, so the K x K structure is consistent across images.
  md <- .get_spot_metadata(object)
  if (!(group_by %in% colnames(md))) {
    stop("matrispace: group_by column '", group_by, "' not found", call. = FALSE)
  }
  analyzed_spots <- names(membership)[unname(membership) %in% analyzed_images]
  categories <- levels(droplevels(.group_factor(md[analyzed_spots, group_by])))
  K <- length(categories)
  if (K < 1L) {
    stop("matrispace: no categories in '", group_by, "' among the analyzed image(s)",
         call. = FALSE)
  }

  coords_all <- .get_coordinates(object)
  counts_by_image <- vector("list", n_analyzed)
  names(counts_by_image) <- analyzed_images
  coords_kept <- vector("list", n_analyzed); names(coords_kept) <- analyzed_images
  cat_kept <- vector("list", n_analyzed); names(cat_kept) <- analyzed_images
  usable_spots <- stats::setNames(integer(n_analyzed), analyzed_images)
  omitted_labels <- stats::setNames(integer(n_analyzed), analyzed_images)
  coord_fps <- stats::setNames(character(n_analyzed), analyzed_images)

  for (img in analyzed_images) {
    spots_i <- names(membership)[unname(membership) == img]
    cat_i <- match(as.character(md[spots_i, group_by]), categories)  # NA = excluded
    keep <- !is.na(cat_i)
    omitted_labels[img] <- sum(!keep)
    spots_k <- spots_i[keep]
    if (length(spots_k) < 2L) {
      stop("matrispace: image '", img, "' has fewer than 2 labelled spots",
           call. = FALSE)
    }
    coords_i <- coords_all[spots_k, , drop = FALSE] * scale_vec[[img]]
    # Validate coordinates AFTER subsetting + scaling (the Seurat accessor does
    # not guarantee finiteness, and a large scale factor can overflow to Inf).
    # Otherwise a spot with NA/Inf coordinates would be reported usable while all
    # of its pairs are silently dropped.
    finite_row <- is.finite(coords_i[, 1L]) & is.finite(coords_i[, 2L])
    if (!all(finite_row)) {
      bad <- spots_k[!finite_row]
      stop("matrispace: image '", img, "' has non-finite coordinates after ",
           "scaling (e.g. spot '", bad[1], "'); check the coordinates and ",
           "distance_scale.", call. = FALSE)
    }
    cnt <- .cooccurrence_counts_image(coords_i, cat_i[keep], breaks, K, chunk_size)
    if (sum(cnt) == 0) {
      stop("matrispace: image '", img, "' has no eligible spot pair within the ",
           "distance breaks (max = ", breaks[length(breaks)], ")", call. = FALSE)
    }
    counts_by_image[[img]] <- cnt
    coords_kept[[img]] <- coords_i
    cat_kept[[img]] <- cat_i[keep]
    usable_spots[img] <- length(spots_k)
    ord <- order(spots_k)
    coord_fps[img] <- digest::digest(
      list(spots = spots_k[ord], coords = coords_i[ord, , drop = FALSE],
           scale = unname(scale_vec[[img]])), algo = "xxhash64")
  }

  # Pooled counts (for n_pairs context and the pooled_pairs estimand).
  pooled_mode <- .cooccurrence_apply_mode(Reduce(`+`, counts_by_image), mode, B)
  ps <- .cooccurrence_stats(pooled_mode, K, B)

  if (aggregation == "pooled_pairs") {
    cond <- ps$conditional; marg <- ps$marginal; ratio <- ps$ratio
    ratio_sd_arr <- array(NA_real_, dim = c(K, K, B))
    n_used_arr <- array(n_analyzed, dim = c(K, K, B))
  } else {
    per <- lapply(counts_by_image, function(c0)
      .cooccurrence_stats(.cooccurrence_apply_mode(c0, mode, B), K, B))
    stack_of <- function(field) {
      s <- array(NA_real_, dim = c(K, K, B, n_analyzed))
      for (t in seq_len(n_analyzed)) s[, , , t] <- per[[t]][[field]]
      s
    }
    rr <- .cooccurrence_across_images(stack_of("ratio"))
    ratio <- rr$mean; ratio_sd_arr <- rr$sd; n_used_arr <- rr$n_def
    cond <- .cooccurrence_across_images(stack_of("conditional"))$mean
    marg <- .cooccurrence_across_images(stack_of("marginal"))$mean
  }

  # Within-image label-permutation null (SPEC-EXT s4.5). Labels are shuffled
  # WITHIN each image (preserving per-image category counts and fixed geometry);
  # each permuted replicate is aggregated by the SAME estimand as the observed
  # statistic. The seeded stream is drawn before counting, so p-values do not
  # depend on chunk_size or scheduling. Inference for a cell is reported ONLY
  # where the observed ratio is defined AND all `n_perm` permutations also define
  # it, so the empirical denominator is exactly `n_perm + 1` (no hidden
  # cell-specific effective sample size). A cell that any permutation leaves
  # undefined (e.g. a rare category with too few pairs) is returned NA rather
  # than silently using a smaller conditional denominator.
  p_enrich_arr <- array(NA_real_, dim = c(K, K, B))
  p_deplete_arr <- array(NA_real_, dim = c(K, K, B))
  p_value_arr <- array(NA_real_, dim = c(K, K, B))
  if (n_perm > 0L) {
    obs_ratio <- ratio
    tally <- .with_seed(seed, {
      ge <- le <- nv <- array(0, dim = c(K, K, B))
      for (p in seq_len(n_perm)) {
        pc <- lapply(analyzed_images, function(img) {
          ci <- cat_kept[[img]]
          .cooccurrence_counts_image(coords_kept[[img]], ci[sample.int(length(ci))],
                                     breaks, K, chunk_size)
        })
        names(pc) <- analyzed_images
        pr <- .cooccurrence_ratio_array(pc, mode, aggregation, K, B)
        d <- !is.na(pr) & !is.na(obs_ratio)
        nv[d] <- nv[d] + 1L
        ge[d & pr >= obs_ratio] <- ge[d & pr >= obs_ratio] + 1L
        le[d & pr <= obs_ratio] <- le[d & pr <= obs_ratio] + 1L
      }
      list(ge = ge, le = le, nv = nv)
    })
    full <- !is.na(obs_ratio) & (tally$nv == n_perm)   # every permutation defined
    p_enrich_arr[full] <- (tally$ge[full] + 1) / (n_perm + 1)
    p_deplete_arr[full] <- (tally$le[full] + 1) / (n_perm + 1)
    p_value_arr <- pmin(1, 2 * pmin(p_enrich_arr, p_deplete_arr))
  }

  # Assemble one row per ordered (from = a, to = b) pair and reported bin r.
  g <- expand.grid(r = seq_len(B), b = seq_len(K), a = seq_len(K))
  lin <- g$a + (g$b - 1L) * K + (g$r - 1L) * K * K
  dmin <- if (mode == "annular") breaks[g$r] else rep(0, nrow(g))
  dmax <- breaks[g$r + 1L]
  df <- data.frame(
    from = categories[g$a], to = categories[g$b],
    distance_min = dmin, distance_max = dmax, distance_mid = (dmin + dmax) / 2,
    mode = mode, aggregation = aggregation, coordinate_units = units_out,
    conditional_probability = cond[lin], marginal_probability = marg[lin],
    ratio = ratio[lin], log2_ratio = log2(ratio[lin]),
    n_pairs_from = ps$Crow[cbind(g$a, g$r)], n_pairs_total = ps$Ctot[g$r],
    n_images_used = n_used_arr[lin], ratio_sd = ratio_sd_arr[lin],
    n_perm = n_perm, seed = as.integer(seed),
    p_enrich = p_enrich_arr[lin], p_deplete = p_deplete_arr[lin],
    p_value = p_value_arr[lin], p_adjusted = NA_real_,
    stringsAsFactors = FALSE, row.names = NULL)
  # BH adjustment over every DEFINED ordered-pair x bin test in the returned
  # family (SPEC-EXT s4.5).
  if (n_perm > 0L) {
    def <- !is.na(df$p_value)
    if (any(def)) df$p_adjusted[def] <- stats::p.adjust(df$p_value[def], "BH")
  }
  # Preserve the natural category order for from/to.
  df$from <- factor(df$from, levels = categories)
  df$to <- factor(df$to, levels = categories)

  attr(df, "matrispace") <- list(
    producer = "compute_cooccurrence", version = .cooccurrence_version,
    group_by = group_by, categories = categories, distance_breaks = breaks,
    distance_scale = scale_vec, coordinate_units = units_out,
    mode = mode, aggregation = aggregation, images = analyzed_images,
    usable_spots = usable_spots, omitted_labels = omitted_labels,
    coordinate_fingerprints = coord_fps, n_perm = n_perm, seed = as.integer(seed),
    chunk_size = chunk_size)
  df
}
