#' matrispace: spatially-resolved ECM gene expression analysis
#'
#' Matrisome scoring, ECM niche annotation, spatial statistics, and
#' matrisome-pair co-expression for Seurat and SpatialExperiment objects.
#'
#' @keywords internal
#' @importFrom rlang .data
"_PACKAGE"
