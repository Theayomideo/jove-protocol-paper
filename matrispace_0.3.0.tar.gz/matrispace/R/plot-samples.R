#' Compare sample-level values between two groups.
#'
#' Box plots with one point per sample, faceted by feature, as used for
#' cohort comparisons in the MatriSpace protocol. Use it on values that have
#' already been summarised to one row per biological sample (for example a
#' donor), not on individual spots. Whiskers span the observed range.
#'
#' @param data A data.frame with one row per sample, a grouping column and one
#'   numeric column per feature.
#' @param features Character vector of numeric columns to plot.
#' @param group Grouping column with exactly two groups, shown in factor-level
#'   order or, for character columns, in order of first appearance.
#' @param p_values Optional P values, one per feature, drawn above each panel.
#' @param labels Optional facet labels: a function applied to `features` or a
#'   character vector named by feature.
#' @param group_labels Optional x-axis labels named by group.
#' @param colours Optional box fill colours, preferably named by group.
#' @param y_label Y-axis title.
#' @param ncol Maximum number of facet columns.
#' @param italic Italicise facet labels (for gene names).
#' @param ... Must be empty.
#' @return A ggplot.
#' @export
plot_sample_comparison <- function(data, features, group = "condition",
                                   p_values = NULL, labels = NULL,
                                   group_labels = NULL, colours = NULL,
                                   y_label = "Value", ncol = 3L,
                                   italic = FALSE, ...) {
  if (...length()) {
    stop("matrispace: unknown argument(s) passed to plot_sample_comparison()",
         call. = FALSE)
  }
  if (!is.data.frame(data)) stop("matrispace: `data` must be a data.frame", call. = FALSE)
  if (!is.character(features) || !length(features) || !all(features %in% names(data))) {
    stop("matrispace: `features` must name columns of `data`", call. = FALSE)
  }
  if (!all(vapply(data[features], is.numeric, logical(1)))) {
    stop("matrispace: `features` must be numeric columns", call. = FALSE)
  }
  if (!.is_nonempty_scalar_chr(group) || !(group %in% names(data))) {
    stop("matrispace: `group` must name a column of `data`", call. = FALSE)
  }
  # Factor levels are kept; otherwise groups appear in data order.
  g <- data[[group]]
  lev <- if (is.factor(g)) levels(droplevels(g)) else unique(as.character(g[!is.na(g)]))
  if (length(lev) != 2L) {
    stop("matrispace: `group` must contain exactly two groups", call. = FALSE)
  }
  if (!is.null(p_values) && !(is.numeric(p_values) && length(p_values) == length(features))) {
    stop("matrispace: `p_values` must be NULL or one number per feature", call. = FALSE)
  }
  if (!(is.numeric(ncol) && length(ncol) == 1L && ncol >= 1)) {
    stop("matrispace: `ncol` must be one positive number", call. = FALSE)
  }
  facet <- if (is.null(labels)) features else .axis_labeller(labels, "labels")(features)
  fill <- .annotation_colours(factor(lev, levels = lev),
                              colours %||% c("#9DB4D3", "#22336B"))

  long <- do.call(rbind, lapply(seq_along(features), function(i) data.frame(
    feature = facet[i], group = factor(as.character(g), levels = lev),
    value = data[[features[i]]], stringsAsFactors = FALSE)))
  long$feature <- factor(long$feature, levels = unique(facet))

  p <- ggplot2::ggplot(long, ggplot2::aes(x = .data[["group"]], y = .data[["value"]])) +
    ggplot2::geom_boxplot(ggplot2::aes(fill = .data[["group"]]), width = 0.5,
                          coef = Inf, outlier.shape = NA, colour = "black") +
    ggplot2::geom_point(shape = 21, fill = "white", size = 2) +
    ggplot2::facet_wrap(~ feature, scales = "free_y",
                        ncol = min(as.integer(ncol), length(features)),
                        labeller = ggplot2::label_wrap_gen(width = 18)) +
    ggplot2::scale_fill_manual(values = fill) +
    ggplot2::scale_y_continuous(expand = ggplot2::expansion(mult = c(0.05, 0.2))) +
    ggplot2::labs(x = NULL, y = y_label) +
    ggplot2::theme_classic(base_size = 11) +
    ggplot2::theme(strip.background = ggplot2::element_blank(),
                   strip.text = ggplot2::element_text(
                     size = 10, face = if (isTRUE(italic)) "italic" else "plain"),
                   axis.text = ggplot2::element_text(colour = "black"),
                   legend.position = "none")
  if (!is.null(group_labels)) {
    p <- p + ggplot2::scale_x_discrete(labels = .axis_labeller(group_labels, "group_labels"))
  }
  if (!is.null(p_values)) {
    top <- tapply(long$value, long$feature, max, na.rm = TRUE)
    span <- tapply(long$value, long$feature, function(v) diff(range(v, na.rm = TRUE)))
    ann <- data.frame(feature = factor(names(top), levels = levels(long$feature)),
                      y = as.numeric(top + 0.12 * span),
                      label = sprintf("P = %.2g", p_values[match(names(top), unique(facet))]))
    p <- p +
      ggplot2::geom_segment(data = ann, ggplot2::aes(x = 1, xend = 2, y = .data[["y"]],
                                                     yend = .data[["y"]]),
                            inherit.aes = FALSE) +
      ggplot2::geom_text(data = ann, ggplot2::aes(x = 1.5, y = .data[["y"]],
                                                  label = .data[["label"]]),
                         vjust = -0.6, size = 3.3, fontface = "italic",
                         inherit.aes = FALSE)
  }
  p
}
