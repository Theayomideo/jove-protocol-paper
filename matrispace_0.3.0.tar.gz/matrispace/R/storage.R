# Versioned registry, canonical storage keys, artifact manifests, and discovery
# (SPEC s3). The registry is the authoritative discovery mechanism and follows
# read -> validate -> migrate -> use; storage names come only from the key
# module. Lifecycle (validate/migrate on access) lives in compat.R so both
# containers behave identically.

.registry_schema_current <- "1.0.0"
.registry_known_versions <- c("0.9.0", "1.0.0")
.registry_required_slots <- c("schema_version", "package_version",
                              "reference_versions", "graphs", "artifacts",
                              "history")

#' @keywords internal
.new_registry <- function() {
  list(
    schema_version     = .registry_schema_current,
    package_version    = as.character(utils::packageVersion("matrispace")),
    reference_versions = character(0),
    graphs             = list(),
    artifacts          = list(),
    history            = list()
  )
}

# Lightweight structural check of the registry SHAPE (slots, versions, names).
# Used during migration (each step) where deep graph/manifest content is not yet
# relevant.
#' @keywords internal
.validate_registry_shape <- function(reg) {
  if (is.null(reg)) {
    stop("matrispace: registry is NULL", call. = FALSE)
  }
  missing <- setdiff(.registry_required_slots, names(reg))
  if (length(missing)) {
    stop("matrispace: registry is missing required slot(s): ",
         paste(missing, collapse = ", "), call. = FALSE)
  }
  v <- reg$schema_version
  if (utils::compareVersion(v, .registry_schema_current) > 0) {
    stop("matrispace: registry schema_version '", v, "' is newer than this ",
         "package supports (", .registry_schema_current, "). Upgrade matrispace; ",
         "there is no migration path for a future schema.", call. = FALSE)
  }
  for (slot in c("graphs", "artifacts", "history")) {
    if (!is.list(reg[[slot]])) {
      stop("matrispace: registry slot '", slot, "' must be a list", call. = FALSE)
    }
  }
  if (length(reg$artifacts) &&
      (is.null(names(reg$artifacts)) || any(!nzchar(names(reg$artifacts))))) {
    stop("matrispace: registry artifacts must be named", call. = FALSE)
  }
  if (length(reg$graphs) &&
      (is.null(names(reg$graphs)) || any(!nzchar(names(reg$graphs))))) {
    stop("matrispace: registry graphs must be named", call. = FALSE)
  }
  invisible(reg)
}

# Full validation: shape plus deep validation of every manifest and graph. Used
# at the read/write boundary (.get_registry / .set_registry).
#' @keywords internal
.validate_registry <- function(reg) {
  .validate_registry_shape(reg)
  if (length(reg$artifacts)) lapply(reg$artifacts, .validate_manifest)
  if (length(reg$graphs))    lapply(reg$graphs, .validate_matrispace_graph)
  invisible(reg)
}

# Sequential migration step 0.9.0 -> 1.0.0: add slots absent in the old schema,
# preserve existing graphs/artifacts.
.migrate_registry_0_9_to_1_0 <- function(reg) {
  if (is.null(reg$history))            reg$history <- list()
  if (is.null(reg$artifacts))          reg$artifacts <- list()
  if (is.null(reg$graphs))             reg$graphs <- list()
  if (is.null(reg$reference_versions)) reg$reference_versions <- character(0)
  if (is.null(reg$package_version))    reg$package_version <- NA_character_
  reg$schema_version <- "1.0.0"
  reg
}

#' @keywords internal
.migrate_registry <- function(reg, to = .registry_schema_current) {
  v <- reg$schema_version
  if (is.null(v)) {
    stop("matrispace: cannot migrate a registry with no schema_version", call. = FALSE)
  }
  if (!(to %in% .registry_known_versions) ||
      utils::compareVersion(to, .registry_schema_current) > 0) {
    stop("matrispace: unknown/unsupported migration target '", to, "'", call. = FALSE)
  }
  if (utils::compareVersion(v, to) > 0) {
    stop("matrispace: registry schema '", v, "' is newer than target '", to,
         "'", call. = FALSE)
  }
  if (!(v %in% .registry_known_versions)) {
    stop("matrispace: unsupported registry schema '", v, "'; no migration path ",
         "from this version.", call. = FALSE)
  }
  # Walk the defined chain one step at a time, validating shape after each step.
  while (utils::compareVersion(reg$schema_version, to) < 0) {
    cur <- reg$schema_version
    reg <- switch(cur,
      "0.9.0" = .migrate_registry_0_9_to_1_0(reg),
      stop("matrispace: no migration step defined from schema '", cur, "'",
           call. = FALSE))
    if (identical(reg$schema_version, cur)) {
      stop("matrispace: migration from '", cur, "' did not advance the schema",
           call. = FALSE)
    }
    .validate_registry_shape(reg)   # shape integrity after each step
  }
  reg
}

#' @keywords internal
.registry_append_history <- function(reg, command, params = list()) {
  rec <- list(
    command         = command,
    params          = params,
    package_version = reg$package_version %||% NA_character_,
    timestamp       = format(Sys.time(), "%Y-%m-%dT%H:%M:%S%z")
  )
  reg$history <- c(reg$history, list(rec))
  reg
}

# ---- Canonical storage keys (SPEC s3.4) -------------------------------------

#' @keywords internal
.key_graph <- function(name) name

#' @keywords internal
.key_feature_result <- function(name) paste0("matrispace_", name)

# ---- Artifact manifests (SPEC s3.1) -----------------------------------------

.manifest_required_fields <- c("schema_version", "producer", "package_version",
                               "timestamp", "parameters", "input_assay",
                               "input_layer", "spot_fingerprint",
                               "reference_version", "type", "storage", "layer")

# Shape-complete manifest. Provenance the low-level primitive cannot know
# (producer, parameters, input_assay/layer, spot_fingerprint, reference_version)
# defaults to NA/empty but is ALWAYS present, so analysis functions fill values
# without changing the schema.
#' @keywords internal
.new_manifest <- function(storage, layer, type,
                          producer = NA_character_, parameters = list(),
                          input_assay = NA_character_, input_layer = NA_character_,
                          spot_fingerprint = NA_character_,
                          reference_version = NA_character_,
                          package_version = as.character(utils::packageVersion("matrispace"))) {
  list(
    schema_version    = "1.0.0",
    producer          = producer,
    package_version   = package_version,
    timestamp         = format(Sys.time(), "%Y-%m-%dT%H:%M:%S%z"),
    parameters        = parameters,
    input_assay       = input_assay,
    input_layer       = input_layer,
    spot_fingerprint  = spot_fingerprint,
    reference_version = reference_version,
    type              = type,
    storage           = storage,
    layer             = layer
  )
}

.is_scalar_chr <- function(x) is.character(x) && length(x) == 1L && !is.na(x)
.is_nonempty_scalar_chr <- function(x) .is_scalar_chr(x) && nzchar(x)
.is_scalar_chr_or_na <- function(x) length(x) == 1L && (is.character(x) || is.na(x))

#' @keywords internal
.validate_manifest <- function(man) {
  if (!is.list(man)) stop("matrispace: manifest must be a list", call. = FALSE)
  missing <- setdiff(.manifest_required_fields, names(man))
  if (length(missing)) {
    stop("matrispace: artifact manifest missing field(s): ",
         paste(missing, collapse = ", "), call. = FALSE)
  }
  # Semantic checks (cheap): shape and domain of each field.
  if (!.is_scalar_chr(man$schema_version) ||
      utils::compareVersion(man$schema_version, .registry_schema_current) > 0) {
    stop("matrispace: manifest schema_version must be a supported scalar version",
         call. = FALSE)
  }
  if (!.is_scalar_chr(man$type) || !(man$type %in% c("score", "activity"))) {
    stop("matrispace: manifest type must be 'score' or 'activity'", call. = FALSE)
  }
  if (!.is_nonempty_scalar_chr(man$storage)) {
    stop("matrispace: manifest storage must be a non-empty scalar string",
         call. = FALSE)
  }
  if (!.is_nonempty_scalar_chr(man$layer)) {
    stop("matrispace: manifest layer must be a non-empty scalar string",
         call. = FALSE)
  }
  if (!.is_scalar_chr_or_na(man$producer) ||
      !.is_scalar_chr_or_na(man$package_version) ||
      !.is_scalar_chr_or_na(man$input_assay) ||
      !.is_scalar_chr_or_na(man$input_layer) ||
      !.is_scalar_chr_or_na(man$spot_fingerprint) ||
      !.is_scalar_chr_or_na(man$reference_version) ||
      !.is_scalar_chr_or_na(man$timestamp)) {
    stop("matrispace: manifest provenance fields must be scalar character or NA",
         call. = FALSE)
  }
  if (!is.list(man$parameters)) {
    stop("matrispace: manifest parameters must be a list", call. = FALSE)
  }
  invisible(man)
}

# ---- Public discovery (SPEC s3.1) -------------------------------------------

#' Does the object carry any matrispace spatial graph?
#' @param object A Seurat or SpatialExperiment object.
#' @return Logical scalar.
#' @export
has_matrispace_graph <- function(object) {
  reg <- .get_registry(object)
  !is.null(reg) && length(reg$graphs) > 0
}

#' Names of the matrispace spatial graphs stored on an object.
#' @param object A Seurat or SpatialExperiment object.
#' @return Character vector of graph names (empty if none).
#' @export
matrispace_graphs <- function(object) {
  reg <- .get_registry(object)
  if (is.null(reg)) character(0) else names(reg$graphs)
}

# ---- Spot-id validation (SPEC s4) -------------------------------------------

#' @keywords internal
.validate_spot_ids <- function(ids) {
  if (is.null(ids) || length(ids) == 0) {
    stop("matrispace: spot ids are NULL or empty", call. = FALSE)
  }
  if (anyNA(ids)) {
    stop("matrispace: spot ids contain NA", call. = FALSE)
  }
  if (any(!nzchar(ids))) {
    stop("matrispace: spot ids contain empty strings", call. = FALSE)
  }
  if (anyDuplicated(ids)) {
    stop("matrispace: duplicated spot ids", call. = FALSE)
  }
  invisible(TRUE)
}
