# Seurat implementation of the accessor contract (SPEC s4). This is the ONLY
# file (with compat-spatialexperiment.R) permitted to touch Seurat internals.

.get_expression_seurat <- function(object, assay = NULL, layer = NULL) {
  assay <- assay %||% SeuratObject::DefaultAssay(object)
  layer <- layer %||% "data"
  SeuratObject::LayerData(object, layer = layer, assay = assay)
}

# Validate the (assay, layer) pair against the object, defaulting assay to the
# active assay and layer to "data". Errors name the available assays/layers.
.resolve_expression_source_seurat <- function(object, assay = NULL, layer = NULL) {
  assays <- SeuratObject::Assays(object)
  assay <- assay %||% SeuratObject::DefaultAssay(object)
  if (!(assay %in% assays)) {
    stop("matrispace: assay '", assay, "' not found (available: ",
         paste(assays, collapse = ", "), ").", call. = FALSE)
  }
  layers <- SeuratObject::Layers(object, assay = assay)
  layer <- layer %||% "data"
  if (!(layer %in% layers)) {
    stop("matrispace: assay '", assay, "' has no layer '", layer,
         "' (available: ", paste(layers, collapse = ", "),
         "). Choose a normalized layer explicitly, e.g. assay='SCT', layer='data'.",
         call. = FALSE)
  }
  list(assay = assay, layer = layer)
}

.get_counts_seurat <- function(object, assay = NULL) {
  assay <- assay %||% SeuratObject::DefaultAssay(object)
  SeuratObject::LayerData(object, layer = "counts", assay = assay)
}

.get_coordinates_seurat <- function(object, image_id = NULL) {
  available <- SeuratObject::Images(object)
  if (length(available) == 0) {
    stop("matrispace: Seurat object has no spatial image/FOV; cannot read ",
         "coordinates.", call. = FALSE)
  }
  if (!is.null(image_id) && !(image_id %in% available)) {
    stop("matrispace: unknown image_id '", image_id, "'; available: ",
         paste(available, collapse = ", "), call. = FALSE)
  }
  imgs <- if (is.null(image_id)) available else image_id
  parts <- lapply(imgs, function(im) {
    # VisiumV1 defaults to low-resolution image pixels; physical graphs need
    # full-resolution coordinates. FOV objects keep their native coordinate API.
    spatial_image <- object[[im]]
    tc <- if (inherits(spatial_image, c("VisiumV1", "VisiumV2"))) {
      SeuratObject::GetTissueCoordinates(spatial_image, scale = NULL)
    } else {
      SeuratObject::GetTissueCoordinates(object, image = im)
    }
    cell <- if (!is.null(tc$cell)) as.character(tc$cell) else rownames(tc)
    axes <- if (all(c("x", "y") %in% names(tc))) c("x", "y") else
      if (all(c("imagecol", "imagerow") %in% names(tc))) c("imagecol", "imagerow") else
        stop("matrispace: unsupported spatial coordinate columns for image '",
             im, "': ", paste(names(tc), collapse = ", "), call. = FALSE)
    m <- as.matrix(tc[, axes, drop = FALSE])
    storage.mode(m) <- "double"
    rownames(m) <- cell
    colnames(m) <- c("x", "y")
    m
  })
  do.call(rbind, parts)
}

.spatial_y_is_down_seurat <- function(object, image_id = NULL) {
  images <- SeuratObject::Images(object)
  if (!length(images)) return(NULL)
  im <- image_id %||% images[1]
  if (!(im %in% images)) return(NULL)
  cls <- class(object[[im]])
  if (any(cls %in% c("VisiumV1", "VisiumV2", "SlideSeq"))) return(TRUE)
  if ("FOV" %in% cls) return(FALSE)
  NULL
}

.get_image_membership_seurat <- function(object) {
  imgs <- SeuratObject::Images(object)
  if (length(imgs) == 0) {
    stop("matrispace: Seurat object has no spatial image/FOV; every spot must ",
         "belong to exactly one image.", call. = FALSE)
  }
  # Detect a cell shared by two FOVs BEFORE building the map (last-wins would
  # otherwise hide it). Each spot must belong to exactly one image.
  per_image <- lapply(imgs, function(im) SeuratObject::Cells(object[[im]]))
  names(per_image) <- imgs
  all_cells <- unlist(per_image, use.names = FALSE)
  dup <- unique(all_cells[duplicated(all_cells)])
  if (length(dup)) {
    stop("matrispace: ", length(dup), " spot(s) belong to more than one image ",
         "(e.g. '", dup[1], "'); each spot must belong to exactly one image.",
         call. = FALSE)
  }
  mem <- character(0)
  for (im in imgs) mem[per_image[[im]]] <- im
  cells <- colnames(object)
  missing <- setdiff(cells, names(mem))
  if (length(missing)) {
    stop("matrispace: ", length(missing), " spot(s) belong to no image.",
         call. = FALSE)
  }
  mem[cells]
}

.get_spot_metadata_seurat <- function(object) {
  object[[]]
}

.set_spot_metadata_seurat <- function(object, name, value) {
  value <- .align_to_spots(value, colnames(object))
  object[[name]] <- unname(value)
  object
}

.get_registry_raw_seurat <- function(object) {
  SeuratObject::Misc(object, slot = "matrispace")
}

.set_registry_raw_seurat <- function(object, registry) {
  # Overwriting an existing registry is intentional; muffle Seurat's
  # "Overwriting miscellaneous data" note.
  suppressWarnings(SeuratObject::Misc(object, slot = "matrispace") <- registry)
  object
}

# Physical storage only: a scores/activity Assay5 with a data layer (no counts).
.store_feature_result_seurat <- function(object, akey, matrix) {
  suppressWarnings({
    assay <- SeuratObject::CreateAssay5Object(
      data = methods::as(matrix, "CsparseMatrix"))
    object[[akey]] <- assay
    object
  })
}

.read_feature_result_seurat <- function(object, storage, layer) {
  SeuratObject::LayerData(object, layer = layer, assay = storage)
}

.remove_feature_result_seurat <- function(object, akey) {
  if (akey %in% SeuratObject::Assays(object)) {
    suppressWarnings(object[[akey]] <- NULL)
  }
  object
}
