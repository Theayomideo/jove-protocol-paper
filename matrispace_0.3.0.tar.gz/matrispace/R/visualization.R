# Visualization (SPEC s11). Every plot_* is a PURE consumer: it reads stored
# results or explicit inputs through the accessor contract only, returns a
# composable ggplot, and has NO side effects -- it never mutates the container,
# touches the registry/metadata/assays, advances the RNG, or opens a graphics
# device. plot_lisa() consumes a supplied compute_lisa() result and NEVER
# recomputes. All plots are image-aware: multi-image data facets by image_id so
# each library's LOCAL coordinate frame renders in its own panel.

# ---- Stable, named palettes (SPEC s11) --------------------------------------
# Each returns a named character vector of valid colors, deterministic across
# calls (no scCustomize, no RNG).

#' ECM niche color palette.
#' @return A named character vector of hex colors.
#' @export
palette_ecm_niche <- function() {
  c(interstitial = "#1B9E77", basement = "#D95F02", vascular = "#7570B3",
    fibrotic = "#E7298A", provisional = "#66A61E", not_assigned = "#999999")
}

#' Matrisome-category color palette.
#' @return A named character vector of hex colors.
#' @export
palette_matrisome_category <- function() {
  c(Collagens = "#4E79A7", `ECM Glycoproteins` = "#59A14F",
    Proteoglycans = "#B07AA1", `ECM Regulators` = "#F28E2B",
    `ECM-affiliated Proteins` = "#EDC948", `Secreted Factors` = "#E15759")
}

#' Generic annotation color palette.
#' @param n Number of colors. The first eight retain the package's original
#'   Tableau-style colors; larger palettes use a deterministic qualitative HCL
#'   palette.
#' @return A named character vector of colors.
#' @export
palette_annotation <- function(n = 8L) {
  if (!(is.numeric(n) && length(n) == 1L && is.finite(n) && n >= 1 &&
        n == round(n))) {
    stop("matrispace: `n` must be a positive whole number", call. = FALSE)
  }
  n <- as.integer(n)
  base <- c("#4E79A7", "#F28E2B", "#59A14F", "#E15759",
            "#B07AA1", "#EDC948", "#76B7B2", "#FF9DA7")
  cols <- if (n <= length(base)) base[seq_len(n)] else
    grDevices::hcl.colors(n, palette = "Dark 3")
  stats::setNames(cols, as.character(seq_len(n)))
}

#' matrispace ggplot theme.
#' @return A ggplot2 theme object.
#' @export
theme_matrispace <- function() {
  ggplot2::theme_minimal(base_size = 11) +
    ggplot2::theme(
      panel.grid.minor = ggplot2::element_blank(),
      strip.text = ggplot2::element_text(face = "bold"),
      plot.title = ggplot2::element_text(face = "bold"),
      legend.key = ggplot2::element_blank(),
      legend.position = "right"
    )
}

# Spatial maps use image coordinates only to position marks; the coordinate
# values themselves are not an analytical axis. Match Seurat's clean spatial
# presentation by retaining the panel/title/legend while removing coordinate
# titles, ticks, tick labels, and all grid lines.
.theme_spatial <- function() {
  theme_matrispace() +
    ggplot2::theme(
      panel.grid = ggplot2::element_blank(),
      axis.title = ggplot2::element_blank(),
      axis.text = ggplot2::element_blank(),
      axis.ticks = ggplot2::element_blank()
    )
}

# ---- Internal, accessor-only helpers ----------------------------------------

# Per-spot value for `feature`: a spot-metadata column, else an expression row.
# Returns a named numeric/character vector over the object's spots. Read-only.
.feature_vector <- function(object, feature, assay = NULL, layer = NULL) {
  if (!.is_nonempty_scalar_chr(feature)) {
    stop("matrispace: `feature` must be a single non-empty name", call. = FALSE)
  }
  spots <- colnames(object)
  md <- .get_spot_metadata(object)
  if (feature %in% colnames(md)) {
    return(stats::setNames(md[spots, feature], spots))
  }
  expr <- .get_expression(object, assay = assay, layer = layer)
  if (feature %in% rownames(expr)) {
    return(stats::setNames(as.numeric(expr[feature, ]), colnames(expr)))
  }
  stop("matrispace: feature '", feature, "' not found in spot metadata or the ",
       "expression assay", call. = FALSE)
}

# Per-spot NUMERIC value for `feature`. Rejects categorical (factor/character)
# metadata with a focused error instead of silently coercing factor level codes
# or turning labels into NA. Non-finite values are mapped consistently to NA.
.numeric_feature_vector <- function(object, feature, assay = NULL, layer = NULL) {
  v <- .feature_vector(object, feature, assay = assay, layer = layer)
  if (is.factor(v) || is.character(v)) {
    stop("matrispace: feature '", feature, "' is categorical; this plot requires ",
         "a numeric feature (expression or a numeric metadata column)", call. = FALSE)
  }
  v <- stats::setNames(as.numeric(v), names(v))       # as.numeric() drops names
  v[!is.finite(v)] <- NA_real_
  v
}

# Assemble a per-spot plotting frame (spot_id, x, y, image_id, value) restricted
# to spots that carry coordinates (optionally a single image_id).
.spatial_frame <- function(object, feature, image_id = NULL,
                           assay = NULL, layer = NULL) {
  coords <- .get_coordinates(object, image_id = image_id)
  mem <- .get_image_membership(object)
  spots <- rownames(coords)
  val <- .feature_vector(object, feature, assay = assay, layer = layer)[spots]
  data.frame(spot_id = spots, x = coords[, "x"], y = coords[, "y"],
             image_id = unname(mem[spots]), value = unname(val),
             stringsAsFactors = FALSE, row.names = NULL)
}

# Spatial orientation is container/technology-aware. Visium and registered
# rasters have a top-left origin; Seurat FOV and plain x/y SPE coordinates are
# Cartesian unless the caller explicitly overrides the adapter decision.
.resolve_flip_y <- function(object, image_id = NULL, flip_y = "auto") {
  if (is.logical(flip_y) && length(flip_y) == 1L && !is.na(flip_y)) {
    return(flip_y)
  }
  if (!identical(flip_y, "auto")) {
    stop("matrispace: `flip_y` must be 'auto', TRUE, or FALSE", call. = FALSE)
  }
  isTRUE(.spatial_y_is_down(object, image_id))
}

# Returned as a list because a scale and coordinate object cannot be safely
# pre-combined across supported ggplot2 versions.
.spatial_coord_layers <- function(flip_y, xlim = NULL, ylim = NULL,
                                  expand = TRUE) {
  coord <- ggplot2::coord_fixed(xlim = xlim, ylim = ylim, expand = expand)
  if (isTRUE(flip_y)) list(ggplot2::scale_y_reverse(), coord) else list(coord)
}

# Facet by image only when there is more than one image; each library retains
# its local coordinate frame by default.
.facet_by_image <- function(df, scales = "free") {
  scales <- match.arg(scales, c("fixed", "free", "free_x", "free_y"))
  if (length(unique(df$image_id)) > 1L) {
    ggplot2::facet_wrap(ggplot2::vars(.data[["image_id"]]), scales = scales)
  } else {
    NULL
  }
}

# Compact validation shared by all spatial-family plots.
.spatial_style <- function(n, point_size, point_alpha, na_colour) {
  if (is.null(point_size)) point_size <- min(1.8, max(0.35, 100 / sqrt(max(1, n))))
  if (!(is.numeric(point_size) && length(point_size) == 1L &&
        is.finite(point_size) && point_size > 0)) {
    stop("matrispace: `point_size` must be NULL or one positive number",
         call. = FALSE)
  }
  if (!(is.numeric(point_alpha) && length(point_alpha) == 1L &&
        is.finite(point_alpha) && point_alpha >= 0 && point_alpha <= 1)) {
    stop("matrispace: `point_alpha` must be one number in [0, 1]",
         call. = FALSE)
  }
  if (!.is_nonempty_scalar_chr(na_colour)) {
    stop("matrispace: `na_colour` must be one color", call. = FALSE)
  }
  tryCatch(grDevices::col2rgb(na_colour), error = function(e) {
    stop("matrispace: `na_colour` is not a valid color", call. = FALSE)
  })
  list(size = as.numeric(point_size), alpha = as.numeric(point_alpha))
}

.validate_limits <- function(x, name = "limits") {
  if (is.null(x)) return(NULL)
  if (!(is.numeric(x) && length(x) == 2L && all(is.finite(x)) && x[1] < x[2])) {
    stop("matrispace: `", name, "` must be NULL or two increasing finite numbers",
         call. = FALSE)
  }
  as.numeric(x)
}

.squish <- function(x, range) pmax(range[1], pmin(range[2], x))

.annotation_colours <- function(values, palette = NULL) {
  lev <- if (is.factor(values)) levels(values) else levels(.group_factor(values))
  if (!length(lev)) return(character())
  if (is.null(palette)) {
    niche <- palette_ecm_niche()
    if (all(lev %in% names(niche))) return(niche[lev])
    cols <- unname(palette_annotation(length(lev)))
    return(stats::setNames(cols, lev))
  }
  if (!is.character(palette) || !length(palette)) {
    stop("matrispace: `palette` must be NULL or a character vector of colors",
         call. = FALSE)
  }
  tryCatch(grDevices::col2rgb(palette), error = function(e) {
    stop("matrispace: `palette` contains an invalid color", call. = FALSE)
  })
  if (!is.null(names(palette)) && all(nzchar(names(palette)))) {
    miss <- setdiff(lev, names(palette))
    if (length(miss)) {
      stop("matrispace: named `palette` is missing level(s): ",
           paste(miss, collapse = ", "), call. = FALSE)
    }
    return(palette[lev])
  }
  if (length(palette) < length(lev)) {
    stop("matrispace: `palette` needs at least ", length(lev), " colors",
         call. = FALSE)
  }
  stats::setNames(palette[seq_along(lev)], lev)
}

.continuous_colour_scale <- function(name, limits = NULL,
                                     na_colour = "grey80",
                                     colour_scale = "viridis") {
  if (identical(colour_scale, "spectral")) {
    return(ggplot2::scale_colour_gradientn(
      colours = .spectral_colours, name = name, limits = limits,
      na.value = na_colour, oob = .squish))
  }
  ggplot2::scale_colour_viridis_c(
    name = name, limits = limits, na.value = na_colour, oob = .squish)
}

# Reversed 11-class ColorBrewer Spectral (low = purple, high = red), as in the app.
.spectral_colours <- c("#5E4FA2", "#3288BD", "#66C2A5", "#ABDDA4", "#E6F598",
                       "#FFFFBF", "#FEE08B", "#FDAE61", "#F46D43", "#D53E4F",
                       "#9E0142")

# Default scale-bar label: coordinates are assumed to be micrometres.
.scale_bar_label <- function(length) {
  if (length >= 1000 && length %% 1000 == 0) paste(length / 1000, "mm")
  else paste(format(length, trim = TRUE), "\u00b5m")
}

# Horizontal scale bar in the bottom-right corner of a coordinate-only map.
.add_scale_bar <- function(p, df, length, label, flip) {
  xr <- range(df$x, na.rm = TRUE); yr <- range(df$y, na.rm = TRUE)
  off <- 0.04 * diff(yr)
  # Bar just below the map, label below the bar (on screen, for either y direction).
  y0 <- if (isTRUE(flip)) yr[2] + off else yr[1] - off
  ty <- if (isTRUE(flip)) y0 + 0.5 * off else y0 - 0.5 * off
  p + ggplot2::annotate("segment", x = xr[2] - length, xend = xr[2], y = y0, yend = y0,
                        linewidth = 1, colour = "black") +
    ggplot2::annotate("text", x = xr[2] - length / 2, y = ty, label = label,
                      size = 3, vjust = 1)
}

.discrete_colour_scale <- function(values, name, palette = NULL,
                                   na_colour = "grey80") {
  ggplot2::scale_colour_manual(
    name = name, values = .annotation_colours(values, palette),
    na.value = na_colour, drop = FALSE)
}

.validate_image_args <- function(image, image_scale, image_alpha, crop) {
  if (!(is.logical(image) && length(image) == 1L && !is.na(image))) {
    stop("matrispace: `image` must be a single TRUE/FALSE", call. = FALSE)
  }
  image_scale <- match.arg(image_scale, c("lowres", "hires"))
  if (!(is.numeric(image_alpha) && length(image_alpha) == 1L &&
        is.finite(image_alpha) && image_alpha >= 0 && image_alpha <= 1)) {
    stop("matrispace: `image_alpha` must be a single number in [0, 1]",
         call. = FALSE)
  }
  if (!(is.logical(crop) && length(crop) == 1L && !is.na(crop))) {
    stop("matrispace: `crop` must be a single TRUE/FALSE", call. = FALSE)
  }
  list(image = image, image_scale = image_scale,
       image_alpha = image_alpha, crop = crop)
}

.point_layer <- function(df, style) {
  if (".alpha" %in% names(df)) {
    ggplot2::geom_point(ggplot2::aes(alpha = .data[[".alpha"]]),
                        size = style$size, stroke = 0) 
  } else {
    ggplot2::geom_point(size = style$size, alpha = style$alpha, stroke = 0)
  }
}

# Render any x/y/image_id/value frame using the same spatial grammar. A scale
# factory is used because each histology panel needs its own ggplot scale object.
.spatial_points_plot <- function(object, df, scale_factory,
                                 image = FALSE, image_scale = "lowres",
                                 image_alpha = 1, crop = FALSE,
                                 point_size = NULL, point_alpha = 1,
                                 flip_y = "auto", facet_scales = "free",
                                 title = NULL, legend_position = "right",
                                 colour_column = "value") {
  args <- .validate_image_args(image, image_scale, image_alpha, crop)
  style <- .spatial_style(nrow(df), point_size, point_alpha, "grey80")
  if (".alpha" %in% names(df)) df$.alpha <- df$.alpha * style$alpha
  base_mapping <- ggplot2::aes(x = .data[["x"]], y = .data[["y"]],
                               colour = .data[[colour_column]])

  if (!isTRUE(args$image)) {
    flip <- .resolve_flip_y(object, unique(df$image_id)[1], flip_y)
    p <- ggplot2::ggplot(df, base_mapping) +
      .point_layer(df, style) + scale_factory() +
      .spatial_coord_layers(flip) + .facet_by_image(df, facet_scales) +
      ggplot2::labs(x = NULL, y = NULL, title = title) + .theme_spatial() +
      ggplot2::theme(legend.position = legend_position)
    if (".alpha" %in% names(df)) p <- p + ggplot2::scale_alpha_identity()
    return(p)
  }

  panels <- lapply(unique(df$image_id), function(im) {
    d <- df[df$image_id == im, , drop = FALSE]
    sf <- .get_spatial_scale_factor(object, im, args$image_scale)
    raster <- .get_spatial_image(object, im, args$image_scale)
    if (is.null(sf) || is.null(raster)) {
      stop("matrispace: image = TRUE but no histology raster is available for ",
           "image '", im, "' at scale '", args$image_scale, "'. Use image = FALSE ",
           "for coordinate-only plotting.", call. = FALSE)
    }
    d$x <- d$x * sf; d$y <- d$y * sf
    h <- nrow(raster); w <- ncol(raster)
    if (isTRUE(args$crop)) {
      xr <- range(d$x, na.rm = TRUE); yr <- range(d$y, na.rm = TRUE)
      mx <- 0.03 * (diff(xr) + 1); my <- 0.03 * (diff(yr) + 1)
      xlim <- c(max(0, xr[1] - mx), min(w, xr[2] + mx))
      ylim <- c(max(0, yr[1] - my), min(h, yr[2] + my))
    } else {
      xlim <- c(0, w); ylim <- c(0, h)
    }
    panel_title <- if (length(unique(df$image_id)) > 1L) im else title
    p <- ggplot2::ggplot(d, base_mapping) +
      ggplot2::annotation_raster(.apply_raster_alpha(raster, args$image_alpha),
                                 xmin = 0, xmax = w, ymin = 0, ymax = h) +
      .point_layer(d, style) + scale_factory() +
      .spatial_coord_layers(.resolve_flip_y(object, im, flip_y),
                            xlim = xlim, ylim = ylim, expand = FALSE) +
      ggplot2::labs(x = NULL, y = NULL, title = panel_title) + .theme_spatial() +
      ggplot2::theme(legend.position = legend_position)
    if (".alpha" %in% names(d)) p <- p + ggplot2::scale_alpha_identity()
    p
  })
  if (length(panels) == 1L) return(panels[[1]])
  if (!requireNamespace("patchwork", quietly = TRUE)) {
    stop("matrispace: composing multiple histology images needs 'patchwork'; ",
         "install it or select one `image_id`.", call. = FALSE)
  }
  patchwork::wrap_plots(panels)
}

# Rescale to [0, 1] using optional robust quantile limits. A degenerate range
# maps to 0.5 and values outside the limits are squished, not discarded.
.rescale01 <- function(x, quantiles = c(0, 1)) {
  if (!(is.numeric(quantiles) && length(quantiles) == 2L &&
        all(is.finite(quantiles)) && quantiles[1] >= 0 && quantiles[2] <= 1 &&
        quantiles[1] < quantiles[2])) {
    stop("matrispace: `quantiles` must be two increasing probabilities in [0, 1]",
         call. = FALSE)
  }
  rng <- as.numeric(stats::quantile(x, probs = quantiles, na.rm = TRUE,
                                    names = FALSE, type = 8))
  if (!all(is.finite(rng)) || rng[1] == rng[2]) {
    return(ifelse(is.na(x), NA_real_, 0.5))
  }
  .squish((x - rng[1]) / (rng[2] - rng[1]), c(0, 1))
}

# ---- Public plots -----------------------------------------------------------

#' Spatial feature map.
#'
#' By default a coordinate-only map (equal aspect, top-left image origin), with
#' multi-image data faceted by `image_id`. With `image = TRUE` the histology
#' raster is drawn underneath, coordinates are scaled into the raster's pixel
#' space, and multi-image data is composed one panel per image (requires the
#' `patchwork` package). Coordinate-only rendering is the default (`image =
#' FALSE`); `image = TRUE` requires a raster and errors when none is available
#' rather than silently reverting.
#'
#' @param object A Seurat or SpatialExperiment object.
#' @param feature A spot-metadata column or an expression feature.
#' @param image_id Optional single image to restrict to.
#' @param assay,layer Expression source (when `feature` is an expression row).
#' @param image Draw the histology raster underneath (default `FALSE`).
#' @param image_scale Raster resolution: `"lowres"` (default) or `"hires"`.
#' @param image_alpha Opacity of the histology raster in `[0, 1]`.
#' @param crop Zoom to the spot bounding box (default `FALSE` shows the full
#'   raster extent).
#' @param feature_type Treat the feature as `"continuous"` or `"discrete"`;
#'   `"auto"` uses its storage type.
#' @param point_size Point size; `NULL` chooses a compact size from spot count.
#' @param point_alpha Point opacity in `[0, 1]`.
#' @param palette Optional discrete color vector, preferably named by level.
#' @param limits Optional continuous color limits; outlying values are squished.
#' @param na_colour Color for missing values.
#' @param flip_y `"auto"` (technology-aware), `TRUE`, or `FALSE`.
#' @param facet_scales Facet scale policy for coordinate-only multi-image plots.
#' @param legend_position A ggplot2 legend position.
#' @param colour_scale Continuous colour scale: `"viridis"` (default) or
#'   `"spectral"` (reversed ColorBrewer Spectral, as in the MatriSpace app).
#' @param title,legend_title Optional plot and legend titles; the legend title
#'   defaults to the feature name.
#' @param scale_bar Optional scale-bar length in coordinate units (for example
#'   `1000` for 1 mm when coordinates are in micrometres). Coordinate-only,
#'   single-image maps only.
#' @param scale_bar_label Optional scale-bar label; by default the length is
#'   labelled in micrometres or millimetres.
#' @param ... Must be empty.
#' @return A ggplot; with `image = TRUE` and multiple images, a `patchwork`
#'   composition of one ggplot per image.
#' @export
plot_spatial <- function(object, feature, image_id = NULL,
                         assay = NULL, layer = NULL, image = FALSE,
                         image_scale = "lowres", image_alpha = 1,
                         crop = FALSE,
                         feature_type = c("auto", "continuous", "discrete"),
                         point_size = NULL, point_alpha = 1,
                         palette = NULL, limits = NULL, na_colour = "grey80",
                         flip_y = "auto", facet_scales = "free",
                         legend_position = "right",
                         colour_scale = c("viridis", "spectral"),
                         title = NULL, legend_title = NULL,
                         scale_bar = NULL, scale_bar_label = NULL, ...) {
  if (...length()) {
    stop("matrispace: unknown argument(s) passed to plot_spatial()", call. = FALSE)
  }
  feature_type <- match.arg(feature_type)
  colour_scale <- match.arg(colour_scale)
  limits <- .validate_limits(limits)
  for (nm in c("title", "legend_title", "scale_bar_label")) {
    v <- get(nm)
    if (!is.null(v) && !.is_scalar_chr(v)) {
      stop("matrispace: `", nm, "` must be NULL or one string", call. = FALSE)
    }
  }
  if (!is.null(scale_bar) && !(is.numeric(scale_bar) && length(scale_bar) == 1L &&
                               is.finite(scale_bar) && scale_bar > 0)) {
    stop("matrispace: `scale_bar` must be NULL or one positive number", call. = FALSE)
  }
  legend_name <- legend_title %||% feature
  df <- .spatial_frame(object, feature, image_id = image_id,
                       assay = assay, layer = layer)
  if (!is.null(scale_bar) && (isTRUE(image) || length(unique(df$image_id)) > 1L)) {
    stop("matrispace: `scale_bar` needs a coordinate-only (image = FALSE), ",
         "single-image map; select one `image_id`", call. = FALSE)
  }
  discrete <- if (feature_type == "auto") {
    is.character(df$value) || is.factor(df$value) || is.logical(df$value)
  } else feature_type == "discrete"
  if (discrete) {
    df$value <- .group_factor(df$value)
    scale_factory <- function() .discrete_colour_scale(
      df$value, legend_name, palette, na_colour)
  } else {
    if (is.factor(df$value) || is.character(df$value)) {
      stop("matrispace: feature '", feature, "' is categorical; use ",
           "feature_type='discrete' or choose a numeric feature", call. = FALSE)
    }
    df$value <- as.numeric(df$value)
    df$value[!is.finite(df$value)] <- NA_real_
    scale_factory <- function() .continuous_colour_scale(
      legend_name, limits, na_colour, colour_scale)
  }
  p <- .spatial_points_plot(
    object, df, scale_factory, image, image_scale, image_alpha, crop,
    point_size, point_alpha, flip_y, facet_scales, title = title,
    legend_position = legend_position)
  if (!is.null(scale_bar)) {
    flip <- .resolve_flip_y(object, unique(df$image_id)[1], flip_y)
    p <- .add_scale_bar(p, df, scale_bar,
                        scale_bar_label %||% .scale_bar_label(scale_bar), flip)
  }
  p
}

# Scale a raster's opacity by `alpha` for ANY valid color spec -- "#RRGGBB",
# "#RRGGBBAA", or named ("red") -- by round-tripping through col2rgb(alpha=TRUE)
# and MULTIPLYING the existing alpha (so already-transparent pixels stay
# transparent). Rebuilt as "#RRGGBBAA". Unrecognized cells are left unchanged.
.apply_raster_alpha <- function(ras, alpha) {
  if (alpha >= 1) return(ras)
  m <- as.matrix(ras)
  cells <- unique(as.vector(m))
  conv <- vapply(cells, function(col) {
    rgba <- tryCatch(grDevices::col2rgb(col, alpha = TRUE)[, 1],
                     error = function(e) NULL)
    if (is.null(rgba)) return(NA_character_)          # not a color: leave as-is
    a <- round(rgba[["alpha"]] * alpha)               # multiply existing opacity
    sprintf("#%02X%02X%02X%02X", rgba[["red"]], rgba[["green"]], rgba[["blue"]], a)
  }, character(1))
  out <- conv[as.vector(m)]
  na <- is.na(out)
  if (any(na)) out[na] <- as.vector(m)[na]
  dim(out) <- dim(m)
  grDevices::as.raster(out)
}

#' Two-feature blend map.
#'
#' @param object A Seurat or SpatialExperiment object.
#' @param feature1,feature2 Two expression/metadata features.
#' @param image_id Optional single image to restrict to.
#' @param assay,layer Expression source.
#' @param quantiles Two probabilities used as robust per-feature color limits.
#' @param colours Four colors named `low`, `feature1`, `feature2`, and `both`.
#' @param image,image_scale,image_alpha,crop Histology controls as in
#'   [plot_spatial()].
#' @param point_size,point_alpha,flip_y,facet_scales,legend_position Spatial
#'   presentation controls as in [plot_spatial()].
#' @param na_colour Color for a spot missing either value.
#' @param ... Must be empty.
#' @return A ggplot with a per-spot bivariate color and corner legend.
#' @export
plot_blend <- function(object, feature1, feature2, image_id = NULL,
                       assay = NULL, layer = NULL,
                       quantiles = c(0.01, 0.99),
                       colours = c(low = "#E6E6E6", feature1 = "#E64B35",
                                   feature2 = "#3C5488", both = "#7A1FA2"),
                       image = FALSE, image_scale = "lowres", image_alpha = 1,
                       crop = FALSE, point_size = NULL, point_alpha = 1,
                       na_colour = "grey80", flip_y = "auto",
                       facet_scales = "free", legend_position = "right", ...) {
  if (...length()) {
    stop("matrispace: unknown argument(s) passed to plot_blend()", call. = FALSE)
  }
  if (!is.character(colours) || length(colours) != 4L) {
    stop("matrispace: `colours` must contain four colors", call. = FALSE)
  }
  if (is.null(names(colours)) || !all(c("low", "feature1", "feature2", "both") %in%
                                      names(colours))) {
    names(colours) <- c("low", "feature1", "feature2", "both")
  }
  colours <- colours[c("low", "feature1", "feature2", "both")]
  tryCatch(grDevices::col2rgb(c(colours, na_colour)), error = function(e) {
    stop("matrispace: `colours` and `na_colour` must be valid colors",
         call. = FALSE)
  })
  coords <- .get_coordinates(object, image_id = image_id)
  mem <- .get_image_membership(object)
  spots <- rownames(coords)
  v1 <- .numeric_feature_vector(object, feature1, assay = assay, layer = layer)[spots]
  v2 <- .numeric_feature_vector(object, feature2, assay = assay, layer = layer)[spots]
  a <- .rescale01(v1, quantiles); b <- .rescale01(v2, quantiles)
  corner_rgb <- grDevices::col2rgb(colours) / 255
  blended <- vapply(seq_along(a), function(i) {
    if (is.na(a[i]) || is.na(b[i])) return(na_colour)
    w <- c((1-a[i])*(1-b[i]), a[i]*(1-b[i]), (1-a[i])*b[i], a[i]*b[i])
    z <- as.numeric(corner_rgb %*% w)
    grDevices::rgb(z[1], z[2], z[3])
  }, character(1))
  df <- data.frame(spot_id = spots, x = coords[, "x"], y = coords[, "y"],
                   image_id = unname(mem[spots]), feature1 = unname(v1),
                   feature2 = unname(v2), value = blended,
                   stringsAsFactors = FALSE, row.names = NULL)
  labels <- c("Both low", paste(feature1, "high"), paste(feature2, "high"),
              "Both high")
  scale_factory <- function() ggplot2::scale_colour_identity(
    name = "Bivariate blend",
    limits = function(x) unique(c(x, unname(colours))),
    breaks = unname(colours), labels = labels, drop = FALSE,
    guide = ggplot2::guide_legend(
      override.aes = list(size = 4, colour = unname(colours))))
  .spatial_points_plot(
    object, df, scale_factory, image, image_scale, image_alpha, crop,
    point_size, point_alpha, flip_y, facet_scales,
    title = paste(feature1, "/", feature2), legend_position = legend_position)
}

#' Plot a LISA result (pure consumer; never recomputes).
#'
#' @param object The container the LISA result was computed on (for coordinates).
#' @param result A `compute_lisa()` data.frame (spot_id, image_id, quadrant, ...).
#' @param significance Optional alpha; when supplied, non-significant spots are
#'   drawn in neutral grey. Adjusted p-values are preferred automatically.
#' @param p_column `"auto"`, `"p_adjusted"`, or `"p_value"`.
#' @param image,image_scale,image_alpha,crop Histology controls as in
#'   [plot_spatial()].
#' @param point_size,point_alpha,flip_y,facet_scales,legend_position Spatial
#'   presentation controls as in [plot_spatial()].
#' @param palette Optional named LISA-quadrant palette.
#' @param title Optional title; inferred from `feature1` when available.
#' @param ... Must be empty.
#' @return A ggplot colored by LISA quadrant, faceted by image.
#' @export
plot_lisa <- function(object, result, significance = NULL,
                      p_column = c("auto", "p_adjusted", "p_value"),
                      image = FALSE, image_scale = "lowres", image_alpha = 1,
                      crop = FALSE, point_size = NULL, point_alpha = 1,
                      flip_y = "auto", facet_scales = "free",
                      palette = NULL, title = NULL,
                      legend_position = "right", ...) {
  if (...length()) {
    stop("matrispace: unknown argument(s) passed to plot_lisa()", call. = FALSE)
  }
  p_column <- match.arg(p_column)
  req <- c("spot_id", "image_id", "quadrant")
  if (!is.data.frame(result) || !all(req %in% colnames(result))) {
    stop("matrispace: `result` must be a compute_lisa() data.frame with columns ",
         paste(req, collapse = ", "), call. = FALSE)
  }
  if (anyDuplicated(result$spot_id)) {
    stop("matrispace: `result` has duplicated spot_id rows", call. = FALSE)
  }
  coords <- .get_coordinates(object)
  miss <- setdiff(result$spot_id, rownames(coords))
  if (length(miss)) {
    stop("matrispace: ", length(miss), " LISA spot(s) are absent from the ",
         "object's coordinates (e.g. '", miss[1], "')", call. = FALSE)
  }
  # Verify each spot's image against the object's OWN spot->image map, not the
  # (possibly stale/malformed) result, so no spot lands in the wrong facet.
  mem <- .get_image_membership(object)
  expected <- unname(mem[result$spot_id])
  result_img <- as.character(result$image_id)
  mismatch <- which(is.na(result_img) | result_img != expected)
  if (length(mismatch)) {
    i <- mismatch[1]
    stop("matrispace: LISA image_id disagrees with the object for ",
         length(mismatch), " spot(s) (e.g. spot '", result$spot_id[i], "': result='",
         result$image_id[i], "', object='", expected[i], "')", call. = FALSE)
  }
  df <- data.frame(
    spot_id = result$spot_id,
    x = coords[result$spot_id, "x"], y = coords[result$spot_id, "y"],
    image_id = expected,                              # authoritative frame
    quadrant = as.character(result$quadrant),
    stringsAsFactors = FALSE)
  if (!is.null(significance)) {
    if (!(is.numeric(significance) && length(significance) == 1L &&
          is.finite(significance) && significance >= 0 && significance <= 1)) {
      stop("matrispace: `significance` must be a single finite number in [0, 1]",
           call. = FALSE)
    }
    if (p_column == "auto") {
      p_column <- if ("p_adjusted" %in% names(result)) "p_adjusted" else "p_value"
    }
    if (!(p_column %in% colnames(result))) {
      stop("matrispace: `significance` needs a `", p_column,
           "` column in `result`", call. = FALSE)
    }
    pv <- result[[p_column]]
    if (!is.numeric(pv) || any(pv[!is.na(pv)] < 0 | pv[!is.na(pv)] > 1)) {
      stop("matrispace: `result$", p_column, "` must be numeric in [0, 1]",
           call. = FALSE)
    }
    significant <- !is.na(pv) & pv <= significance
    df$plot_quadrant <- ifelse(significant, df$quadrant, "Not significant")
  }
  lisa_palette <- c(HH = "#D73027", `high-high` = "#D73027",
                    HL = "#FC8D59", `high-low` = "#FC8D59",
                    LH = "#91BFDB", `low-high` = "#91BFDB",
                    LL = "#4575B4", `low-low` = "#4575B4")
  colour_column <- if ("plot_quadrant" %in% names(df))
    "plot_quadrant" else "quadrant"
  lev <- levels(.group_factor(df[[colour_column]]))
  if (is.null(palette)) {
    missing <- setdiff(lev, names(lisa_palette))
    if (length(missing)) {
      lisa_palette <- c(lisa_palette,
                        stats::setNames(unname(palette_annotation(length(missing))),
                                        missing))
    }
    palette <- lisa_palette[lev]
    if ("Not significant" %in% lev) palette["Not significant"] <- "grey82"
  }
  scale_factory <- function() .discrete_colour_scale(
    df[[colour_column]], "LISA quadrant", palette, "grey80")
  if (is.null(title) && "feature1" %in% names(result)) {
    f <- unique(stats::na.omit(as.character(result$feature1)))
    if (length(f) == 1L) title <- paste("LISA:", f)
  }
  .spatial_points_plot(
    object, df, scale_factory, image, image_scale, image_alpha, crop,
    point_size, point_alpha, flip_y, facet_scales, title,
    legend_position = legend_position, colour_column = colour_column)
}

#' Dot plot: mean expression (color) and detection fraction (size) per group.
#'
#' @param object A Seurat or SpatialExperiment object.
#' @param features Character vector of expression features.
#' @param group_by Spot-metadata grouping column.
#' @param assay,layer Expression source.
#' @param scale_by `"none"` for raw group means or `"feature"` for a z-score
#'   across groups within each feature.
#' @param point_range Minimum and maximum dot sizes.
#' @param ... Must be empty.
#' @return A ggplot.
#' @export
plot_dotplot <- function(object, features, group_by, assay = NULL, layer = NULL,
                         scale_by = c("none", "feature"),
                         point_range = c(0, 6), ...) {
  if (...length()) {
    stop("matrispace: unknown argument(s) passed to plot_dotplot()", call. = FALSE)
  }
  scale_by <- match.arg(scale_by)
  if (!(is.numeric(point_range) && length(point_range) == 2L &&
        all(is.finite(point_range)) && point_range[1] >= 0 &&
        point_range[1] < point_range[2])) {
    stop("matrispace: `point_range` must be two increasing non-negative numbers",
         call. = FALSE)
  }
  if (!is.character(features) || length(features) == 0L) {
    stop("matrispace: `features` must be a non-empty character vector", call. = FALSE)
  }
  if (!.is_nonempty_scalar_chr(group_by)) {
    stop("matrispace: `group_by` must be a single column name", call. = FALSE)
  }
  md <- .get_spot_metadata(object)
  if (!(group_by %in% colnames(md))) {
    stop("matrispace: group_by column '", group_by, "' not found", call. = FALSE)
  }
  expr <- .get_expression(object, assay = assay, layer = layer)
  missing <- setdiff(features, rownames(expr))
  if (length(missing)) {
    stop("matrispace: feature(s) not found in the assay: ",
         paste(missing, collapse = ", "), call. = FALSE)
  }
  feats <- unique(features)                            # preserve requested order
  spots <- colnames(object)
  # Preserve the grouping column's natural level order (factor levels, or
  # numeric-aware ordering of a numeric-valued text column) on the x axis.
  grp_all <- .group_factor(md[spots, group_by])
  keep <- !is.na(grp_all)
  grp <- grp_all[keep]; sub <- expr[feats, spots[keep], drop = FALSE]
  groups <- levels(droplevels(grp))
  rows <- lapply(groups, function(g) {
    cols <- which(as.character(grp) == g); m <- sub[, cols, drop = FALSE]
    data.frame(feature = feats, group = g,
               avg_expr = as.numeric(Matrix::rowMeans(m)),
               pct = as.numeric(Matrix::rowMeans(m > 0)),
               stringsAsFactors = FALSE)
  })
  df <- do.call(rbind, rows)
  if (scale_by == "feature") {
    df$avg_expr <- stats::ave(df$avg_expr, df$feature, FUN = function(z) {
      s <- stats::sd(z, na.rm = TRUE)
      if (!is.finite(s) || s == 0) rep(0, length(z)) else
        (z - mean(z, na.rm = TRUE)) / s
    })
  }
  df$feature <- factor(df$feature, levels = feats)
  df$group <- factor(df$group, levels = groups)
  ggplot2::ggplot(df, ggplot2::aes(x = .data[["group"]], y = .data[["feature"]],
                                   size = .data[["pct"]],
                                   colour = .data[["avg_expr"]])) +
    ggplot2::geom_point() +
    ggplot2::scale_colour_viridis_c() +
    ggplot2::scale_size_continuous(
      limits = c(0, 1), range = point_range,
      labels = function(x) paste0(round(100 * x), "%")) +
    ggplot2::labs(x = group_by, y = NULL,
                  colour = if (scale_by == "feature") "Mean expression\n(z-score)" else
                    "Mean expression",
                  size = "% detected") +
    theme_matrispace()
}

#' Violin plot of one feature across groups.
#'
#' @param object A Seurat or SpatialExperiment object.
#' @param feature Expression/metadata feature.
#' @param group_by Spot-metadata grouping column.
#' @param assay,layer Expression source.
#' @param box Add a narrow boxplot showing median and quartiles.
#' @param jitter Add individual spot values with light jitter.
#' @param show_n Append group sizes to x-axis labels.
#' @param palette Optional fill colors, preferably named by group.
#' @param ... Must be empty.
#' @return A ggplot.
#' @export
plot_violin <- function(object, feature, group_by, assay = NULL, layer = NULL,
                        box = FALSE, jitter = FALSE, show_n = FALSE,
                        palette = NULL, ...) {
  if (...length()) {
    stop("matrispace: unknown argument(s) passed to plot_violin()", call. = FALSE)
  }
  for (z in c(box = box, jitter = jitter, show_n = show_n)) {
    if (!(is.logical(z) && length(z) == 1L && !is.na(z))) {
      stop("matrispace: `box`, `jitter`, and `show_n` must be TRUE/FALSE",
           call. = FALSE)
    }
  }
  if (!.is_nonempty_scalar_chr(group_by)) {
    stop("matrispace: `group_by` must be a single column name", call. = FALSE)
  }
  md <- .get_spot_metadata(object)
  if (!(group_by %in% colnames(md))) {
    stop("matrispace: group_by column '", group_by, "' not found", call. = FALSE)
  }
  spots <- colnames(object)
  val <- .numeric_feature_vector(object, feature, assay = assay, layer = layer)[spots]
  # Preserve the grouping column's natural level order on the x axis.
  grp <- .group_factor(md[spots, group_by])
  df <- data.frame(group = grp, value = val, stringsAsFactors = FALSE)
  df <- df[!is.na(df$group), , drop = FALSE]
  df$group <- droplevels(df$group)
  p <- ggplot2::ggplot(df, ggplot2::aes(x = .data[["group"]], y = .data[["value"]],
                                        fill = .data[["group"]])) +
    ggplot2::geom_violin(scale = "width", trim = TRUE, colour = "grey25",
                         linewidth = 0.35) +
    ggplot2::scale_fill_manual(values = .annotation_colours(df$group, palette),
                               drop = FALSE) +
    ggplot2::labs(x = group_by, y = feature, fill = group_by) +
    theme_matrispace() +
    # The y grid supports value comparison; vertical group grid lines do not.
    ggplot2::theme(panel.grid.major.x = ggplot2::element_blank(),
                   legend.position = "none")
  if (isTRUE(box)) {
    p <- p + ggplot2::geom_boxplot(width = 0.12, outlier.shape = NA,
                                   fill = "white", alpha = 0.8,
                                   linewidth = 0.3)
  }
  if (isTRUE(jitter)) {
    p <- p + ggplot2::geom_jitter(width = 0.12, height = 0, size = 0.45,
                                  alpha = 0.25, show.legend = FALSE)
  }
  if (isTRUE(show_n)) {
    n <- table(df$group)
    p <- p + ggplot2::scale_x_discrete(
      labels = stats::setNames(paste0(names(n), " (n=", as.integer(n), ")"),
                               names(n)))
  }
  p
}

#' Heatmap of a terminal result table (schema-agnostic).
#'
#' Accepts either a numeric matrix (features x groups) or a long data.frame.
#' For a data.frame, `row`/`column`/`value` name the axes and fill; when omitted
#' they are inferred by **semantics** (preferred names like `pair`/`feature`/
#' `gene`/`pair_id` for rows, `group`/`cluster`/`condition` for columns, and
#' `value`/`mean_coexpression`/`avg_log2FC`/... for the fill), falling back to
#' positional label/numeric columns. This keeps the heatmap usable for DE
#' tables, real `find_matrisome_pair_enrichment()` output, and score matrices alike. The
#' readable `pair` is preferred for the axis while `pair_id` (when present) is
#' the collision-resistant identity: distinct pairs that share a display label
#' are disambiguated, not merged. Duplicate row-column cells are rejected rather
#' than silently overplotted.
#'
#' @param data A matrix or a long data.frame.
#' @param row,column,value Column names for a long data.frame (optional).
#' @param scale_by `"none"`, `"row"`, or `"column"`; scaled values are
#'   z-scores within the selected margin.
#' @param center `"auto"` uses a zero-centered diverging scale when values span
#'   zero; a finite number forces a diverging midpoint; `NULL` stays sequential.
#' @param limits Optional fill limits; outliers are squished.
#' @param complete Draw the full row-by-column grid, making absent combinations
#'   explicit `NA` tiles.
#' @param reverse_rows Put the first matrix/data level at the top, following
#'   conventional heatmap orientation.
#' @param na_colour Fill for missing or absent cells.
#' @param colours Optional fill colours: three colours (low, mid, high) for a
#'   diverging scale, or two or more colours for a sequential gradient. For
#'   example, `palette_diverging()` gives the red-blue scale used in the
#'   MatriSpace figures.
#' @param legend_title Optional legend title.
#' @param row_labels,column_labels Optional axis labels: a function applied to
#'   the level names or a character vector named by level.
#' @param italic Italicise `"rows"`, `"columns"`, `"both"` or `"none"` (for
#'   gene names).
#' @param x_angle Rotation of the column labels in degrees.
#' @param legend_position A ggplot2 legend position.
#' @param ... Must be empty.
#' @return A ggplot tile heatmap.
#' @export
plot_heatmap <- function(data, row = NULL, column = NULL, value = NULL,
                         scale_by = c("none", "row", "column"),
                         center = "auto", limits = NULL, complete = TRUE,
                         reverse_rows = TRUE, na_colour = "grey90",
                         colours = NULL, legend_title = NULL,
                         row_labels = NULL, column_labels = NULL,
                         italic = c("none", "rows", "columns", "both"),
                         x_angle = 0, legend_position = "right", ...) {
  if (...length()) {
    stop("matrispace: unknown argument(s) passed to plot_heatmap()", call. = FALSE)
  }
  scale_by <- match.arg(scale_by)
  italic <- match.arg(italic)
  limits <- .validate_limits(limits)
  if (!is.null(colours)) {
    if (!is.character(colours) || length(colours) < 2L) {
      stop("matrispace: `colours` must be NULL or at least two colours", call. = FALSE)
    }
    tryCatch(grDevices::col2rgb(colours), error = function(e) {
      stop("matrispace: `colours` contains an invalid colour", call. = FALSE)
    })
  }
  if (!is.null(legend_title) && !.is_scalar_chr(legend_title)) {
    stop("matrispace: `legend_title` must be NULL or one string", call. = FALSE)
  }
  if (!(is.numeric(x_angle) && length(x_angle) == 1L && is.finite(x_angle))) {
    stop("matrispace: `x_angle` must be one number", call. = FALSE)
  }
  if (!(is.null(center) || identical(center, "auto") ||
        (is.numeric(center) && length(center) == 1L && is.finite(center)))) {
    stop("matrispace: `center` must be 'auto', NULL, or one finite number",
         call. = FALSE)
  }
  for (z in c(complete = complete, reverse_rows = reverse_rows)) {
    if (!(is.logical(z) && length(z) == 1L && !is.na(z))) {
      stop("matrispace: `complete` and `reverse_rows` must be TRUE/FALSE",
           call. = FALSE)
    }
  }
  tryCatch(grDevices::col2rgb(na_colour), error = function(e) {
    stop("matrispace: `na_colour` is not a valid color", call. = FALSE)
  })
  value_name <- value %||% "value"
  if (is.matrix(data) || methods::is(data, "Matrix")) {
    m <- as.matrix(data)
    if (is.null(rownames(m))) rownames(m) <- as.character(seq_len(nrow(m)))
    if (is.null(colnames(m))) colnames(m) <- as.character(seq_len(ncol(m)))
    # Keep the matrix's own row and column order.
    df <- data.frame(
      row = factor(rep(rownames(m), times = ncol(m)), levels = unique(rownames(m))),
      column = factor(rep(colnames(m), each = nrow(m)), levels = unique(colnames(m))),
      value = as.numeric(m), stringsAsFactors = FALSE)
  } else if (is.data.frame(data)) {
    cat_cols <- names(data)[vapply(data,
      function(v) is.character(v) || is.factor(v), logical(1))]
    num_cols <- names(data)[vapply(data, is.numeric, logical(1))]
    pick <- function(cands, pool) {
      h <- intersect(cands, pool); if (length(h)) h[1] else NA_character_
    }
    auto_row <- is.null(row)
    if (auto_row) {
      # Prefer the human-readable `pair` for the axis over the slugged `pair_id`
      # (FIX_GUIDE s6); `pair_id` remains the collision-resistant identity below.
      row <- pick(c("pair", "feature", "gene", "pair_id"), cat_cols)
      if (is.na(row) && length(cat_cols)) row <- cat_cols[1]
    }
    if (is.null(column)) {
      pool <- setdiff(cat_cols, row)
      column <- pick(c("group", "cluster", "condition", "niche", "celltype"), pool)
      if (is.na(column) && length(pool)) column <- pool[1]
    }
    if (is.null(value)) {
      value <- pick(c("value", "mean_coexpression", "mean_activity", "avg_log2FC", "log2FoldChange",
                      "activity", "score", "stat"), num_cols)
      if (is.na(value) && length(num_cols)) value <- num_cols[1]
    }
    value_name <- value
    if (is.null(row) || is.na(row) || is.null(column) || is.na(column) ||
        is.null(value) || is.na(value)) {
      stop("matrispace: could not infer row/column/value; supply them explicitly ",
           "(need two label columns and one numeric column)", call. = FALSE)
    }
    for (nm in c(row = row, column = column, value = value)) {
      if (!(nm %in% names(data))) {
        stop("matrispace: column '", nm, "' not found in `data`", call. = FALSE)
      }
    }
    if (!is.numeric(data[[value]])) {
      stop("matrispace: value column '", value, "' must be numeric", call. = FALSE)
    }
    df <- data.frame(
      row = as.character(data[[row]]), column = as.character(data[[column]]),
      value = as.numeric(data[[value]]), stringsAsFactors = FALSE)
    # Collision-resistant identity: when `row` was auto-picked as the display
    # `pair`, use `pair_id` (if present) to decide what a genuine duplicate cell
    # is, so distinct pairs that happen to share a display label are NOT merged.
    id_col <- if (auto_row && row == "pair" && "pair_id" %in% names(data)) {
      "pair_id"
    } else {
      row
    }
    df$row_id <- as.character(data[[id_col]])
    dup <- duplicated(df[, c("row_id", "column")])
    if (any(dup)) {
      i <- which(dup)[1]
      stop("matrispace: duplicate row-column cell(s) (e.g. row='", df$row[i],
           "', column='", df$column[i], "'); supply row/column/value that ",
           "uniquely identify each cell", call. = FALSE)
    }
    # Disambiguate display labels that collide across DISTINCT identities: append
    # the short id only to the offending labels, leaving unique labels readable.
    if (id_col != row) {
      map <- unique(df[, c("row", "row_id")])
      collide <- names(which(tapply(map$row_id, map$row,
                                    function(z) length(unique(z)) > 1L)))
      if (length(collide)) {
        hit <- df$row %in% collide
        df$row[hit] <- paste0(df$row[hit], " (", df$row_id[hit], ")")
      }
    }
    df$row_id <- NULL
    # Preserve declared ordering from factor inputs before the generic fallback
    # below; data.frame() above intentionally standardized display values.
    df$column <- .group_factor(data[[column]])
    if (id_col == row) df$row <- .group_factor(data[[row]])
  } else {
    stop("matrispace: `data` must be a matrix or a data.frame", call. = FALSE)
  }
  # Apply the same ordering contract as grouped plots/statistics: declared
  # factor levels survive, while numeric text is ordered numerically (0, 1, 2,
  # ..., 10) rather than lexically (0, 1, 10, ...). This matters especially for
  # cluster axes after matrix/data-frame round trips.
  df$row <- .group_factor(df$row)
  df$column <- .group_factor(df$column)
  row_ordered <- is.ordered(df$row); column_ordered <- is.ordered(df$column)
  row_levels <- levels(df$row); column_levels <- levels(df$column)
  if (isTRUE(complete)) {
    grid <- expand.grid(row = row_levels, column = column_levels,
                        KEEP.OUT.ATTRS = FALSE, stringsAsFactors = FALSE)
    key <- paste(as.character(df$row), as.character(df$column), sep = "\r")
    idx <- match(paste(grid$row, grid$column, sep = "\r"), key)
    grid$value <- df$value[idx]
    df <- grid
    df$row <- factor(df$row, levels = row_levels, ordered = row_ordered)
    df$column <- factor(df$column, levels = column_levels,
                        ordered = column_ordered)
  }
  if (scale_by != "none") {
    margin <- if (scale_by == "row") df$row else df$column
    df$value <- stats::ave(df$value, margin, FUN = function(z) {
      s <- stats::sd(z, na.rm = TRUE)
      if (!is.finite(s) || s == 0) ifelse(is.na(z), NA_real_, 0) else
        (z - mean(z, na.rm = TRUE)) / s
    })
    value_name <- paste0(scale_by, " z-score")
  }
  resolved_center <- center
  if (identical(center, "auto")) {
    finite <- df$value[is.finite(df$value)]
    resolved_center <- if (length(finite) && min(finite) < 0 && max(finite) > 0) 0 else NULL
  }
  if (!is.null(resolved_center) && is.null(limits)) {
    d <- max(abs(df$value - resolved_center), na.rm = TRUE)
    if (is.finite(d) && d > 0) limits <- resolved_center + c(-d, d)
  }
  fill_scale <- if (is.null(resolved_center)) {
    if (is.null(colours)) {
      ggplot2::scale_fill_viridis_c(limits = limits, na.value = na_colour,
                                    oob = .squish)
    } else {
      ggplot2::scale_fill_gradientn(colours = colours, limits = limits,
                                    na.value = na_colour, oob = .squish)
    }
  } else {
    div <- if (length(colours) == 3L) colours else c("#3B4CC0", "#F7F7F7", "#B40426")
    ggplot2::scale_fill_gradient2(
      low = div[1], mid = div[2], high = div[3],
      midpoint = resolved_center, limits = limits, na.value = na_colour,
      oob = .squish)
  }
  p <- ggplot2::ggplot(df, ggplot2::aes(x = .data[["column"]], y = .data[["row"]],
                                        fill = .data[["value"]])) +
    ggplot2::geom_tile(colour = "white", linewidth = 0.2) +
    fill_scale +
    ggplot2::labs(x = NULL, y = NULL, fill = legend_title %||% value_name) +
    theme_matrispace() +
    # Tile boundaries already encode the matrix; grid lines only add clutter.
    ggplot2::theme(
      panel.grid = ggplot2::element_blank(),
      legend.position = legend_position,
      axis.text = ggplot2::element_text(colour = "black"),
      axis.text.x = ggplot2::element_text(
        angle = x_angle, hjust = if (x_angle == 0) 0.5 else 1,
        face = if (italic %in% c("columns", "both")) "italic" else "plain"),
      axis.text.y = ggplot2::element_text(
        face = if (italic %in% c("rows", "both")) "italic" else "plain"))
  x_lab <- .axis_labeller(column_labels, "column_labels")
  y_lab <- .axis_labeller(row_labels, "row_labels")
  p <- p + ggplot2::scale_x_discrete(drop = FALSE, labels = x_lab)
  if (isTRUE(reverse_rows)) {
    p <- p + ggplot2::scale_y_discrete(limits = rev(row_levels), drop = FALSE,
                                       labels = y_lab)
  } else {
    p <- p + ggplot2::scale_y_discrete(drop = FALSE, labels = y_lab)
  }
  p
}

# Turn a labelling function or named character vector into a scale labeller.
.axis_labeller <- function(x, name) {
  if (is.null(x)) return(ggplot2::waiver())
  if (is.function(x)) return(x)
  if (is.character(x) && !is.null(names(x))) {
    return(function(v) ifelse(v %in% names(x), unname(x[v]), v))
  }
  stop("matrispace: `", name, "` must be NULL, a function, or a named character vector",
       call. = FALSE)
}

#' Red-blue diverging colours used in the MatriSpace figures.
#'
#' @return Three colours (low, mid, high) for [plot_heatmap()] `colours`.
#' @export
palette_diverging <- function() c(low = "#2166AC", mid = "#F7F7F7", high = "#B2182B")

#' Plot a co-occurrence result (pure consumer; never recomputes).
#'
#' Draws the association ratio (or its log2) against distance, one colored series
#' per neighbor category `to`, faceted by focal category `from` when more than
#' one is shown. A reference line marks no association (1 for `ratio`, 0 for
#' `log2_ratio`). On the `log2_ratio` scale a zero ratio is `-Inf`; such points
#' are drawn as downward triangles at a finite display floor and the connecting
#' line breaks rather than implying a numeric trend through `-Inf`. On the
#' `ratio` scale a zero ratio is the finite value `0` and plots as an ordinary
#' point.
#'
#' @param result A [compute_cooccurrence()] data.frame.
#' @param from,to Optional character vectors restricting AND ordering the focal
#'   and neighbor categories.
#' @param value `"log2_ratio"` (default) or `"ratio"` on the y axis.
#' @param significance Optional alpha in `[0, 1]`; nonsignificant rows are faint.
#' @param p_column `"auto"` prefers adjusted p-values, or explicitly choose
#'   `"p_adjusted"`/`"p_value"`.
#' @param max_categories Safety limit per axis before explicit `from`/`to`
#'   selection is required.
#' @param palette Optional colors for `to`, preferably named by category.
#' @param facet_ncol Optional number of facet columns.
#' @param ... Must be empty; unknown arguments are rejected.
#' @return A ggplot.
#' @export
plot_cooccurrence <- function(result, from = NULL, to = NULL,
                              value = c("log2_ratio", "ratio"),
                              significance = NULL,
                              p_column = c("auto", "p_adjusted", "p_value"),
                              max_categories = 8L, palette = NULL,
                              facet_ncol = NULL, ...) {
  value <- match.arg(value)
  p_column <- match.arg(p_column)
  if (...length()) {
    stop("matrispace: unknown argument(s) passed to plot_cooccurrence()",
         call. = FALSE)
  }
  req <- c("from", "to", "distance_min", "distance_max", "distance_mid",
           "ratio", "log2_ratio")
  if (!is.data.frame(result) || !all(req %in% names(result))) {
    stop("matrispace: `result` must be a compute_cooccurrence() data.frame with ",
         "columns ", paste(req, collapse = ", "), call. = FALSE)
  }
  # Validate value TYPES/ranges, not just column presence, so a mislabeled table
  # cannot render as discrete axes or negative ratios.
  for (nm in c("distance_min", "distance_max", "distance_mid")) {
    if (!is.numeric(result[[nm]]) || any(!is.finite(result[[nm]]))) {
      stop("matrispace: `result$", nm, "` must be finite numeric", call. = FALSE)
    }
  }
  r <- result$ratio
  if (!is.numeric(r) || any(is.nan(r)) ||
      any(!is.na(r) & (!is.finite(r) | r < 0))) {
    stop("matrispace: `result$ratio` must be finite and non-negative, or NA",
         call. = FALSE)
  }
  if (!is.numeric(result$log2_ratio) || any(is.nan(result$log2_ratio)) ||
      any(result$log2_ratio == Inf, na.rm = TRUE)) {
    stop("matrispace: `result$log2_ratio` must be numeric (finite or -Inf)",
         call. = FALSE)
  }
  if (anyDuplicated(result[, c("from", "to", "distance_min", "distance_max")])) {
    stop("matrispace: `result` has duplicate from/to/distance-bin rows", call. = FALSE)
  }
  # Restrict to categories actually PRESENT in the data, preserving any declared
  # factor-level order. Unused factor levels must not inflate the max_categories
  # guard below, nor appear as phantom keys in the (drop = FALSE) colour legend.
  present_levels <- function(x) {
    lv <- levels(x) %||% unique(as.character(x))
    intersect(lv, unique(as.character(x)))
  }
  from_all <- present_levels(result$from)
  to_all <- present_levels(result$to)
  check_subset <- function(requested, present, what) {
    if (is.null(requested)) return(present)
    if (!is.character(requested) || !length(requested)) {
      stop("matrispace: `", what, "` must be a non-empty character vector",
           call. = FALSE)
    }
    if (anyDuplicated(requested)) {
      stop("matrispace: `", what, "` must not contain duplicate values", call. = FALSE)
    }
    unknown <- setdiff(requested, present)
    if (length(unknown)) {
      stop("matrispace: unknown ", what, ": ", paste(unknown, collapse = ", "),
           " (available: ", paste(present, collapse = ", "), ")", call. = FALSE)
    }
    requested
  }
  from_levels <- check_subset(from, from_all, "from")
  to_levels <- check_subset(to, to_all, "to")
  if (!(is.numeric(max_categories) && length(max_categories) == 1L &&
        is.finite(max_categories) && max_categories >= 1 &&
        max_categories == round(max_categories))) {
    stop("matrispace: `max_categories` must be a positive whole number",
         call. = FALSE)
  }
  if (length(from_levels) > max_categories || length(to_levels) > max_categories) {
    stop("matrispace: co-occurrence would draw ", length(from_levels),
         " focal x ", length(to_levels), " neighbor categories; select `from` ",
         "and/or `to`, or deliberately raise `max_categories` (default ",
         max_categories, ").", call. = FALSE)
  }
  if (!is.null(facet_ncol) && !(is.numeric(facet_ncol) && length(facet_ncol) == 1L &&
      is.finite(facet_ncol) && facet_ncol >= 1 && facet_ncol == round(facet_ncol))) {
    stop("matrispace: `facet_ncol` must be NULL or a positive whole number",
         call. = FALSE)
  }

  df <- result[as.character(result$from) %in% from_levels &
                 as.character(result$to) %in% to_levels, , drop = FALSE]
  df$from <- factor(as.character(df$from), levels = from_levels)
  df$to <- factor(as.character(df$to), levels = to_levels)

  yv <- df[[value]]
  is_floor <- is.infinite(yv) & yv < 0                  # zero ratio (log2 = -Inf)
  finite <- yv[is.finite(yv)]
  floor_val <- if (length(finite)) {
    min(finite) - 0.05 * (diff(range(finite)) + 1)
  } else if (value == "log2_ratio") -1 else 0
  df$.y <- yv; df$.y[is_floor] <- floor_val
  df$.floored <- is_floor
  df$.line_y <- df$.y; df$.line_y[is_floor] <- NA_real_
  # A FACTOR (not the raw logical) for the shape aesthetic: ggplot2 (>= 4.0)
  # matches manual-scale value NAMES against the aesthetic's levels, and a
  # logical never shares levels with character names "FALSE"/"TRUE", which
  # silently drops the zero-ratio markers. Fixed two levels keep the mapping and
  # legend stable even when only one is present.
  df$.floored_shape <- factor(df$.floored, levels = c(FALSE, TRUE))
  df <- df[!is.na(df$.y), , drop = FALSE]               # undefined cells cannot plot

  has_sig <- !is.null(significance)
  if (has_sig) {
    if (!(is.numeric(significance) && length(significance) == 1L &&
          is.finite(significance) && significance >= 0 && significance <= 1)) {
      stop("matrispace: `significance` must be a single number in [0, 1]",
           call. = FALSE)
    }
    if (p_column == "auto") {
      p_column <- if ("p_adjusted" %in% names(df)) "p_adjusted" else "p_value"
    }
    if (!(p_column %in% names(df))) {
      stop("matrispace: `significance` needs a `", p_column,
           "` column in `result`", call. = FALSE)
    }
    pv <- df[[p_column]]
    if (!is.numeric(pv) || any(pv[!is.na(pv)] < 0 | pv[!is.na(pv)] > 1)) {
      stop("matrispace: `result$", p_column, "` must be numeric in [0, 1]",
           call. = FALSE)
    }
    df$.alpha <- ifelse(!is.na(pv) & pv <= significance, 1, 0.18)
  } else {
    df$.alpha <- 1
  }

  ref <- if (value == "ratio") 1 else 0
  p <- ggplot2::ggplot(df, ggplot2::aes(x = .data[["distance_mid"]],
                                        y = .data[[".y"]],
                                        colour = .data[["to"]],
                                        group = .data[["to"]])) +
    ggplot2::geom_hline(yintercept = ref, linetype = "dashed", colour = "grey50") +
    ggplot2::geom_line(ggplot2::aes(y = .data[[".line_y"]],
                                    alpha = .data[[".alpha"]]), na.rm = TRUE) +
    ggplot2::scale_alpha_identity() +
    ggplot2::scale_colour_manual(values = .annotation_colours(df$to, palette),
                                 drop = FALSE)
  if (any(df$.floored)) {
    p <- p +
      ggplot2::geom_point(ggplot2::aes(alpha = .data[[".alpha"]],
                                       shape = .data[[".floored_shape"]])) +
      ggplot2::scale_shape_manual(
        values = c(`FALSE` = 16, `TRUE` = 25), breaks = "TRUE",
        labels = "Zero ratio", name = NULL)
  } else {
    p <- p + ggplot2::geom_point(ggplot2::aes(alpha = .data[[".alpha"]]))
  }
  if (nlevels(droplevels(df$from)) > 1L) {
    p <- p + ggplot2::facet_wrap(ggplot2::vars(.data[["from"]]),
                                 ncol = facet_ncol)
  }
  ylab <- if (value == "ratio") "co-occurrence ratio" else "log2 co-occurrence ratio"
  units <- if ("coordinate_units" %in% names(df))
    unique(stats::na.omit(as.character(df$coordinate_units))) else character()
  xlab <- if (length(units) == 1L && nzchar(units))
    paste0("distance (", units, ")") else "distance"
  p +
    ggplot2::labs(x = xlab, y = ylab, colour = "to",
                  caption = if (any(df$.floored))
                    "Downward triangles denote zero ratios (-Inf on the log2 scale)." else NULL) +
    theme_matrispace() +
    # Quantitative y guide retained; vertical panel grid lines removed.
    ggplot2::theme(panel.grid.major.x = ggplot2::element_blank(),
                   panel.grid.minor.x = ggplot2::element_blank())
}
