# Matrisome-pair co-expression (SPEC s9). Spatially weighted co-expression of two
# genes over a NAMED graph:
#   coexpression[pair, i] = sqrt(max(gene_2_i, 0)) * sum_j W[i,j] * sqrt(max(gene_1_j, 0))
# i.e. gene_2 measured at spot i and gene_1 measured in the neighbourhood of i.
# The score measures where the two members of a pair are expressed together; it
# does not infer signalling direction or binding.
#
# Pairs come from MatriComDB, where at least one member is a matrisome gene. The
# bundled `matrisome_pairs` table holds one alphabetically ordered row per unique
# heterotypic pair. User-supplied tables keep their own member order.
#
# Sparsity contract: only SCORABLE pairs (both genes present) are stored, as a
# sparse pairs x spots matrix. Missing pairs are recorded structurally in the
# manifest (never materialized as explicit-NA rows), so a database with many
# absent genes cannot blow up the stored result.

.pair_artifact <- "matrisome_pair_coexpression"

# Human-readable DISPLAY key (may not be unique if a gene name contains "__").
.pair_display <- function(gene_1, gene_2) paste(gene_1, gene_2, sep = "__")

# Collision-resistant MACHINE id: a per-tuple hash. Distinct tuples get distinct
# ids even when their display keys would collide (e.g. ("a__b","c") vs ("a","b__c")).
.pair_id <- function(gene_1, gene_2) {
  vapply(seq_along(gene_1),
         function(i) digest::digest(list(gene_1[i], gene_2[i]), algo = "xxhash64"),
         character(1))
}

# Order-invariant, association-preserving digest of a pair set.
.pairs_digest <- function(gene_1, gene_2) {
  digest::digest(sort(.pair_id(gene_1, gene_2)), algo = "xxhash64")
}

# sqrt(max(x, 0)) on a sparse matrix without densifying (operate on stored values).
.sqrt_pos <- function(m) {
  m <- methods::as(m, "CsparseMatrix")
  m@x <- sqrt(pmax(m@x, 0))
  Matrix::drop0(m)
}

# Accept `gene_1`/`gene_2` (preferred) or legacy `ligand`/`receptor` columns.
.as_pair_table <- function(pairs) {
  if (!is.data.frame(pairs)) {
    stop("matrispace: `pairs` must be a data.frame with `gene_1` and `gene_2`",
         call. = FALSE)
  }
  cols <- if (all(c("gene_1", "gene_2") %in% colnames(pairs))) {
    c("gene_1", "gene_2")
  } else if (all(c("ligand", "receptor") %in% colnames(pairs))) {
    c("ligand", "receptor")
  } else {
    stop("matrispace: `pairs` must be a data.frame with `gene_1` and `gene_2`",
         call. = FALSE)
  }
  if (nrow(pairs) == 0L) stop("matrispace: `pairs` is empty", call. = FALSE)
  out <- data.frame(gene_1 = as.character(pairs[[cols[1]]]),
                    gene_2 = as.character(pairs[[cols[2]]]),
                    stringsAsFactors = FALSE)
  if (anyNA(out) || any(!nzchar(out$gene_1)) || any(!nzchar(out$gene_2))) {
    stop("matrispace: `pairs` contain NA or empty gene names", call. = FALSE)
  }
  out
}

.require_pair_artifact <- function(object) {
  reg <- .get_registry(object)
  if (is.null(reg) || !(.pair_artifact %in% names(reg$artifacts))) {
    stop("matrispace: object has no matrisome-pair co-expression; run ",
         "score_matrisome_pair_coexpression() first", call. = FALSE)
  }
  reg$artifacts[[.pair_artifact]]$parameters
}

#' Score spatial co-expression of matrisome pairs on a named graph.
#'
#' For each pair, the score at a spot is the square-root expression of `gene_2`
#' in that spot multiplied by the weighted sum of square-root `gene_1`
#' expression in its neighbouring spots. The score shows where the two members
#' of a pair are expressed together; it does not infer signalling direction or
#' protein binding. Homomeric rows (`gene_1 == gene_2`) and duplicate rows are
#' removed before scoring.
#'
#' @param object A Seurat or SpatialExperiment object with a stored graph.
#' @param pairs A data.frame with `gene_1` and `gene_2` columns (legacy
#'   `ligand`/`receptor` columns are also accepted). Defaults to the bundled
#'   [matrisome_pairs].
#' @param graph Name of a stored graph (may be directed).
#' @param assay,layer Explicit expression source (negatives truncated; non-finite errors).
#' @param weight Weight transform (default "row_standardize"; "binary" for legacy).
#' @param chunk_size Pairs processed per chunk (NULL = all scorable at once).
#' @param sigma,eps Weight-transform parameters.
#' @param database Optional source-database identifier (scalar string or NA).
#' @param ... Unused.
#' @return The object with a matrisome-pair co-expression (scorable pairs x
#'   spots) artifact.
#' @export
score_matrisome_pair_coexpression <- function(object, pairs = matrisome_pairs, graph,
                                              assay, layer = NULL,
                                              weight = "row_standardize",
                                              chunk_size = NULL,
                                              sigma = NULL, eps = NULL,
                                              database = NULL, ...) {
  bundled_pairs <- missing(pairs)
  if (is.null(database)) {
    database <- if (bundled_pairs) "MatriComDB / MatriSpace authoritative snapshot"
                else NA_character_
  }
  pairs <- .as_pair_table(pairs)
  .check_weight_args(weight, sigma, eps)
  if (missing(assay)) stop("matrispace: `assay` is required", call. = FALSE)
  if (!is.null(chunk_size) && !.is_pos_whole(chunk_size)) {
    stop("matrispace: `chunk_size` must be a positive whole number", call. = FALSE)
  }
  if (!(length(database) == 1L && (is.na(database) || .is_nonempty_scalar_chr(database)))) {
    stop("matrispace: `database` must be a scalar string or NA", call. = FALSE)
  }

  # Remove homomeric rows, then deduplicate on the (gene_1, gene_2) tuple.
  homomeric <- pairs$gene_1 == pairs$gene_2
  n_homomeric <- sum(homomeric)
  pairs <- pairs[!homomeric, , drop = FALSE]
  if (nrow(pairs) == 0L) {
    stop("matrispace: `pairs` contain only homomeric rows (gene_1 == gene_2)",
         call. = FALSE)
  }
  pairs <- pairs[!duplicated(pairs), , drop = FALSE]
  pair_ids <- .pair_id(pairs$gene_1, pairs$gene_2)
  n_pairs <- nrow(pairs)

  g <- .resolve_graph(object, graph)                 # directed allowed
  needs_dist <- weight %in% c("inverse_distance", "gaussian")
  Wt <- .as_general_csparse(transform_weights(g$connectivities,
          distances = if (needs_dist) g$distances else NULL,
          method = weight, sigma = sigma, eps = eps))
  tWt <- Matrix::t(Wt)

  expr <- .get_expression(object, assay = assay, layer = layer)
  .validate_finite(expr, "expression")
  spots <- g$spot_ids
  expr <- methods::as(expr[, spots, drop = FALSE], "CsparseMatrix")
  genes <- rownames(expr)

  scorable <- pairs$gene_1 %in% genes & pairs$gene_2 %in% genes
  sidx <- which(scorable)
  n_scorable <- length(sidx)
  chunk_eff <- if (n_scorable == 0L) 0L
    else if (is.null(chunk_size)) n_scorable
    else min(as.integer(chunk_size), n_scorable)

  if (n_scorable) {
    parts <- lapply(split(sidx, ceiling(seq_along(sidx) / chunk_eff)), function(ci) {
      sqrt1 <- .sqrt_pos(expr[pairs$gene_1[ci], , drop = FALSE])
      sqrt2 <- .sqrt_pos(expr[pairs$gene_2[ci], , drop = FALSE])
      methods::as(sqrt2 * (sqrt1 %*% tWt), "CsparseMatrix")
    })
    scorable_act <- do.call(rbind, parts)
  } else {
    scorable_act <- Matrix::Matrix(0, 0, length(spots), sparse = TRUE)
  }
  rownames(scorable_act) <- pair_ids[sidx]
  colnames(scorable_act) <- spots

  akey <- .key_feature_result(.pair_artifact)
  materialized <- n_scorable > 0L
  if (materialized) {
    m <- scorable_act[, colnames(object), drop = FALSE]
    .validate_feature_matrix(m, colnames(object))
    object <- .store_feature_result(object, akey, m)
  } else {
    object <- .remove_feature_result(object, akey)
  }
  man <- .new_manifest(storage = akey, layer = "data", type = "activity",
    producer = "score_matrisome_pair_coexpression",
    input_assay = assay %||% NA_character_,
    input_layer = layer %||% NA_character_,
    parameters = list(
      gene_1 = pairs$gene_1, gene_2 = pairs$gene_2, scorable = scorable,
      materialized = materialized, graph = graph,
      graph_fingerprint = g$coordinate_fingerprint,
      weight = weight, sigma = sigma %||% NA_real_, eps = eps %||% NA_real_,
      directed = isTRUE(g$directed), n_pairs = n_pairs, n_missing = sum(!scorable),
      n_homomeric = n_homomeric,
      chunk_size = chunk_size %||% NA_integer_, chunk_size_effective = chunk_eff,
      database = database,
      pair_digest = .pairs_digest(pairs$gene_1, pairs$gene_2)))
  .validate_manifest(man)
  reg <- .get_registry(object) %||% .new_registry()
  reg$artifacts[[.pair_artifact]] <- man
  reg <- .registry_append_history(reg, "score_matrisome_pair_coexpression",
                                  list(n_pairs = n_pairs, n_missing = sum(!scorable)))
  .set_registry(object, reg)
}

# A synthesized empty (0 x spots) sparse co-expression matrix.
.pair_empty_matrix <- function(object) {
  Matrix::Matrix(0, 0, ncol(object), sparse = TRUE,
                 dimnames = list(character(0), colnames(object)))
}

#' Retrieve the stored matrisome-pair co-expression matrix.
#'
#' @param object A Seurat or SpatialExperiment object.
#' @param names `"id"` (default) uses the collision-resistant pair ids as row
#'   names; `"pair"` uses readable `GENE1__GENE2` names.
#' @return A sparse scorable-pairs x spots matrix. Missing pairs are not rows;
#'   identify them via `missing_matrisome_pairs()`.
#' @export
get_matrisome_pair_coexpression <- function(object, names = c("id", "pair")) {
  names <- match.arg(names)
  p <- .require_pair_artifact(object)
  if (!isTRUE(p$materialized)) return(.pair_empty_matrix(object))
  act <- .get_feature_result(object, .pair_artifact)
  # Row names come from the manifest, not the stored feature names (Seurat
  # mangles some characters in assay feature names).
  rownames(act) <- if (names == "id") {
    .pair_id(p$gene_1, p$gene_2)[p$scorable]
  } else {
    .pair_display(p$gene_1, p$gene_2)[p$scorable]
  }
  act
}

#' Matrisome pairs that could not be scored (a gene absent from the data).
#' @param object A Seurat or SpatialExperiment object with stored pair co-expression.
#' @return A data.frame of missing `gene_1`/`gene_2` pairs (possibly empty).
#' @export
missing_matrisome_pairs <- function(object) {
  p <- .require_pair_artifact(object)
  miss <- !p$scorable
  data.frame(gene_1 = p$gene_1[miss], gene_2 = p$gene_2[miss],
             stringsAsFactors = FALSE)
}

#' Mean matrisome-pair co-expression per group.
#'
#' Sparse-aware (never densifies the co-expression matrix). Reports every pair;
#' a missing pair (or a group with no spots) yields `NA` mean co-expression.
#'
#' @param object A Seurat or SpatialExperiment object with stored pair co-expression.
#' @param group_by Spot-metadata column naming the groups.
#' @param ... Unused.
#' @return A data.frame (one row per pair x group) with columns `gene_1`,
#'   `gene_2`, `pair`, `pair_id`, `group`, `mean_coexpression` and `n_spots`;
#'   the object is not mutated.
#' @export
find_matrisome_pair_enrichment <- function(object, group_by, ...) {
  if (!.is_nonempty_scalar_chr(group_by)) {
    stop("matrispace: `group_by` must be a single metadata column name", call. = FALSE)
  }
  p <- .require_pair_artifact(object)
  act <- if (!isTRUE(p$materialized)) .pair_empty_matrix(object) else
    .get_feature_result(object, .pair_artifact)
  md <- .get_spot_metadata(object)
  if (!(group_by %in% colnames(md))) {
    stop("matrispace: group_by column '", group_by, "' not found", call. = FALSE)
  }
  labels <- as.character(md[colnames(act), group_by])
  groups <- sort(unique(labels[!is.na(labels) & nzchar(labels)]))
  pair_id <- .pair_id(p$gene_1, p$gene_2)
  display <- .pair_display(p$gene_1, p$gene_2)
  if (length(groups) == 0L) {
    return(data.frame(gene_1 = character(0), gene_2 = character(0),
                      pair = character(0), pair_id = character(0),
                      group = character(0), mean_coexpression = numeric(0),
                      n_spots = integer(0), stringsAsFactors = FALSE))
  }
  scor_ids <- pair_id[p$scorable]
  rows <- lapply(groups, function(gp) {
    cols <- which(labels == gp)
    mean_by_id <- stats::setNames(rep(NA_real_, length(pair_id)), pair_id)
    if (length(cols) && nrow(act)) {
      mean_by_id[scor_ids] <- as.numeric(Matrix::rowMeans(act[, cols, drop = FALSE]))
    }
    data.frame(gene_1 = p$gene_1, gene_2 = p$gene_2, pair = display,
               pair_id = pair_id, group = gp,
               mean_coexpression = as.numeric(mean_by_id), n_spots = length(cols),
               stringsAsFactors = FALSE)
  })
  res <- do.call(rbind, rows)
  rownames(res) <- NULL
  res
}

# ---- Deprecated ligand-receptor names ------------------------------------------

#' Deprecated ligand-receptor function names
#'
#' These names were used before the matrisome-pair terminology. They call the
#' matrisome-pair functions and will be removed in a future release.
#'
#' @param object,pairs,graph,assay,layer,group_by,... Passed to the
#'   matrisome-pair functions.
#' @return See [score_matrisome_pair_coexpression()],
#'   [get_matrisome_pair_coexpression()], [missing_matrisome_pairs()] and
#'   [find_matrisome_pair_enrichment()].
#' @name matrispace-deprecated
#' @keywords internal
NULL

#' @rdname matrispace-deprecated
#' @export
score_lr_activity <- function(object, pairs = matrisome_pairs, graph, assay,
                              layer = NULL, ...) {
  .Deprecated("score_matrisome_pair_coexpression", package = "matrispace")
  if (missing(pairs)) {
    score_matrisome_pair_coexpression(object, graph = graph, assay = assay,
                                      layer = layer, ...)
  } else {
    score_matrisome_pair_coexpression(object, pairs = pairs, graph = graph,
                                      assay = assay, layer = layer, ...)
  }
}

#' @rdname matrispace-deprecated
#' @export
get_lr_activity <- function(object) {
  .Deprecated("get_matrisome_pair_coexpression", package = "matrispace")
  get_matrisome_pair_coexpression(object)
}

#' @rdname matrispace-deprecated
#' @export
lr_missing_pairs <- function(object) {
  .Deprecated("missing_matrisome_pairs", package = "matrispace")
  missing_matrisome_pairs(object)
}

#' @rdname matrispace-deprecated
#' @export
find_lr_enrichment <- function(object, group_by, ...) {
  .Deprecated("find_matrisome_pair_enrichment", package = "matrispace")
  find_matrisome_pair_enrichment(object, group_by, ...)
}
