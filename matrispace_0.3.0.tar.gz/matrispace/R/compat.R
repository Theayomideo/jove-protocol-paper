# Container-independent accessor/setter contract (SPEC s4). Public algorithms
# call ONLY these; all container-specific code is confined to compat-seurat.R
# and compat-spatialexperiment.R. Registry lifecycle and manifest resolution are
# centralized here so both containers behave identically.

.container_kind <- function(object) {
  if (methods::is(object, "Seurat")) return("seurat")
  if (methods::is(object, "SpatialExperiment")) return("spe")
  stop("matrispace: unsupported container class '",
       paste(class(object), collapse = ", "),
       "'. Expected a Seurat or SpatialExperiment object.", call. = FALSE)
}

#' @keywords internal
.get_expression <- function(object, assay = NULL, layer = NULL) {
  # Resolve + validate the (assay, layer) pair up front so an absent layer
  # reports itself (with the valid choices) instead of masquerading later as a
  # missing feature (FIX_GUIDE s3).
  src <- .resolve_expression_source(object, assay = assay, layer = layer)
  switch(.container_kind(object),
    seurat = .get_expression_seurat(object, src$assay, src$layer),
    spe    = .get_expression_spe(object, src$assay, src$layer))
}

# Resolve the default assay, enumerate its available layers, and fail early with
# an actionable error (listing available assays/layers) when the requested or
# default layer is absent. Never guesses which layer is normalized.
#' @keywords internal
.resolve_expression_source <- function(object, assay = NULL, layer = NULL) {
  switch(.container_kind(object),
    seurat = .resolve_expression_source_seurat(object, assay, layer),
    spe    = .resolve_expression_source_spe(object, assay, layer))
}

#' @keywords internal
.get_counts <- function(object, assay = NULL) {
  switch(.container_kind(object),
    seurat = .get_counts_seurat(object, assay),
    spe    = .get_counts_spe(object, assay))
}

#' @keywords internal
.get_coordinates <- function(object, image_id = NULL) {
  switch(.container_kind(object),
    seurat = .get_coordinates_seurat(object, image_id),
    spe    = .get_coordinates_spe(object, image_id))
}

#' @keywords internal
.get_image_membership <- function(object) {
  switch(.container_kind(object),
    seurat = .get_image_membership_seurat(object),
    spe    = .get_image_membership_spe(object))
}

# Optional histology raster / scale factor for a given image + resolution.
# Both return NULL when unavailable so plotting falls back to coordinate-only.
#' @keywords internal
.get_spatial_image <- function(object, image_id, image_scale) {
  switch(.container_kind(object),
    seurat = .get_spatial_image_seurat(object, image_id, image_scale),
    spe    = .get_spatial_image_spe(object, image_id, image_scale))
}

#' @keywords internal
.get_spatial_scale_factor <- function(object, image_id, image_scale) {
  switch(.container_kind(object),
    seurat = .get_spatial_scale_factor_seurat(object, image_id, image_scale),
    spe    = .get_spatial_scale_factor_spe(object, image_id, image_scale))
}

# Whether increasing y moves downward on the rendered spatial canvas. This is
# presentation metadata only: algorithms always consume the stored coordinates
# unchanged. NULL means the adapter cannot determine the convention.
#' @keywords internal
.spatial_y_is_down <- function(object, image_id = NULL) {
  switch(.container_kind(object),
    seurat = .spatial_y_is_down_seurat(object, image_id),
    spe    = .spatial_y_is_down_spe(object, image_id))
}

#' @keywords internal
.get_spot_metadata <- function(object) {
  switch(.container_kind(object),
    seurat = .get_spot_metadata_seurat(object),
    spe    = .get_spot_metadata_spe(object))
}

#' @keywords internal
.set_spot_metadata <- function(object, name, value) {
  switch(.container_kind(object),
    seurat = .set_spot_metadata_seurat(object, name, value),
    spe    = .set_spot_metadata_spe(object, name, value))
}

# ---- Registry: read -> validate -> migrate -> use (SPEC s3.1) ---------------

#' @keywords internal
.get_registry <- function(object) {
  raw <- switch(.container_kind(object),
    seurat = .get_registry_raw_seurat(object),
    spe    = .get_registry_raw_spe(object))
  if (is.null(raw)) return(NULL)
  raw <- .migrate_registry(raw)   # in-memory lift to the current schema
  .validate_registry(raw)
  raw
}

#' @keywords internal
.set_registry <- function(object, registry) {
  registry <- .migrate_registry(registry)  # rejects future/unknown, lifts old
  .validate_registry(registry)
  switch(.container_kind(object),
    seurat = .set_registry_raw_seurat(object, registry),
    spe    = .set_registry_raw_spe(object, registry))
}

# ---- Feature results: physical storage (container) + manifest (registry) ----

#' @keywords internal
.set_feature_result <- function(object, name, matrix, type, context = list()) {
  akey <- .key_feature_result(name)
  .validate_feature_matrix(matrix, colnames(object))
  matrix <- matrix[, colnames(object), drop = FALSE]
  object <- switch(.container_kind(object),
    seurat = .store_feature_result_seurat(object, akey, matrix),
    spe    = .store_feature_result_spe(object, akey, matrix))

  man <- do.call(.new_manifest,
                 c(list(storage = akey, layer = "data", type = type), context))
  .validate_manifest(man)

  reg <- .get_registry(object) %||% .new_registry()
  reg$artifacts[[name]] <- man
  reg <- .registry_append_history(reg, "set_feature_result",
                                  list(name = name, type = type))
  .set_registry(object, reg)
}

#' @keywords internal
.store_feature_result <- function(object, akey, matrix) {
  switch(.container_kind(object),
    seurat = .store_feature_result_seurat(object, akey, matrix),
    spe    = .store_feature_result_spe(object, akey, matrix))
}

# Remove a previously-stored physical feature result (no-op if absent).
#' @keywords internal
.remove_feature_result <- function(object, akey) {
  switch(.container_kind(object),
    seurat = .remove_feature_result_seurat(object, akey),
    spe    = .remove_feature_result_spe(object, akey))
}

#' @keywords internal
.get_feature_result <- function(object, name) {
  reg <- .get_registry(object)
  man <- if (is.null(reg)) NULL else reg$artifacts[[name]]
  if (is.null(man)) {
    stop("matrispace: no registered feature result named '", name,
         "'. A physical assay without a registry artifact is not a matrispace ",
         "result.", call. = FALSE)
  }
  switch(.container_kind(object),
    seurat = .read_feature_result_seurat(object, man$storage, man$layer),
    spe    = .read_feature_result_spe(object, man$storage, man$layer))
}

# Complete, order-invariant fingerprint of a stored computation: the canonical
# gene-set definition PLUS every other result-changing input (resolved
# assay/layer and the numeric parameters). Two runs share a fingerprint iff they
# would produce the same artifact, so the overwrite guard cannot be fooled by
# holding the genes fixed while changing maxRank, a threshold, or the layer.
#' @keywords internal
.computation_fingerprint <- function(definition, assay, layer, params) {
  .definition_digest(list(
    definition = definition,
    assay = assay %||% NA_character_,
    layer = layer %||% NA_character_,
    params = params))
}

# Decide what a (re)score should do with an existing canonical artifact
# (FIX_GUIDE s5). Returns "proceed" (compute + store) or "skip" (identical
# computation already stored -> return the object untouched, no recompute).
# Errors when the artifact differs and overwrite is not authorized; an existing
# artifact WITHOUT a comparable fingerprint fails safely (cannot prove a match).
#' @keywords internal
.overwrite_decision <- function(object, artifact, new_fp, overwrite, producer) {
  if (isTRUE(overwrite)) return("proceed")            # explicit replacement
  reg <- .get_registry(object)
  man <- if (is.null(reg)) NULL else reg$artifacts[[artifact]]
  if (is.null(man)) return("proceed")                 # nothing to clobber
  old_fp <- man$parameters$fingerprint
  if (!is.null(old_fp) && identical(old_fp, new_fp)) {
    return("skip")                                    # idempotent: same inputs
  }
  stop("matrispace: ", producer, "() would replace the existing '", artifact,
       "' artifact, which was computed from a different definition, assay/layer, ",
       "or parameters. Pass overwrite = TRUE to replace it, or select all desired ",
       "inputs in a single call (results are not appended across calls).",
       call. = FALSE)
}

# ---- Shared helpers ---------------------------------------------------------

# Validate a features x spots result matrix before storage: matrix-like, with
# unique non-empty feature and spot ids, and every object spot present.
.validate_feature_matrix <- function(m, spots) {
  if (!(is.matrix(m) || methods::is(m, "Matrix"))) {
    stop("matrispace: feature result must be a matrix", call. = FALSE)
  }
  sn <- colnames(m)
  if (is.null(sn) || anyNA(sn) || any(!nzchar(sn)) || anyDuplicated(sn)) {
    stop("matrispace: feature result needs unique, non-empty spot (column) ids",
         call. = FALSE)
  }
  missing <- setdiff(spots, sn)
  if (length(missing)) {
    stop("matrispace: feature result is missing ", length(missing),
         " object spot(s)", call. = FALSE)
  }
  # A zero-row result (e.g. no scorable L-R pairs) is valid; only check feature
  # ids when there are features.
  if (nrow(m) > 0L) {
    fn <- rownames(m)
    if (is.null(fn) || anyNA(fn) || any(!nzchar(fn)) || anyDuplicated(fn)) {
      stop("matrispace: feature result needs unique, non-empty feature (row) ids",
           call. = FALSE)
    }
  }
  invisible(TRUE)
}

# Align a per-spot value to the object's spot order. Named values are reordered
# by spot id (required ids must be present and unique); unnamed values are used
# positionally with a length check.
.align_to_spots <- function(value, spots) {
  if (!is.null(names(value))) {
    if (anyDuplicated(names(value))) {
      stop("matrispace: value has duplicated spot names", call. = FALSE)
    }
    missing <- setdiff(spots, names(value))
    if (length(missing)) {
      stop("matrispace: value is missing ", length(missing), " required spot(s)",
           call. = FALSE)
    }
    return(value[spots])
  }
  if (length(value) != length(spots)) {
    stop("matrispace: unnamed value length (", length(value),
         ") does not match spot count (", length(spots), ")", call. = FALSE)
  }
  value
}
