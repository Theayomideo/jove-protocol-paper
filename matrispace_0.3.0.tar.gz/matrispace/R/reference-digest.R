# Canonical, load-path-independent AND collision-safe digest of a bundled
# reference object.
#
# Two requirements:
#  1. Load-path independence -- R's serialize() encodes the SAME logical object
#     differently for a freshly load()ed copy vs a LazyData/ALTREP-materialized
#     one, so hashing serialize() output is not reproducible.
#  2. Collision safety -- the encoding is INJECTIVE over the SUPPORTED DOMAIN so
#     semantically different objects hash differently.
#
# SUPPORTED DOMAIN (the bundled-reference schema): plain data frames (character/
# integer/double/logical columns), nested plain lists, 1-D atomic vectors of
# type logical/integer/double/character, and factors (ordered or unordered).
# Anything outside it -- matrices/arrays or other dimensioned objects, custom-
# classed atomics/lists, S4/environments/closures, and unsupported atomic types
# -- is REJECTED with an error rather than silently under-encoded, so the seal
# cannot be fooled by an unrecorded attribute. Extend the encoder (and this
# domain statement) before adding a reference object of a new shape.
#
# Encoding: every node is a length-prefixed frame `TAG:<nchar>:<body>` (so
# concatenation is unambiguously decodable, hence injective), recording explicit
# type, length, names (NULL distinguished from any actual names), data-frame
# dimensions + row names, factor ordered-status + levels + codes, and per-element
# tokens where NA is a dedicated token distinct from every string. Values pass
# through as.character() so ALTREP/lazy encodings collapse to identical text.
# digest() then hashes one ordinary CHARSXP. Single source of truth used both to
# SEAL (data-raw) and VERIFY (tests) object_sha256.
#
# Self-contained (only `digest`) so data-raw/build-reference-data.R can source().

# Length-prefixed frame: TAG + ":" + nchar(body) + ":" + body. Because the body
# length is known, any concatenation of frames is unambiguously decodable.
.cf <- function(tag, body) {
  paste0(tag, ":", nchar(body, type = "chars"), ":", body)
}

# Encode a character vector's ELEMENTS: count + one token each. A non-NA string
# is "S<len>:<chars>" (self-delimiting); NA is the bare token "N" (distinct from
# "S0:" = "" and "S2:NA" = the literal "NA").
.cf_elems <- function(chr) {
  chr <- as.character(chr)
  toks <- ifelse(is.na(chr), "N",
                 paste0("S", nchar(chr, type = "chars"), ":", chr))
  paste0(length(chr), "|", paste0(toks, collapse = ""))
}

# NULL names encode distinctly from any actual (possibly NA/empty) names.
.cf_names <- function(x) {
  nms <- names(x)
  if (is.null(nms)) .cf("names", "NULL") else .cf("names", .cf_elems(nms))
}

# Injective canonical encoding over the supported reference domain.
.canon_encode <- function(x) {
  if (is.data.frame(x)) {
    body <- paste0(
      .cf("nrow", as.character(nrow(x))),
      .cf("ncol", as.character(ncol(x))),
      .cf_names(x),
      .cf("rownames", .cf_elems(rownames(x))),
      .cf("cols", paste0(vapply(x, .canon_encode, character(1)), collapse = "")))
    return(.cf("DF", body))
  }
  if (is.factor(x)) {
    body <- paste0(
      .cf("type", "factor"), .cf_names(x),
      .cf("ordered", as.character(is.ordered(x))),
      .cf("levels", .cf_elems(levels(x))),
      .cf("codes", .cf_elems(as.character(unclass(x)))))
    return(.cf("ATOM", body))
  }
  # Beyond here only PLAIN (unclassed), non-dimensioned lists/atomics are in the
  # supported domain; reject anything else so the seal never under-encodes.
  if (!is.null(oldClass(x))) {
    stop("reference digest: unsupported classed object '",
         paste(class(x), collapse = ", "), "'", call. = FALSE)
  }
  if (!is.null(dim(x))) {
    stop("reference digest: unsupported dimensioned object (matrix/array)",
         call. = FALSE)
  }
  if (is.list(x)) {
    body <- paste0(
      .cf("len", as.character(length(x))),
      .cf_names(x),
      .cf("elems", paste0(vapply(x, .canon_encode, character(1)), collapse = "")))
    return(.cf("LIST", body))
  }
  ty <- typeof(x)
  if (!ty %in% c("logical", "integer", "double", "character")) {
    stop("reference digest: unsupported atomic type '", ty, "'", call. = FALSE)
  }
  body <- paste0(.cf("type", ty), .cf_names(x),
                 .cf("vals", .cf_elems(as.character(x))))
  .cf("ATOM", body)
}

# Canonical SHA-256 of a bundled reference object (load-path independent,
# collision-safe over the supported domain).
.reference_object_digest <- function(x) {
  digest::digest(.canon_encode(x), algo = "sha256")
}
