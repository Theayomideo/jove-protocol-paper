# Internal utilities.

`%||%` <- function(a, b) if (is.null(a)) b else a

# Sparse-safe validation that a matrix holds finite, non-negative values (the
# normalized scale scoring requires). Only the stored nonzeros of a sparse
# matrix need checking (implicit zeros are non-negative and finite).
.validate_nonneg_finite <- function(m, what = "expression") {
  vals <- if (methods::is(m, "sparseMatrix")) m@x else as.numeric(m)
  if (any(!is.finite(vals))) {
    stop("matrispace: ", what, " contains non-finite values (NA/NaN/Inf)",
         call. = FALSE)
  }
  if (any(vals < 0)) {
    stop("matrispace: ", what, " must be finite and non-negative (a necessary ",
         "check; a normalized scale is the caller's responsibility)", call. = FALSE)
  }
  invisible(TRUE)
}

# Recursively canonicalize a definition: sort+unique character leaves, and order
# named list entries by name (preserving the names, e.g. positive/negative). So
# reordering keys, niches, or genes does not change the result.
.canon_def <- function(x) {
  if (is.list(x)) {
    x <- lapply(x, .canon_def)
    if (!is.null(names(x))) x <- x[order(names(x))]
    x
  } else if (is.character(x)) {
    sort(unique(x))
  } else {
    x
  }
}

# Deterministic, fully order-invariant digest of a (possibly nested) gene-set
# definition (signatures, marker lists): identical definitions hash equal;
# different gene sets differ.
.definition_digest <- function(def) {
  digest::digest(.canon_def(def), algo = "xxhash64")
}

# Sparse-safe validation that a matrix holds only finite values (NA/NaN/Inf are
# rejected). Negatives are allowed (callers may truncate them).
.validate_finite <- function(m, what = "expression") {
  vals <- if (methods::is(m, "sparseMatrix")) m@x else as.numeric(m)
  if (any(!is.finite(vals))) {
    stop("matrispace: ", what, " contains non-finite values (NA/NaN/Inf)",
         call. = FALSE)
  }
  invisible(TRUE)
}

# Coerce a grouping vector to a factor with a natural, stable level order:
#  * an existing factor keeps its own levels (drops nothing, preserves order);
#  * an all-numeric character/text column orders numerically (0, 1, 2, ... 13),
#    not lexically ("0", "1", "10", "11", ...);
#  * everything else keeps first-appearance-of-sorted order.
# Blank/NA entries are excluded from the levels. Used by grouped plots and
# neighborhood enrichment so cluster order survives round-trips (FIX_GUIDE s2).
.group_factor <- function(x) {
  if (is.factor(x)) {
    # Drop a blank declared level and map blank values to NA, but keep the rest
    # of the meaningful order (and ordered status) intact.
    keep <- levels(x)[nzchar(levels(x))]
    xc <- as.character(x)
    xc[!is.na(xc) & !nzchar(xc)] <- NA_character_
    return(factor(xc, levels = keep, ordered = is.ordered(x)))
  }
  x_chr <- as.character(x)
  present <- unique(x_chr[!is.na(x_chr) & nzchar(x_chr)])
  if (length(present) && all(grepl("^-?[0-9]+(?:\\.[0-9]+)?$", present))) {
    present <- present[order(as.numeric(present))]
  } else {
    present <- sort(present)
  }
  factor(x_chr, levels = present)
}

# A single, non-logical NUMERIC whole-number scalar within R's integer range (so
# as.integer() cannot overflow to NA), optionally bounded below by `min`. The
# is.numeric() gate rejects logical/list/character/factor first, so malformed
# inputs yield a package diagnostic instead of a leaked base error or a silent
# NA-with-warning coercion.
.is_whole_scalar <- function(x, min = -Inf) {
  is.numeric(x) && length(x) == 1L && !is.na(x) && is.finite(x) &&
    x == round(x) && abs(x) <= .Machine$integer.max && x >= min
}

# A single positive whole number within R's integer range.
.is_pos_whole <- function(x) .is_whole_scalar(x, min = 1)

# Resolve a definition-vs-selector argument pair to a concrete named list
# (FIX_GUIDE s5). `custom` is a user-supplied definition list; `keys` selects a
# subset of `bundled` by name. Exactly one may be supplied; neither means "use
# all bundled". Selection preserves the requested key order and reports unknown,
# duplicate, or empty selections with the available choices. Resolution happens
# in the public wrapper, BEFORE fingerprinting, so provenance records exactly
# what was scored.
.select_bundled <- function(custom, keys, bundled, custom_arg, key_arg, what) {
  if (!is.null(custom) && !is.null(keys)) {
    stop("matrispace: supply exactly one of `", custom_arg, "` or `", key_arg,
         "`, not both", call. = FALSE)
  }
  if (is.null(custom) && is.null(keys)) return(bundled)   # default: all bundled
  if (is.null(custom)) {                                  # selector path
    if (!is.character(keys) || length(keys) == 0L) {
      stop("matrispace: `", key_arg, "` must be a non-empty character vector",
           call. = FALSE)
    }
    if (anyDuplicated(keys)) {
      dup <- unique(keys[duplicated(keys)])
      stop("matrispace: `", key_arg, "` has duplicate ", what, "(s): ",
           paste(dup, collapse = ", "), call. = FALSE)
    }
    unknown <- setdiff(keys, names(bundled))
    if (length(unknown)) {
      stop("matrispace: unknown ", what, "(s) in `", key_arg, "`: ",
           paste(unknown, collapse = ", "), " (available: ",
           paste(names(bundled), collapse = ", "), ")", call. = FALSE)
    }
    return(bundled[keys])                                 # preserve requested order
  }
  custom                                                  # custom definitions as-is
}

# Evaluate `expr` with a fixed RNG seed, restoring the caller's RNG state after.
# Keeps permutation inference reproducible without clobbering the user's stream.
.with_seed <- function(seed, expr) {
  if (exists(".Random.seed", envir = globalenv(), inherits = FALSE)) {
    old <- get(".Random.seed", envir = globalenv(), inherits = FALSE)
    on.exit(assign(".Random.seed", old, envir = globalenv()), add = TRUE)
  } else {
    on.exit(suppressWarnings(rm(".Random.seed", envir = globalenv())), add = TRUE)
  }
  set.seed(seed)
  force(expr)
}
