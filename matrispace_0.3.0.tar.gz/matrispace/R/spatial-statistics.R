# Global spatial autocorrelation (SPEC s6). Self-implemented kernels, sparse-
# aware, deterministic under a seed, cross-checked against hand values and spdep.
# All standardization and permutation happen WITHIN each image (SPEC s6.1).

# ---- Kernels (internal) -----------------------------------------------------

# Normalize to a GENERAL CsparseMatrix so both triangles are stored explicitly
# (a symmetric dsCMatrix stores only one triangle, which would halve S0).
.as_general_csparse <- function(W) {
  W <- methods::as(W, "CsparseMatrix")
  if (methods::is(W, "symmetricMatrix")) W <- methods::as(W, "generalMatrix")
  W
}

#' @keywords internal
.morans_i <- function(x, W, row_standardized = FALSE) {
  W <- .as_general_csparse(W)
  if (row_standardized) {
    rs <- Matrix::rowSums(W); rs[rs == 0] <- 1
    W <- methods::as(Matrix::Diagonal(x = 1 / rs) %*% W, "CsparseMatrix")
  }
  n <- length(x)
  z <- x - mean(x)
  S0 <- sum(W@x)
  den <- sum(z^2)
  if (S0 == 0 || den == 0) return(NA_real_)
  num <- as.numeric(Matrix::crossprod(z, W %*% z))
  (n / S0) * (num / den)
}

#' @keywords internal
.gearys_c <- function(x, W) {
  W <- .as_general_csparse(W)
  n <- length(x)
  z <- x - mean(x)
  S0 <- sum(W@x)
  den <- sum(z^2)
  if (S0 == 0 || den == 0) return(NA_real_)
  ij <- Matrix::which(W != 0, arr.ind = TRUE)
  wv <- W[ij]
  num <- sum(wv * (x[ij[, 1]] - x[ij[, 2]])^2)
  ((n - 1) / (2 * S0)) * (num / den)
}

# One-/two-sided permutation p-value, (r + 1) / (n_perm + 1) convention.
.perm_pvalue <- function(observed, null_stats, alternative) {
  m <- length(null_stats)
  greater <- (sum(null_stats >= observed) + 1) / (m + 1)
  less    <- (sum(null_stats <= observed) + 1) / (m + 1)
  switch(alternative,
    greater   = greater,
    less      = less,
    two.sided = min(1, 2 * min(greater, less)),
    stop("matrispace: unknown alternative '", alternative, "'", call. = FALSE))
}

# ---- Shared per-image driver ------------------------------------------------

.autocorr_valid_weights <- c("binary", "row_standardize", "inverse_distance",
                             "gaussian")

# ---- Shared argument/graph preparation (reused by autocorr, LISA, nhood) -----

.check_n_perm_seed <- function(n_perm, seed) {
  if (length(n_perm) != 1L || !is.finite(n_perm) || n_perm < 1 ||
      n_perm != round(n_perm)) {
    stop("matrispace: `n_perm` must be a positive whole number", call. = FALSE)
  }
  if (length(seed) != 1L || !is.finite(seed) || seed != round(seed) ||
      abs(seed) > .Machine$integer.max) {
    stop("matrispace: `seed` must be a whole number within the integer range",
         call. = FALSE)
  }
  list(n_perm = as.integer(n_perm), seed = as.integer(seed))
}

.check_weight_args <- function(weight, sigma, eps) {
  if (!(length(weight) == 1L && weight %in% .autocorr_valid_weights)) {
    stop("matrispace: `weight` must be one of ",
         paste(.autocorr_valid_weights, collapse = ", "), call. = FALSE)
  }
  # Reject weight parameters that do not apply, so they cannot be silently
  # recorded as provenance (SPEC s6.3: NA unless used).
  if (!is.null(sigma) && weight != "gaussian") {
    stop("matrispace: `sigma` only applies to weight = 'gaussian'", call. = FALSE)
  }
  if (!is.null(eps) && weight != "inverse_distance") {
    stop("matrispace: `eps` only applies to weight = 'inverse_distance'", call. = FALSE)
  }
  if (weight == "gaussian" && !.is_finite_pos_scalar(sigma)) {
    stop("matrispace: weight = 'gaussian' requires a single positive `sigma`",
         call. = FALSE)
  }
  if (weight == "inverse_distance" && !is.null(eps) && !.is_finite_pos_scalar(eps)) {
    stop("matrispace: `eps` must be a single positive number", call. = FALSE)
  }
  invisible(TRUE)
}

# Resolve a stored graph and validate it (structurally + against the host).
.resolve_graph <- function(object, graph) {
  if (!.is_nonempty_scalar_chr(graph)) {
    stop("matrispace: `graph` must be a single graph name", call. = FALSE)
  }
  g <- get_matrispace_graph(object, graph)
  .validate_graph_against(g, object)
  g
}

# As above, but require the graph undirected (spatial statistics only; L-R may
# use directed graphs).
.resolve_undirected_graph <- function(object, graph) {
  g <- .resolve_graph(object, graph)
  if (isTRUE(g$directed)) {
    stop("matrispace: spatial statistics require an undirected graph; '", graph,
         "' is directed.", call. = FALSE)
  }
  g
}

.autocorr_table <- function(object, features, graph, statistic, stat_col,
                            weight, alternative, n_perm, seed, na_action,
                            sigma, eps, assay, layer) {
  # ---- Argument validation (before any data access) ----
  alternative <- match.arg(alternative, c("greater", "less", "two.sided"))
  if (!is.character(features) || length(features) == 0L || anyNA(features) ||
      any(!nzchar(features)) || anyDuplicated(features)) {
    stop("matrispace: `features` must be a non-empty vector of unique, non-empty ",
         "feature names", call. = FALSE)
  }
  .check_weight_args(weight, sigma, eps)
  ps <- .check_n_perm_seed(n_perm, seed); n_perm <- ps$n_perm; seed <- ps$seed
  if (!identical(na_action, "omit")) {
    stop("matrispace: `na_action` must be 'omit' in 0.2.0", call. = FALSE)
  }
  g <- .resolve_undirected_graph(object, graph)
  kernel <- switch(statistic, morans = .morans_i, gearys = .gearys_c)
  # A too-small image has no well-defined statistical portion.
  expected <- switch(statistic,
    morans = function(n) if (n < 2) NA_real_ else -1 / (n - 1),
    gearys = function(n) if (n < 2) NA_real_ else 1)
  needs_dist <- weight %in% c("inverse_distance", "gaussian")

  expr <- .get_expression(object, assay = assay, layer = layer)
  missing_feat <- setdiff(features, rownames(expr))
  if (length(missing_feat)) {
    stop("matrispace: feature(s) not found: ",
         paste(missing_feat, collapse = ", "), call. = FALSE)
  }
  sid <- g$spot_ids
  images <- unique(g$image_ids)

  rows <- list()
  for (feat in features) {
    xall <- as.numeric(expr[feat, sid])
    for (im in images) {
      idx <- which(g$image_ids == im)
      x <- xall[idx]
      Wb <- g$connectivities[idx, idx, drop = FALSE]
      Db <- if (needs_dist) g$distances[idx, idx, drop = FALSE] else NULL
      # Drop non-finite values (NA / NaN / Inf) within the image, then take the
      # induced subgraph so re-standardized weights remain valid.
      keep <- which(is.finite(x))
      x <- x[keep]; Wb <- Wb[keep, keep, drop = FALSE]
      if (!is.null(Db)) Db <- Db[keep, keep, drop = FALSE]
      n_used <- length(x)
      stat <- NA_real_; pval <- NA_real_
      if (n_used >= 3 && stats::sd(x) > 0) {
        Wt <- transform_weights(Wb, distances = Db, method = weight,
                                sigma = sigma, eps = eps)
        if (sum(Wt@x) > 0) {
          stat <- kernel(x, Wt)
          null <- .with_seed(seed, vapply(seq_len(n_perm),
                    function(i) kernel(sample(x), Wt), numeric(1)))
          pval <- .perm_pvalue(stat, null, alternative)
        }
      }
      row <- data.frame(feature = feat, image_id = im,
                        stat = stat, expected = expected(n_used),
                        p_value = pval, p_adjusted = NA_real_,
                        graph = graph, weight = weight,
                        sigma = sigma %||% NA_real_, eps = eps %||% NA_real_,
                        alternative = alternative, n_perm = n_perm,
                        seed = seed, na_action = na_action,
                        assay = assay %||% NA_character_,
                        layer = layer %||% NA_character_,
                        n_spots_used = n_used,
                        stringsAsFactors = FALSE)
      names(row)[names(row) == "stat"] <- stat_col
      rows[[length(rows) + 1L]] <- row
    }
  }
  res <- do.call(rbind, rows)
  # BH FDR within each image family (SPEC s6.1: per-image).
  for (im in images) {
    sel <- res$image_id == im & !is.na(res$p_value)
    if (any(sel)) res$p_adjusted[sel] <- stats::p.adjust(res$p_value[sel], "BH")
  }
  rownames(res) <- NULL
  res
}

# ---- Public API -------------------------------------------------------------

#' Global Moran's I spatial autocorrelation, per image.
#' @param object A Seurat or SpatialExperiment object with a stored graph.
#' @param features Character vector of feature names.
#' @param graph Name of a stored undirected graph.
#' @param weight Weight transform (default "row_standardize").
#' @param alternative "greater", "less", or "two.sided".
#' @param n_perm Number of permutations.
#' @param seed RNG seed for reproducible permutation inference.
#' @param na_action "omit" to drop missing spots within each image.
#' @param sigma Gaussian kernel bandwidth (required when weight = "gaussian").
#' @param eps Optional inverse-distance regularizer.
#' @param assay,layer Expression source (container defaults if NULL).
#' @return A data.frame with one row per feature x image and full provenance.
#' @export
compute_morans_i <- function(object, features, graph, weight = "row_standardize",
                             alternative = "greater", n_perm = 99, seed = 1,
                             na_action = "omit", sigma = NULL, eps = NULL,
                             assay = NULL, layer = NULL) {
  .autocorr_table(object, features, graph, statistic = "morans",
                  stat_col = "morans_i", weight = weight,
                  alternative = alternative, n_perm = n_perm, seed = seed,
                  na_action = na_action, sigma = sigma, eps = eps,
                  assay = assay, layer = layer)
}

#' Global Geary's C spatial autocorrelation, per image.
#' @inheritParams compute_morans_i
#' @return A data.frame with one row per feature x image and full provenance.
#' @export
compute_gearys_c <- function(object, features, graph, weight = "row_standardize",
                             alternative = "less", n_perm = 99, seed = 1,
                             na_action = "omit", sigma = NULL, eps = NULL,
                             assay = NULL, layer = NULL) {
  .autocorr_table(object, features, graph, statistic = "gearys",
                  stat_col = "gearys_c", weight = weight,
                  alternative = alternative, n_perm = n_perm, seed = seed,
                  na_action = na_action, sigma = sigma, eps = eps,
                  assay = assay, layer = layer)
}

# ---- LISA: local indicators of spatial association (SPEC s6.4) ---------------

# Local Moran (univariate) or bivariate LISA within one image, with conditional
# permutation WITHOUT replacement (hold focal fixed, sample neighbor values from
# the remaining within-image values). Returns one row per spot.
.lisa_image <- function(spot_ids, image_id, x1, x2, Wb, Db, weight, sigma, eps,
                        alternative, n_perm) {
  n <- length(x1)
  lisa <- rep(NA_real_, n); quad <- rep(NA_character_, n); pval <- rep(NA_real_, n)
  finite <- is.finite(x1) & is.finite(x2)
  keep <- which(finite)
  nk <- length(keep)

  if (nk >= 2) {
    # Induced subgraph on the FINITE spots: drop missing nodes first, then
    # transform that graph and compute degrees there (row-standardized mass is
    # never allocated to a missing neighbor, and a spot whose only neighbors are
    # missing becomes correctly isolated).
    Wb_i <- Wb[keep, keep, drop = FALSE]
    Db_i <- if (!is.null(Db)) Db[keep, keep, drop = FALSE] else NULL
    Wt_i <- .as_general_csparse(transform_weights(Wb_i, distances = Db_i,
                                                 method = weight, sigma = sigma,
                                                 eps = eps))
    deg_i <- as.numeric(Matrix::rowSums(Wb_i != 0))
    x1k <- x1[keep]; x2k <- x2[keep]
    z1 <- x1k - mean(x1k); z2 <- x2k - mean(x2k)
    m2 <- sum(z1^2) / nk
    lagvar <- z2                                          # z1 == z2 in univariate
    lag <- as.numeric(Wt_i %*% lagvar)
    valid <- deg_i > 0 & is.finite(m2) & m2 > 0

    li <- rep(NA_real_, nk); qi <- rep(NA_character_, nk); pv <- rep(NA_real_, nk)
    li[valid] <- (z1[valid] / m2) * lag[valid]
    qi[valid & z1 >= 0 & lag >= 0] <- "HH"
    qi[valid & z1 <  0 & lag <  0] <- "LL"
    qi[valid & z1 >= 0 & lag <  0] <- "HL"
    qi[valid & z1 <  0 & lag >= 0] <- "LH"

    for (i in which(valid)) {
      wi <- Wt_i[i, ]; nz <- which(wi != 0); wv <- wi[nz]
      pool <- lagvar[-i]                                  # remaining induced values
      if (length(pool) < length(wv)) next
      # Sample INDICES, not values: sample(pool, k) treats a length-one numeric
      # pool as 1:pool, which would corrupt the permutation.
      null_I <- vapply(seq_len(n_perm), function(p) {
        (z1[i] / m2) * sum(wv * pool[sample.int(length(pool), length(wv))])
      }, numeric(1))
      pv[i] <- .perm_pvalue(li[i], null_I, alternative)
    }
    lisa[keep] <- li; quad[keep] <- qi; pval[keep] <- pv
  }
  data.frame(spot_id = spot_ids, image_id = image_id, lisa = lisa,
             quadrant = quad, p_value = pval, p_adjusted = NA_real_,
             n_spots_used = nk, stringsAsFactors = FALSE)
}

#' Local indicators of spatial association (local Moran / bivariate LISA).
#'
#' @param object A Seurat or SpatialExperiment object with a stored graph.
#' @param feature1 Focal feature name.
#' @param feature2 Optional second feature for bivariate LISA.
#' @param graph Name of a stored undirected graph.
#' @param weight Weight transform (default "row_standardize").
#' @param alternative Permutation alternative (default "two.sided").
#' @param n_perm,seed Permutation count and seed.
#' @param na_action "omit".
#' @param sigma,eps Weight-transform parameters (as in compute_morans_i).
#' @param assay,layer Expression source.
#' @return A data.frame with one row per spot: spot_id, image_id, lisa,
#'   quadrant, p_value, p_adjusted, plus provenance.
#' @export
compute_lisa <- function(object, feature1, feature2 = NULL, graph,
                         weight = "row_standardize", alternative = "two.sided",
                         n_perm = 99, seed = 1, na_action = "omit",
                         sigma = NULL, eps = NULL, assay = NULL, layer = NULL) {
  if (!.is_nonempty_scalar_chr(feature1)) {
    stop("matrispace: `feature1` must be a single non-empty feature name",
         call. = FALSE)
  }
  if (!is.null(feature2) && !.is_nonempty_scalar_chr(feature2)) {
    stop("matrispace: `feature2` must be NULL or a single feature name", call. = FALSE)
  }
  alternative <- match.arg(alternative, c("two.sided", "greater", "less"))
  .check_weight_args(weight, sigma, eps)
  ps <- .check_n_perm_seed(n_perm, seed); n_perm <- ps$n_perm; seed <- ps$seed
  if (!identical(na_action, "omit")) {
    stop("matrispace: `na_action` must be 'omit' in 0.2.0", call. = FALSE)
  }
  g <- .resolve_undirected_graph(object, graph)
  expr <- .get_expression(object, assay = assay, layer = layer)
  feats <- c(feature1, feature2)
  missing_feat <- setdiff(feats, rownames(expr))
  if (length(missing_feat)) {
    stop("matrispace: feature(s) not found: ",
         paste(missing_feat, collapse = ", "), call. = FALSE)
  }
  sid <- g$spot_ids
  x1all <- as.numeric(expr[feature1, sid])
  x2all <- if (is.null(feature2)) x1all else as.numeric(expr[feature2, sid])
  needs_dist <- weight %in% c("inverse_distance", "gaussian")

  parts <- .with_seed(seed, lapply(unique(g$image_ids), function(im) {
    idx <- which(g$image_ids == im)
    Db <- if (needs_dist) g$distances[idx, idx, drop = FALSE] else NULL
    .lisa_image(spot_ids = sid[idx], image_id = im, x1 = x1all[idx],
                x2 = x2all[idx], Wb = g$connectivities[idx, idx, drop = FALSE],
                Db = Db, weight = weight, sigma = sigma, eps = eps,
                alternative = alternative, n_perm = n_perm)
  }))
  res <- do.call(rbind, parts)
  for (im in unique(res$image_id)) {
    sel <- res$image_id == im & !is.na(res$p_value)
    if (any(sel)) res$p_adjusted[sel] <- stats::p.adjust(res$p_value[sel], "BH")
  }
  res$graph <- graph
  res$feature1 <- feature1
  res$feature2 <- feature2 %||% NA_character_
  res$weight <- weight
  res$sigma <- sigma %||% NA_real_
  res$eps <- eps %||% NA_real_
  res$alternative <- alternative
  res$n_perm <- n_perm
  res$seed <- seed
  res$na_action <- na_action
  res$assay <- assay %||% NA_character_
  res$layer <- layer %||% NA_character_
  rownames(res) <- NULL
  res
}

# ---- Neighborhood enrichment (SPEC s6.5) ------------------------------------

# Symmetric categories x categories count of undirected edges between category
# pairs. Each undirected edge is counted once (upper triangle); diagonal counts
# within-category edges once (not doubled). Edges touching an NA category are
# ignored.
.nhood_count <- function(cat_int, W, K) {
  cnt <- matrix(0, K, K)
  ij <- Matrix::which(Matrix::triu(W, k = 1) != 0, arr.ind = TRUE)
  if (nrow(ij)) {
    a <- cat_int[ij[, 1]]; b <- cat_int[ij[, 2]]
    ok <- !is.na(a) & !is.na(b)
    a <- a[ok]; b <- b[ok]
    if (length(a)) {
      m <- as.matrix(table(factor(a, levels = seq_len(K)),
                           factor(b, levels = seq_len(K))))
      cnt <- m + t(m)
      diag(cnt) <- diag(m)
    }
  }
  cnt
}

#' Neighborhood enrichment by within-image label permutation.
#'
#' @param object A Seurat or SpatialExperiment object with a stored graph.
#' @param group_by Spot-metadata column naming the categories.
#' @param graph Name of a stored undirected graph.
#' @param n_perm,seed Permutation count and seed.
#' @return A list with `zscore`, `count`, `p_value` (all K x K, symmetric),
#'   `categories`, `graph`, `n_perm`, `seed`.
#' @export
compute_nhood_enrichment <- function(object, group_by, graph, n_perm = 99, seed = 1) {
  if (!.is_nonempty_scalar_chr(group_by)) {
    stop("matrispace: `group_by` must be a single metadata column name", call. = FALSE)
  }
  ps <- .check_n_perm_seed(n_perm, seed); n_perm <- ps$n_perm; seed <- ps$seed
  g <- .resolve_undirected_graph(object, graph)
  md <- .get_spot_metadata(object)
  if (!(group_by %in% colnames(md))) {
    stop("matrispace: group_by column '", group_by, "' not found", call. = FALSE)
  }
  sid <- g$spot_ids
  # Preserve the grouping column's natural level order (factor levels, or
  # numeric-aware ordering) in `categories` and all matrix dimnames, instead of
  # lexically sorting the character labels (FIX_GUIDE s2).
  labels_f <- .group_factor(md[sid, group_by])
  categories <- levels(droplevels(labels_f))
  K <- length(categories)
  if (K < 1L) stop("matrispace: no categories in '", group_by, "'", call. = FALSE)
  cat_int <- match(as.character(labels_f), categories) # NA for NA labels
  images <- g$image_ids
  W <- .as_general_csparse(g$connectivities)

  observed <- .nhood_count(cat_int, W, K)
  perms <- .with_seed(seed, {
    out <- array(0, dim = c(n_perm, K, K))
    for (p in seq_len(n_perm)) {
      permuted <- cat_int
      for (im in unique(images)) {
        ii <- which(images == im & !is.na(cat_int))
        if (length(ii) > 1L) permuted[ii] <- cat_int[ii][sample(length(ii))]
      }
      out[p, , ] <- .nhood_count(permuted, W, K)
    }
    out
  })
  mean_p <- apply(perms, c(2, 3), mean)
  sd_p <- apply(perms, c(2, 3), stats::sd)
  zscore <- (observed - mean_p) / sd_p
  zscore[sd_p == 0] <- NA_real_                          # zero-variance -> NA
  pval <- matrix(NA_real_, K, K)
  for (a in seq_len(K)) for (b in seq_len(K)) {
    nb <- perms[, a, b]
    gr <- (sum(nb >= observed[a, b]) + 1) / (n_perm + 1)
    ls <- (sum(nb <= observed[a, b]) + 1) / (n_perm + 1)
    pval[a, b] <- min(1, 2 * min(gr, ls))
  }
  dn <- list(categories, categories)
  dimnames(observed) <- dn; dimnames(zscore) <- dn; dimnames(pval) <- dn
  list(zscore = zscore, count = observed, p_value = pval,
       categories = categories, group_by = group_by, graph = graph,
       n_perm = n_perm, seed = seed)
}
