# Optional histology-image adapters (SPEC s11, FIX_GUIDE s1). These are the ONLY
# place (with the compat-*.R accessors) that touches container image internals.
# Every function returns NULL whenever a raster / scale factor is unavailable, so
# plotting cleanly falls back to coordinate-only rendering. The scale factor maps
# the stored full-resolution coordinates into the (low/hi-res) raster's pixel
# space; coordinates and raster therefore always share one scale factor.

# A usable pixel scale factor is exactly one finite, strictly positive NUMBER
# (zero collapses all spots; a negative value would reflect coordinates). The
# is.numeric() gate first rejects non-numeric metadata (logical/list/factor/
# character) so a malformed value yields the clean image-unavailable path rather
# than a coercion error or warning.
.valid_scale_factor <- function(x) {
  is.numeric(x) && length(x) == 1L && is.finite(x) && x > 0
}

# ---- Seurat (VisiumV1 / VisiumV2 / FOV) -------------------------------------

.get_spatial_scale_factor_seurat <- function(object, image_id, image_scale) {
  img <- tryCatch(object[[image_id]], error = function(e) NULL)
  if (is.null(img)) return(NULL)
  # ScaleFactors() is exported by Seurat (not SeuratObject); guarded so a missing
  # Seurat, or an image class without scale factors, falls back to NULL.
  if (!requireNamespace("Seurat", quietly = TRUE)) return(NULL)
  sf <- tryCatch(Seurat::ScaleFactors(img), error = function(e) NULL)
  if (is.null(sf)) return(NULL)
  val <- tryCatch(sf[[image_scale]], error = function(e) NULL)
  if (!.valid_scale_factor(val)) return(NULL)
  as.numeric(val)
}

.get_spatial_image_seurat <- function(object, image_id, image_scale) {
  img <- tryCatch(object[[image_id]], error = function(e) NULL)
  if (is.null(img)) return(NULL)
  r <- tryCatch(SeuratObject::GetImage(img, mode = "raster", scale = image_scale),
                error = function(e) NULL)
  if (is.null(r)) return(NULL)
  tryCatch(grDevices::as.raster(r), error = function(e) NULL)
}

# ---- SpatialExperiment (imgData) --------------------------------------------

# Row index of the requested (sample_id = image_id, image_id = image_scale)
# image in imgData(), or NULL when absent.
.spe_img_row <- function(object, image_id, image_scale) {
  id <- tryCatch(SpatialExperiment::imgData(object), error = function(e) NULL)
  if (is.null(id) || !nrow(id)) return(NULL)
  ok <- which(as.character(id$sample_id) == image_id &
              as.character(id$image_id) == image_scale)
  if (!length(ok)) return(NULL)
  ok[1]
}

.get_spatial_scale_factor_spe <- function(object, image_id, image_scale) {
  if (is.null(.spe_img_row(object, image_id, image_scale))) return(NULL)
  sf <- tryCatch(SpatialExperiment::scaleFactors(
    object, sample_id = image_id, image_id = image_scale),
    error = function(e) NULL)
  if (!.valid_scale_factor(sf)) return(NULL)
  as.numeric(sf)
}

.get_spatial_image_spe <- function(object, image_id, image_scale) {
  if (is.null(.spe_img_row(object, image_id, image_scale))) return(NULL)
  im <- tryCatch(SpatialExperiment::getImg(
    object, sample_id = image_id, image_id = image_scale),
    error = function(e) NULL)
  if (is.null(im)) return(NULL)
  r <- tryCatch(SpatialExperiment::imgRaster(im), error = function(e) NULL)
  if (is.null(r)) return(NULL)
  tryCatch(grDevices::as.raster(r), error = function(e) NULL)
}
