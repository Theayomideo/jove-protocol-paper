# SpatialExperiment implementation of the accessor contract (SPEC s4). SPE's
# reserved colData$sample_id IS the spatial library/image (`image_id`);
# biological identity lives in a separate column (`replicate_id`).

.get_expression_spe <- function(object, assay = NULL, layer = NULL) {
  assay <- assay %||% SummarizedExperiment::assayNames(object)[1]
  SummarizedExperiment::assay(object, assay)
}

# SPE assays are single matrices, so `layer` has no per-assay meaning; only the
# assay name is validated. Errors name the available assays.
.resolve_expression_source_spe <- function(object, assay = NULL, layer = NULL) {
  assays <- SummarizedExperiment::assayNames(object)
  assay <- assay %||% assays[1]
  if (!(assay %in% assays)) {
    stop("matrispace: assay '", assay, "' not found (available: ",
         paste(assays, collapse = ", "), ").", call. = FALSE)
  }
  list(assay = assay, layer = layer)
}

.get_counts_spe <- function(object, assay = NULL) {
  assay <- assay %||% "counts"
  SummarizedExperiment::assay(object, assay)
}

.get_coordinates_spe <- function(object, image_id = NULL) {
  xy <- as.matrix(SpatialExperiment::spatialCoords(object))
  if (ncol(xy) < 2) {
    stop("matrispace: SpatialExperiment has ", ncol(xy), " spatial coordinate ",
         "column(s); 0.2.0 requires 2-D coordinates (at least two numeric ",
         "columns).", call. = FALSE)
  }
  xy <- xy[, 1:2, drop = FALSE]
  storage.mode(xy) <- "double"
  if (any(!is.finite(xy))) {
    stop("matrispace: spatial coordinates contain non-finite values", call. = FALSE)
  }
  rownames(xy) <- colnames(object)
  colnames(xy) <- c("x", "y")
  if (!is.null(image_id)) {
    imgs <- unique(as.character(object$sample_id))
    if (!(image_id %in% imgs)) {
      stop("matrispace: unknown image_id '", image_id, "'; available: ",
           paste(imgs, collapse = ", "), call. = FALSE)
    }
    keep <- colnames(object)[as.character(object$sample_id) == image_id]
    xy <- xy[keep, , drop = FALSE]
  }
  xy
}

.spatial_y_is_down_spe <- function(object, image_id = NULL) {
  # Registered rasters use image coordinates (origin at the upper left).
  ids <- tryCatch(SpatialExperiment::imgData(object), error = function(e) NULL)
  if (!is.null(ids) && nrow(ids) &&
      (is.null(image_id) || image_id %in% as.character(ids$sample_id))) {
    return(TRUE)
  }
  # Preserve an explicit Visium/pixel convention when informative coordinate
  # names survive import; otherwise plain x/y coordinates are Cartesian.
  nm <- colnames(SpatialExperiment::spatialCoords(object))[1:2]
  if (length(nm) == 2L && any(grepl("pixel|pxl|image|row|col", nm,
                                    ignore.case = TRUE))) return(TRUE)
  FALSE
}

.get_image_membership_spe <- function(object) {
  sid <- object$sample_id
  if (is.null(sid)) {
    stop("matrispace: SpatialExperiment has no sample_id (library/image key).",
         call. = FALSE)
  }
  sid <- as.character(sid)
  if (length(sid) != ncol(object)) {
    stop("matrispace: sample_id length (", length(sid), ") does not match the ",
         "number of spots (", ncol(object), ").", call. = FALSE)
  }
  if (anyNA(sid) || any(!nzchar(sid))) {
    stop("matrispace: sample_id (image/library) contains NA or empty values.",
         call. = FALSE)
  }
  cells <- colnames(object)
  if (is.null(cells) || anyNA(cells) || anyDuplicated(cells)) {
    stop("matrispace: spot names are missing, NA, or duplicated.", call. = FALSE)
  }
  names(sid) <- cells
  sid
}

.get_spot_metadata_spe <- function(object) {
  as.data.frame(SummarizedExperiment::colData(object))
}

.set_spot_metadata_spe <- function(object, name, value) {
  value <- .align_to_spots(value, colnames(object))
  SummarizedExperiment::colData(object)[[name]] <- unname(value)
  object
}

.get_registry_raw_spe <- function(object) {
  S4Vectors::metadata(object)$matrispace
}

.set_registry_raw_spe <- function(object, registry) {
  S4Vectors::metadata(object)$matrispace <- registry
  object
}

.store_feature_result_spe <- function(object, akey, matrix) {
  se <- SummarizedExperiment::SummarizedExperiment(assays = list(data = matrix))
  SingleCellExperiment::altExp(object, akey) <- se
  object
}

.read_feature_result_spe <- function(object, storage, layer) {
  SummarizedExperiment::assay(SingleCellExperiment::altExp(object, storage), layer)
}

.remove_feature_result_spe <- function(object, akey) {
  if (akey %in% SingleCellExperiment::altExpNames(object)) {
    SingleCellExperiment::altExp(object, akey) <- NULL
  }
  object
}
