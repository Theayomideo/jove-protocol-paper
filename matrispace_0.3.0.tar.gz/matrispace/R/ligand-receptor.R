# ECM ligand-receptor activity (SPEC s9). Spatially-weighted co-expression over a
# NAMED graph: activity[pair, i] = sqrt(max(receptor_i, 0)) * sum_j W[i,j] *
# sqrt(max(ligand_j, 0)), where W[i,j] means sender j contributes ligand to
# receiver i (row i is the receiver's neighborhood).
#
# Sparsity contract: only SCORABLE pairs (both genes present) are stored, as a
# sparse pairs x spots matrix. Missing pairs are recorded structurally in the
# manifest (never materialized as explicit-NA rows), so a database with many
# absent genes cannot blow up the stored result. `get_lr_activity()` returns the
# sparse scorable matrix; `find_lr_enrichment()` reports every pair, NA for missing.

# Human-readable DISPLAY key (may not be unique if a gene name contains "__").
.lr_pair_display <- function(ligand, receptor) paste(ligand, receptor, sep = "__")

# Collision-resistant MACHINE id: a per-tuple hash. Distinct tuples get distinct
# ids even when their display keys would collide (e.g. ("a__b","c") vs ("a","b__c")).
.lr_pair_id <- function(ligand, receptor) {
  vapply(seq_along(ligand),
         function(i) digest::digest(list(ligand[i], receptor[i]), algo = "xxhash64"),
         character(1))
}

# Order-invariant, association-preserving digest of a pair set: hashing the
# sorted per-tuple ids keeps each ligand<->receptor pairing intact (so crossed
# pairs differ) while being invariant to pair order.
.lr_pairs_digest <- function(ligand, receptor) {
  digest::digest(sort(.lr_pair_id(ligand, receptor)), algo = "xxhash64")
}

# sqrt(max(x, 0)) on a sparse matrix without densifying (operate on stored values).
.sqrt_pos <- function(m) {
  m <- methods::as(m, "CsparseMatrix")
  m@x <- sqrt(pmax(m@x, 0))
  Matrix::drop0(m)                                    # drop truncated (now-zero) entries
}

#' Score spatially-weighted ligand-receptor activity on a named graph.
#'
#' @param object A Seurat or SpatialExperiment object with a stored graph.
#' @param pairs A data.frame with `ligand` and `receptor` columns.
#' @param graph Name of a stored graph (may be directed).
#' @param assay,layer Explicit expression source (negatives truncated; non-finite errors).
#' @param weight Weight transform (default "row_standardize"; "binary" for legacy).
#' @param chunk_size Pairs processed per chunk (NULL = all scorable at once).
#' @param sigma,eps Weight-transform parameters.
#' @param database Optional source-database identifier (scalar string or NA).
#' @param ... Unused.
#' @return The object with an `lr_activity` (scorable pairs x spots) artifact.
#' @export
score_lr_activity <- function(object, pairs = lr_database, graph, assay, layer = NULL,
                              weight = "row_standardize", chunk_size = NULL,
                              sigma = NULL, eps = NULL,
                              database = NULL,
                              ...) {
  bundled_pairs <- missing(pairs)
  if (is.null(database)) {
    database <- if (bundled_pairs) {
      "MatriComDB / MatriSpace authoritative snapshot"
    } else {
      NA_character_
    }
  }
  if (!is.data.frame(pairs) || !all(c("ligand", "receptor") %in% colnames(pairs))) {
    stop("matrispace: `pairs` must be a data.frame with `ligand` and `receptor`",
         call. = FALSE)
  }
  if (nrow(pairs) == 0L) stop("matrispace: `pairs` is empty", call. = FALSE)
  pairs <- data.frame(ligand = as.character(pairs$ligand),
                      receptor = as.character(pairs$receptor),
                      stringsAsFactors = FALSE)
  if (anyNA(pairs) || any(!nzchar(pairs$ligand)) || any(!nzchar(pairs$receptor))) {
    stop("matrispace: `pairs` contain NA or empty gene names", call. = FALSE)
  }
  .check_weight_args(weight, sigma, eps)
  if (missing(assay)) stop("matrispace: `assay` is required", call. = FALSE)
  if (!is.null(chunk_size) && !.is_pos_whole(chunk_size)) {
    stop("matrispace: `chunk_size` must be a positive whole number", call. = FALSE)
  }
  if (!(length(database) == 1L && (is.na(database) || .is_nonempty_scalar_chr(database)))) {
    stop("matrispace: `database` must be a scalar string or NA", call. = FALSE)
  }

  # Deduplicate on the (ligand, receptor) TUPLE (collision-free).
  keep <- !duplicated(pairs)
  pairs <- pairs[keep, , drop = FALSE]
  pair_ids <- .lr_pair_id(pairs$ligand, pairs$receptor)   # machine row keys
  n_pairs <- nrow(pairs)

  g <- .resolve_graph(object, graph)                 # directed allowed
  needs_dist <- weight %in% c("inverse_distance", "gaussian")
  Wt <- .as_general_csparse(transform_weights(g$connectivities,
          distances = if (needs_dist) g$distances else NULL,
          method = weight, sigma = sigma, eps = eps))
  tWt <- Matrix::t(Wt)

  expr <- .get_expression(object, assay = assay, layer = layer)
  # Non-finite values are rejected; negatives are truncated by the formula.
  .validate_finite(expr, "expression")
  spots <- g$spot_ids
  expr <- methods::as(expr[, spots, drop = FALSE], "CsparseMatrix")
  genes <- rownames(expr)

  scorable <- pairs$ligand %in% genes & pairs$receptor %in% genes
  sidx <- which(scorable)
  n_scorable <- length(sidx)
  # Effective chunk = 0 when nothing is scorable (no chunk runs).
  chunk_eff <- if (n_scorable == 0L) 0L
    else if (is.null(chunk_size)) n_scorable
    else min(as.integer(chunk_size), n_scorable)

  if (n_scorable) {
    parts <- lapply(split(sidx, ceiling(seq_along(sidx) / chunk_eff)), function(ci) {
      sqrtL <- .sqrt_pos(expr[pairs$ligand[ci], , drop = FALSE])
      sqrtR <- .sqrt_pos(expr[pairs$receptor[ci], , drop = FALSE])
      methods::as(sqrtR * (sqrtL %*% tWt), "CsparseMatrix")
    })
    scorable_act <- do.call(rbind, parts)
  } else {
    scorable_act <- Matrix::Matrix(0, 0, length(spots), sparse = TRUE)
  }
  rownames(scorable_act) <- pair_ids[sidx]
  colnames(scorable_act) <- spots

  # Store the physical (sparse) scorable matrix only when there IS something to
  # store; an all-missing database registers a manifest-only artifact (a 0-row
  # assay is not representable in Seurat).
  akey <- .key_feature_result("lr_activity")
  materialized <- n_scorable > 0L
  if (materialized) {
    m <- scorable_act[, colnames(object), drop = FALSE]
    .validate_feature_matrix(m, colnames(object))
    object <- .store_feature_result(object, akey, m)
  } else {
    # Clear any stale physical result from a previous (scorable) scoring run.
    object <- .remove_feature_result(object, akey)
  }
  man <- .new_manifest(storage = akey, layer = "data", type = "activity",
    producer = "score_lr_activity", input_assay = assay %||% NA_character_,
    input_layer = layer %||% NA_character_,
    parameters = list(
      ligand = pairs$ligand, receptor = pairs$receptor, scorable = scorable,
      materialized = materialized, graph = graph,
      graph_fingerprint = g$coordinate_fingerprint,
      weight = weight, sigma = sigma %||% NA_real_, eps = eps %||% NA_real_,
      directed = isTRUE(g$directed), n_pairs = n_pairs, n_missing = sum(!scorable),
      chunk_size = chunk_size %||% NA_integer_, chunk_size_effective = chunk_eff,
      database = database,
      pair_digest = .lr_pairs_digest(pairs$ligand, pairs$receptor)))
  .validate_manifest(man)
  reg <- .get_registry(object) %||% .new_registry()
  reg$artifacts[["lr_activity"]] <- man
  reg <- .registry_append_history(reg, "score_lr_activity",
                                  list(n_pairs = n_pairs, n_missing = sum(!scorable)))
  .set_registry(object, reg)
}

# A synthesized empty (0 x spots) sparse activity matrix.
.lr_empty_activity <- function(object) {
  Matrix::Matrix(0, 0, ncol(object), sparse = TRUE,
                 dimnames = list(character(0), colnames(object)))
}

#' Retrieve the stored ligand-receptor activity matrix (scorable pairs x spots).
#'
#' @param object A Seurat or SpatialExperiment object.
#' @return A sparse scorable-pairs x spots activity matrix. Missing pairs are not
#'   rows; identify them via `lr_missing_pairs()`.
#' @export
get_lr_activity <- function(object) {
  reg <- .get_registry(object)
  if (is.null(reg) || !("lr_activity" %in% names(reg$artifacts))) {
    stop("matrispace: object has no L-R activity; run score_lr_activity() first",
         call. = FALSE)
  }
  p <- reg$artifacts$lr_activity$parameters
  if (!isTRUE(p$materialized)) return(.lr_empty_activity(object))
  act <- .get_feature_result(object, "lr_activity")
  # Authoritative machine pair ids come from the manifest, not the stored feature
  # names (Seurat mangles some characters in assay feature names).
  rownames(act) <- .lr_pair_id(p$ligand, p$receptor)[p$scorable]
  act
}

#' Ligand-receptor pairs that could not be scored (a gene absent from the data).
#' @param object A Seurat or SpatialExperiment object with stored L-R activity.
#' @return A data.frame of missing `ligand`/`receptor` pairs (possibly empty).
#' @export
lr_missing_pairs <- function(object) {
  reg <- .get_registry(object)
  if (is.null(reg) || !("lr_activity" %in% names(reg$artifacts))) {
    stop("matrispace: object has no L-R activity; run score_lr_activity() first",
         call. = FALSE)
  }
  p <- reg$artifacts$lr_activity$parameters
  miss <- !p$scorable
  data.frame(ligand = p$ligand[miss], receptor = p$receptor[miss],
             stringsAsFactors = FALSE)
}

#' Ligand-receptor enrichment: a terminal table of mean activity per group.
#'
#' Sparse-aware (never densifies the activity matrix). Reports every pair; a
#' missing pair (or a group with no spots) yields `NA` mean activity.
#'
#' @param object A Seurat or SpatialExperiment object with stored L-R activity.
#' @param group_by Spot-metadata column naming the groups.
#' @param ... Unused.
#' @return A data.frame (one row per pair x group); the object is not mutated.
#' @export
find_lr_enrichment <- function(object, group_by, ...) {
  if (!.is_nonempty_scalar_chr(group_by)) {
    stop("matrispace: `group_by` must be a single metadata column name", call. = FALSE)
  }
  reg <- .get_registry(object)
  if (is.null(reg) || !("lr_activity" %in% names(reg$artifacts))) {
    stop("matrispace: object has no L-R activity; run score_lr_activity() first",
         call. = FALSE)
  }
  p <- reg$artifacts$lr_activity$parameters
  act <- if (!isTRUE(p$materialized)) .lr_empty_activity(object) else
    .get_feature_result(object, "lr_activity")        # sparse, scorable only
  md <- .get_spot_metadata(object)
  if (!(group_by %in% colnames(md))) {
    stop("matrispace: group_by column '", group_by, "' not found", call. = FALSE)
  }
  labels <- as.character(md[colnames(act), group_by])
  groups <- sort(unique(labels[!is.na(labels) & nzchar(labels)]))  # NA and "" absent
  pair_id <- .lr_pair_id(p$ligand, p$receptor)
  display <- .lr_pair_display(p$ligand, p$receptor)
  empty_tbl <- data.frame(ligand = character(0), receptor = character(0),
                          pair = character(0), pair_id = character(0),
                          group = character(0), mean_activity = numeric(0),
                          n_spots = integer(0), stringsAsFactors = FALSE)
  if (length(groups) == 0L) {
    return(empty_tbl)                                 # typed empty table, never NULL
  }
  scor_ids <- pair_id[p$scorable]

  rows <- lapply(groups, function(gp) {
    cols <- which(labels == gp)
    mean_by_id <- stats::setNames(rep(NA_real_, length(pair_id)), pair_id)
    if (length(cols) && nrow(act)) {
      mean_by_id[scor_ids] <- as.numeric(Matrix::rowMeans(act[, cols, drop = FALSE]))
    }
    data.frame(ligand = p$ligand, receptor = p$receptor, pair = display,
               pair_id = pair_id, group = gp,
               mean_activity = as.numeric(mean_by_id), n_spots = length(cols),
               stringsAsFactors = FALSE)
  })
  res <- do.call(rbind, rows)
  rownames(res) <- NULL
  res
}
