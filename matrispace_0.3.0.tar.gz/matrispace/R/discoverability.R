# Discoverability API (FIX_GUIDE s5). Pure, read-only helpers that let users see
# which bundled signatures/niches exist and how to select them, without touching
# any container or storage. They read only bundled reference data.

#' List bundled matrisome signatures.
#'
#' Returns the [matrisome_signature_manifest] rows, optionally filtered. Use the
#' `key` column values with `score_matrisome(include = ...)`.
#'
#' @param level Optional filter: keep only `"category"` (the six broad ECM
#'   categories) and/or `"subcategory"` (narrower families/programs).
#' @param category Optional filter: keep signatures whose parent category matches
#'   any given label (e.g. `"Collagens"`), matched case-insensitively against the
#'   manifest `category` field's components.
#' @return A data.frame with columns `key`, `label`, `level`, `category`,
#'   `n_genes`, `reference_version`.
#' @export
list_matrisome_signatures <- function(level = NULL, category = NULL) {
  m <- matrisome_signature_manifest
  if (!is.null(level)) {
    ok <- c("category", "subcategory")
    if (!is.character(level) || !length(level) || !all(level %in% ok)) {
      stop("matrispace: `level` must be a subset of: ",
           paste(ok, collapse = ", "), call. = FALSE)
    }
    m <- m[m$level %in% level, , drop = FALSE]
  }
  if (!is.null(category)) {
    if (!is.character(category) || !length(category)) {
      stop("matrispace: `category` must be a non-empty character vector",
           call. = FALSE)
    }
    want <- tolower(category)
    comps <- strsplit(m$category, "; ", fixed = TRUE)
    keep <- vapply(comps, function(cc) any(want %in% tolower(cc)), logical(1))
    m <- m[keep, , drop = FALSE]
  }
  rownames(m) <- NULL
  m
}

#' List bundled ECM niches and their available modes.
#'
#' Shows, for every bundled niche, whether it supports continuous scoring
#' ([score_ecm_niche_signatures()], from [ecm_signatures]) and/or ScType-style
#' classification ([annotate_ecm_niches()], from [ecm_markers]). In the current
#' reference snapshot `vascular` is classification-only.
#'
#' @param mode Optional filter: `"continuous"` or `"classification"` returns only
#'   the niches available in that mode; `NULL` returns all niches.
#' @return A data.frame with columns `niche`, `continuous`, `classification`
#'   (the two logical columns give per-mode availability).
#' @export
list_ecm_niches <- function(mode = NULL) {
  cont <- names(ecm_signatures)
  clas <- names(ecm_markers)
  niches <- union(clas, cont)              # classification order, extras appended
  df <- data.frame(
    niche = niches,
    continuous = niches %in% cont,
    classification = niches %in% clas,
    stringsAsFactors = FALSE)
  if (!is.null(mode)) {
    mode <- match.arg(mode, c("continuous", "classification"))
    df <- df[df[[mode]], , drop = FALSE]
  }
  rownames(df) <- NULL
  df
}
