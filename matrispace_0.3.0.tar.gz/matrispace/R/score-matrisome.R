# Matrisome signature scoring (SPEC s7). UCell module scores over an EXPLICIT
# assay/layer (no hidden normalization), stored keyed by machine keys in
# host-native feature-result storage, discoverable through the registry.

.score_ucell_signatures <- function(object, signatures, assay, layer,
                                    min_genes, maxRank, artifact, producer,
                                    overwrite = FALSE) {
  if (!requireNamespace("UCell", quietly = TRUE)) {
    stop("matrispace: ", producer, "() requires the 'UCell' package", call. = FALSE)
  }
  if (!is.list(signatures) || length(signatures) == 0L ||
      is.null(names(signatures)) || any(!nzchar(names(signatures))) ||
      anyDuplicated(names(signatures))) {
    stop("matrispace: `signatures` must be a non-empty, uniquely-named list of ",
         "gene vectors", call. = FALSE)
  }
  # Each signature must be a character vector without NA/empty gene names (an
  # empty vector is allowed and becomes unscorable).
  for (k in names(signatures)) {
    g <- signatures[[k]]
    if (!is.character(g) || anyNA(g) || any(!nzchar(g))) {
      stop("matrispace: signature '", k, "' must be a character vector with no ",
           "NA or empty gene names", call. = FALSE)
    }
  }
  if (!.is_pos_whole(min_genes)) {
    stop("matrispace: `min_genes` must be a positive whole number", call. = FALSE)
  }
  if (!.is_pos_whole(maxRank)) {
    stop("matrispace: `maxRank` must be a positive whole number", call. = FALSE)
  }

  # Fingerprint the FULL computation (genes + resolved assay/layer + params) and
  # decide before the expensive UCell pass: an identical prior run is returned
  # untouched; a different one requires overwrite = TRUE.
  src <- .resolve_expression_source(object, assay = assay, layer = layer)
  fp <- .computation_fingerprint(
    signatures, src$assay, src$layer,
    params = list(min_genes = min_genes, maxRank = maxRank))
  decision <- .overwrite_decision(object, artifact, fp, overwrite, producer)
  if (identical(decision, "skip")) return(object)

  expr <- .get_expression(object, assay = assay, layer = layer)
  # Necessary (not sufficient) scale check: finite and non-negative. Providing a
  # NORMALIZED scale is the caller's responsibility (raw counts also pass this).
  .validate_nonneg_finite(expr, "expression")
  spots <- colnames(object)
  genes <- rownames(expr)
  keys <- names(signatures)
  maxRank_eff <- min(as.integer(maxRank), nrow(expr))

  matched <- lapply(signatures, function(g) intersect(g, genes))
  scorable <- keys[lengths(matched) >= min_genes]
  empty <- setdiff(keys, scorable)
  if (length(empty)) {
    warning("matrispace: signature(s) with fewer than ", min_genes,
            " matched gene(s) scored as NA: ", paste(empty, collapse = ", "),
            call. = FALSE)
  }

  scores <- matrix(NA_real_, nrow = length(keys), ncol = length(spots),
                   dimnames = list(keys, spots))
  if (length(scorable)) {
    # Serial backend: deterministic and avoids the Windows MulticoreParam warning.
    bp <- if (requireNamespace("BiocParallel", quietly = TRUE)) {
      BiocParallel::SerialParam()
    } else {
      NULL
    }
    uc <- UCell::ScoreSignatures_UCell(expr, features = matched[scorable],
                                       name = "", BPPARAM = bp,
                                       maxRank = maxRank_eff)
    uc <- t(as.matrix(uc))                       # signatures x spots
    scores[rownames(uc), colnames(uc)] <- uc[, spots, drop = FALSE]
  }

  .set_feature_result(object, artifact, scores, type = "score",
    context = list(producer = producer,
                   input_assay = assay %||% NA_character_,
                   input_layer = layer %||% NA_character_,
                   parameters = list(
                     signatures = keys,
                     # Deterministic digest of the canonicalized key -> gene-set
                     # mapping, so identical keys with different genes are
                     # distinguishable in provenance.
                     signature_digest = .definition_digest(signatures),
                     # Complete computation fingerprint used by the overwrite
                     # guard (definition + resolved assay/layer + parameters).
                     fingerprint = fp,
                     matched_genes = lengths(matched)[keys],
                     min_genes = min_genes, maxRank = maxRank,
                     maxRank_effective = maxRank_eff)))
}

#' Score matrisome signatures with UCell and store the result.
#'
#' Supply exactly one of `signatures` (custom definitions) or `include` (bundled
#' [matrisome_signatures] keys); omit both to score every bundled signature.
#' Discover and filter the bundled keys with [list_matrisome_signatures()].
#'
#' @param object A Seurat or SpatialExperiment object.
#' @param signatures Named list of custom gene-signature vectors (names are
#'   machine keys). Mutually exclusive with `include`.
#' @param include Character vector of bundled signature keys to score, in the
#'   requested order. Mutually exclusive with `signatures`.
#' @param assay,layer Explicit expression source; the scale is used as given
#'   (no normalization side effect).
#' @param min_genes Minimum matched genes for a signature to be scored (else NA).
#' @param maxRank UCell rank cutoff (capped at the feature count).
#' @param overwrite Replace an existing `matrisome` artifact that was scored from
#'   a different definition/parameters. Default `FALSE` errors instead, because
#'   results are not appended across calls -- select all desired categories in a
#'   single call.
#' @param ... Unused.
#' @return The object with a `matrisome` score artifact stored in its registry.
#' @export
score_matrisome <- function(object, signatures = NULL, include = NULL,
                            assay, layer = NULL,
                            min_genes = 1L, maxRank = 1500,
                            overwrite = FALSE, ...) {
  if (missing(assay)) stop("matrispace: `assay` is required", call. = FALSE)
  signatures <- .select_bundled(signatures, include, matrisome_signatures,
                                "signatures", "include", "matrisome signature")
  .score_ucell_signatures(
    object, signatures, assay, layer, min_genes, maxRank,
    artifact = "matrisome", producer = "score_matrisome", overwrite = overwrite)
}

#' Score continuous ECM-niche signatures with UCell
#'
#' This is continuous signature scoring, distinct from the ScType-style
#' classification performed by [annotate_ecm_niches()]. Results are stored as
#' `ecm_niche_signature_scores` and never overwrite classification scores.
#'
#' Supply exactly one of `signatures` (custom definitions) or `niches` (bundled
#' [ecm_signatures] keys); omit both to score every bundled continuous niche.
#' See [list_ecm_niches()] for which niches support continuous scoring (note
#' `vascular` is classification-only).
#'
#' @inheritParams score_matrisome
#' @param signatures Named list of custom ECM-niche signatures. Mutually
#'   exclusive with `niches`.
#' @param niches Character vector of bundled continuous-niche keys to score, in
#'   the requested order. Mutually exclusive with `signatures`.
#' @param overwrite Replace an existing `ecm_niche_signature_scores` artifact
#'   scored from a different definition/parameters (default `FALSE` errors).
#' @return The object with an `ecm_niche_signature_scores` artifact.
#' @export
score_ecm_niche_signatures <- function(object, signatures = NULL, niches = NULL,
                                       assay, layer = NULL, min_genes = 1L,
                                       maxRank = 1500, overwrite = FALSE, ...) {
  if (missing(assay)) stop("matrispace: `assay` is required", call. = FALSE)
  signatures <- .select_bundled(signatures, niches, ecm_signatures,
                                "signatures", "niches", "ECM niche")
  .score_ucell_signatures(
    object, signatures, assay, layer, min_genes, maxRank,
    artifact = "ecm_niche_signature_scores",
    producer = "score_ecm_niche_signatures", overwrite = overwrite)
}

# Optionally restrict a stored score matrix to a requested subset of rows,
# preserving the requested order. Unknown keys are named alongside the available
# choices so one full scoring run can serve a subset without rescoring.
.subset_score_rows <- function(m, keys, what) {
  if (is.null(keys)) return(m)
  if (!is.character(keys) || length(keys) == 0L) {
    stop("matrispace: `", what, "` must be a non-empty character vector",
         call. = FALSE)
  }
  missing <- setdiff(keys, rownames(m))
  if (length(missing)) {
    stop("matrispace: unknown ", what, ": ", paste(missing, collapse = ", "),
         " (available: ", paste(rownames(m), collapse = ", "), ")", call. = FALSE)
  }
  m[keys, , drop = FALSE]
}

#' Retrieve continuous ECM-niche signature scores
#' @param object A Seurat or SpatialExperiment object.
#' @param niches Optional character vector selecting a subset of scored niches
#'   (preserving the requested order); `NULL` returns all.
#' @return A niche-signature x spot score matrix.
#' @export
get_ecm_niche_signature_scores <- function(object, niches = NULL) {
  reg <- .get_registry(object)
  if (is.null(reg) || !("ecm_niche_signature_scores" %in% names(reg$artifacts))) {
    stop("matrispace: object has no ECM-niche signature scores; run ",
         "score_ecm_niche_signatures() first", call. = FALSE)
  }
  m <- .get_feature_result(object, "ecm_niche_signature_scores")
  .subset_score_rows(m, niches, "niches")
}

#' Has this object been matrisome-scored?
#' @param object A Seurat or SpatialExperiment object.
#' @return Logical scalar.
#' @export
has_matrisome_scores <- function(object) {
  reg <- .get_registry(object)
  !is.null(reg) && "matrisome" %in% names(reg$artifacts)
}

#' Retrieve the stored matrisome score matrix (signature keys x spots).
#' @param object A Seurat or SpatialExperiment object.
#' @param signatures Optional character vector selecting a subset of scored
#'   signature keys (preserving the requested order); `NULL` returns all. Lets
#'   one full scoring run serve a subset without rescoring or copying the object.
#' @return A features x spots score matrix.
#' @export
get_matrisome_scores <- function(object, signatures = NULL) {
  if (!has_matrisome_scores(object)) {
    stop("matrispace: object has no matrisome scores; run score_matrisome() first",
         call. = FALSE)
  }
  m <- .get_feature_result(object, "matrisome")
  .subset_score_rows(m, signatures, "signatures")
}
