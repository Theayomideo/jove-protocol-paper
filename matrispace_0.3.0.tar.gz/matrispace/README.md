# MatriSpace

MatriSpace provides tools for analyzing and visualizing extracellular matrix
(ECM) gene expression in spatially resolved transcriptomic data. It accepts
Seurat and SpatialExperiment objects and supports matrisome scoring, ECM niche
annotation, spatial statistics and matrisome pair co-expression.

This source package contains version 0.3.0 used for the JoVE cohort protocol.
The published package and its documentation remain available in the
[MatriSpace repository](https://github.com/Theayomideo/matrispace).

## Installation

Install UCell from Bioconductor, then install this source package.

```r
install.packages(c("BiocManager", "remotes", "Seurat"))
BiocManager::install("UCell")
remotes::install_local("matrispace_0.3.0.tar.gz", dependencies = NA)
```

## Matrisome scoring

```r
library(matrispace)

obj <- readRDS("IPF_cohort_MatriSpace.rds")
categories <- list_matrisome_signatures(level = "category")$key
obj <- score_matrisome(obj, include = categories, assay = "Spatial")
scores <- get_matrisome_scores(obj)
```

`score_matrisome()` calculates UCell scores from the specified expression
assay. `get_matrisome_scores()` returns a matrix with signatures in rows and
spots in columns. The input object should already contain normalized expression,
spatial coordinates and the annotations needed for analysis.

## Spatial analysis

Build a graph before calculating spatial statistics or pair co-expression.
For the Visium cohort, coordinates are in micrometres and a 120 micrometre
radius connects the first ring of neighbouring spots within each section.

```r
obj <- build_spatial_graph(obj, method = "radius", radius = 120,
                           coordinate_units = "um", graph_name = "ring1")
obj <- score_lr_activity(obj, pairs = read.csv("cell_matrix_pairs.csv"),
                         graph = "ring1", assay = "Spatial")
```

The paper repository contains the cohort notebook, helper functions and the
pair list used in the protocol. See the package help pages for the full
function arguments and return values.

## Citation

Oshinjo A, Chen D, Petrov P, Izzi V and Naba A. MatriSpace: Identification and
visualization of spatially resolved ECM gene expression patterns in health and
disease. https://doi.org/10.64898/2026.04.26.720198

[MatriSpace web application](https://izzilab-matrispace.share.connect.posit.cloud/)
