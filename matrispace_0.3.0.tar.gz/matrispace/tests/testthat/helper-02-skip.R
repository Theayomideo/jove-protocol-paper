# ---------------------------------------------------------------------------
# Gating: the rewrite is TDD-first. Every contract test is guarded so that
# until `matrispace >= 0.2.0` is loaded (via devtools::load_all / install),
# the test SKIPS instead of erroring on an undefined function. As each
# function is implemented it is picked up automatically.
# ---------------------------------------------------------------------------

# The matrispace namespace, or NULL if not loadable.
mtx_ns <- function() {
  if (!("matrispace" %in% loadedNamespaces() ||
        requireNamespace("matrispace", quietly = TRUE))) {
    return(NULL)
  }
  tryCatch(asNamespace("matrispace"), error = function(e) NULL)
}

# TRUE only when the rewrite (>= 0.2.0) is the loaded matrispace. Guards against
# an installed legacy 0.1.x package masquerading as "implemented".
rewrite_loaded <- function() {
  ns <- mtx_ns()
  if (is.null(ns)) return(FALSE)
  tryCatch(utils::packageVersion("matrispace") >= "0.2.0",
           error = function(e) FALSE)
}

# Does a (possibly internal, dot-prefixed) function exist in the rewrite?
fn_exists <- function(name) {
  ns <- mtx_ns()
  if (!is.null(ns) && exists(name, envir = ns, inherits = FALSE) &&
      is.function(get0(name, envir = ns, inherits = FALSE))) {
    return(TRUE)
  }
  is.function(get0(name, envir = globalenv(), inherits = FALSE))
}

# Resolve a matrispace function by name (namespace first, then global). Only
# call after skip_if_not_implemented() has cleared the same name.
mfn <- function(name) {
  ns <- mtx_ns()
  if (!is.null(ns) && exists(name, envir = ns, inherits = FALSE)) {
    return(get(name, envir = ns, inherits = FALSE))
  }
  get(name, envir = globalenv(), inherits = FALSE)
}

# Skip the current test unless the rewrite is loaded AND every named function
# is implemented.
skip_if_not_implemented <- function(...) {
  if (!rewrite_loaded()) {
    testthat::skip("matrispace rewrite (>= 0.2.0) not loaded")
  }
  fns <- unlist(list(...), use.names = FALSE)
  missing <- fns[!vapply(fns, fn_exists, logical(1))]
  if (length(missing)) {
    testthat::skip(paste0("not implemented yet: ",
                          paste(missing, collapse = ", ")))
  }
  invisible(TRUE)
}
