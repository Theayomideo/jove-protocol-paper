test_that("bundled matrisome reference has the canonical DE schema", {
  expect_s3_class(matrisome_db, "data.frame")
  expect_identical(names(matrisome_db)[1:2], c("gene", "category"))
  expect_gt(nrow(matrisome_db), 1000L)
  expect_false(anyNA(matrisome_db$gene))
  expect_identical(anyDuplicated(matrisome_db$gene), 0L)
  expect_true(all(nzchar(matrisome_db$category)))

  expect_type(matrisome_signatures, "list")
  expect_gt(length(matrisome_signatures), 20L)
  expect_true(all(grepl("^[a-z][a-z0-9_]*$", names(matrisome_signatures))))
  expect_identical(anyDuplicated(names(matrisome_signatures)), 0L)
  expect_true(all(lengths(matrisome_signatures) > 0L))
  expect_true(all(unique(unlist(matrisome_signatures)) %in% matrisome_db$gene))
})

test_that("bundled niche references match scoring and annotation contracts", {
  expect_identical(names(ecm_markers), c("interstitial", "basement", "vascular"))
  for (x in ecm_markers) {
    expect_identical(names(x), c("positive", "negative"))
    expect_type(x$positive, "character")
    expect_type(x$negative, "character")
    expect_false(anyNA(c(x$positive, x$negative)))
    expect_length(x$negative, 0L)
  }
  expect_true("KNG1" %in% ecm_markers$vascular$positive)
  expect_false("KNG" %in% ecm_markers$vascular$positive)
  expect_identical(names(ecm_signatures), c("interstitial", "basement"))
  expect_true(all(lengths(ecm_signatures) > 0L))
})

test_that("bundled matrisome pairs are unique, unordered, heterotypic, and evidence-aware", {
  expect_s3_class(matrisome_pairs, "data.frame")
  expect_identical(names(matrisome_pairs), c(
    "gene_1", "gene_2", "interaction_type", "source", "database_score",
    "evidence_count", "source_count"))
  expect_gt(nrow(matrisome_pairs), 16000L)
  expect_true(all(matrisome_pairs$gene_1 < matrisome_pairs$gene_2))
  expect_false(anyNA(matrisome_pairs[, c("gene_1", "gene_2")]))
  expect_identical(anyDuplicated(matrisome_pairs[, c("gene_1", "gene_2")]), 0L)
  expect_false(isTRUE(any(grepl("///", matrisome_pairs$gene_1, fixed = TRUE))))
  expect_false(isTRUE(any(grepl("///", matrisome_pairs$gene_2, fixed = TRUE))))
  expect_true(all(matrisome_pairs$evidence_count >= 1L))
  expect_true(all(matrisome_pairs$source_count >= 1L))
})

test_that("reference manifest is complete and checksums loaded objects", {
  required <- c(
    "object", "schema_version", "source_repository", "source_commit",
    "source_file", "source_sha256", "source_date", "license", "species",
    "gene_identifier", "transformation", "schema", "source_rows",
    "packaged_rows", "excluded_rows", "collapsed_rows", "object_sha256")
  expect_true(all(required %in% names(reference_data_manifest)))
  expect_identical(reference_data_manifest$object, c(
    "matrisome_db", "matrisome_signatures", "ecm_signatures", "ecm_markers",
    "matrisome_pairs"))
  expect_true(all(reference_data_manifest$species == "Homo sapiens"))
  objs <- list(matrisome_db = matrisome_db,
               matrisome_signatures = matrisome_signatures,
               ecm_signatures = ecm_signatures, ecm_markers = ecm_markers,
               matrisome_pairs = matrisome_pairs)
  # Verify with the SAME canonical, load-path-independent digest used to seal the
  # manifest (raw serialize() hashes differ between load()ed and LazyData/ALTREP
  # materializations, which is not a reproducible integrity check).
  hashes <- vapply(objs, mfn(".reference_object_digest"), character(1))
  expect_identical(unname(hashes), reference_data_manifest$object_sha256)
  # The canonical digest must be collision-safe at the semantic layer, not just
  # reproducible: these pairs are DIFFERENT objects and must hash differently.
  d <- mfn(".reference_object_digest")
  expect_false(d(NA_character_) == d("NA"))          # NA vs literal "NA"
  expect_false(d(character(0)) == d(""))             # empty vector vs ""
  expect_false(d(1) == d("1"))                       # double vs character
  expect_false(d(1L) == d(1))                        # integer vs double
  expect_false(d(c(a = 1)) == d(c(b = 1)))           # names matter
  expect_false(d(c(a = 1)) == d(1))                  # named vs unnamed
  expect_false(d(factor("1")) == d("1"))             # factor vs character
  expect_false(d(list(a = 1)) == d(list(b = 1)))     # list names matter
  expect_false(d(list(1)) == d(1))                   # list vs atomic
  df1 <- data.frame(x = 1:2, row.names = c("r1", "r2"))
  df2 <- data.frame(x = 1:2, row.names = c("r1", "r3"))
  expect_false(d(df1) == d(df2))                     # row names matter
  expect_false(d(factor("1")) == d(factor("1", ordered = TRUE)))  # ordered status
  expect_identical(d(matrisome_signatures), d(matrisome_signatures))  # stable

  # Objects OUTSIDE the supported reference domain are rejected, not silently
  # under-encoded (which is how a matrix or custom-classed value could collide).
  expect_error(d(matrix(1:4, 2, 2)), "dimensioned")
  expect_error(d(structure(1:4, class = "foo")), "unsupported classed")
  expect_error(d(as.raw(1:3)), "unsupported atomic type")

  lr <- reference_data_manifest[reference_data_manifest$object == "matrisome_pairs", ]
  expect_equal(lr$source_rows, 24539L)
  expect_gt(lr$packaged_rows, 16000L)
  expect_equal(lr$source_rows,
               lr$packaged_rows + lr$excluded_rows + lr$collapsed_rows)
})

test_that("scoring functions default definition + selector to NULL (resolve at runtime)", {
  # The definition/selector pair defaults to NULL; omitting both scores all
  # bundled signatures (resolved via .select_bundled), so no lazy-data default
  # is baked into the formals.
  expect_null(formals(score_matrisome)$signatures)
  expect_null(formals(score_matrisome)$include)
  expect_null(formals(score_ecm_niche_signatures)$signatures)
  expect_null(formals(score_ecm_niche_signatures)$niches)
  expect_null(formals(annotate_ecm_niches)$markers)
  expect_null(formals(annotate_ecm_niches)$niches)
  # These functions keep their bundled defaults directly.
  expect_identical(formals(score_matrisome_pair_coexpression)$pairs, quote(matrisome_pairs))
  expect_null(formals(score_matrisome_pair_coexpression)$database)
  expect_identical(formals(find_ecm_markers)$matrisome, quote(matrisome_db))
  expect_identical(formals(find_ecm_de)$matrisome, quote(matrisome_db))
})

test_that("category signatures follow the app's canonical coverage", {
  cats <- list_matrisome_signatures(level = "category")$key
  expect_false(any(c("F8", "USH2A") %in% unlist(matrisome_signatures[cats])))
  expect_true(all(c("F8", "USH2A") %in% matrisome_db$gene))
})
