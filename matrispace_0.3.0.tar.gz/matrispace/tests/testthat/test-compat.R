# Accessor / setter contract (arch doc s2.3). These run identically against
# every installed container so version breakage is centralised here. Direct S4
# slot access is prohibited outside compat-*.R; these tests are the guardrail.
#
# The (assay, layer) model differs by container: Seurat uses a named assay + a
# layer; SpatialExperiment uses assayNames and has no layer. Tests request data
# through each container's native handle (tf_expr_args / tf_counts_args), never
# a shared fiction like assay = "RNA".

ACCESSORS <- c(".get_expression", ".get_counts", ".get_coordinates",
               ".get_spot_metadata", ".set_spot_metadata", ".get_registry",
               ".set_registry", ".set_feature_result", ".get_feature_result")

get_expr <- function(ct, obj) {
  do.call(mfn(".get_expression"), c(list(obj), tf_expr_args(ct)))
}
get_cnts <- function(ct, obj) {
  do.call(mfn(".get_counts"), c(list(obj), tf_counts_args(ct)))
}
skip_container <- function(ct) {
  skip_if_not_installed(if (ct == "seurat") "Seurat" else "SpatialExperiment")
}

for (ct in c("seurat", "spe")) {

  test_that(sprintf("[%s] expression + counts round-trip as genes x spots", ct), {
    skip_if_not_implemented(".get_expression", ".get_counts")
    skip_container(ct)
    u <- tf_universe(); obj <- tf_container(ct, u)

    expr <- get_expr(ct, obj)
    expect_equal(rownames(expr), u$genes)
    expect_equal(colnames(expr), u$spots)
    expect_equal(as.matrix(expr)[u$genes, u$spots], as.matrix(u$logcounts),
                 tolerance = TOL_LOOSE)

    cnt <- get_cnts(ct, obj)
    expect_equal(as.matrix(cnt)[u$genes, u$spots], as.matrix(u$counts))
  })

  test_that(sprintf("[%s] coordinates align to spot ids", ct), {
    skip_if_not_implemented(".get_coordinates")
    skip_container(ct)
    u <- tf_universe(); obj <- tf_container(ct, u)

    xy <- mfn(".get_coordinates")(obj)
    expect_equal(nrow(xy), length(u$spots))
    expect_setequal(rownames(xy), u$spots)
    expect_equal(as_xy(xy)[u$spots, ], as_xy(u$coords)[u$spots, ],
                 tolerance = TOL_COORD)
  })

  test_that(sprintf("[%s] coordinates can be fetched per image", ct), {
    skip_if_not_implemented(".get_coordinates")
    skip_container(ct)
    u <- tf_universe(n_images = 2); obj <- tf_container(ct, u)

    im1 <- u$images[1]
    xy1 <- mfn(".get_coordinates")(obj, image_id = im1)
    expect_setequal(rownames(xy1), u$spots[u$image_ids == im1])
  })

  test_that(sprintf("[%s] spot metadata round-trips through set/get", ct), {
    skip_if_not_implemented(".get_spot_metadata", ".set_spot_metadata")
    skip_container(ct)
    u <- tf_universe(); obj <- tf_container(ct, u)

    md <- mfn(".get_spot_metadata")(obj)
    expect_true(all(c("replicate_id", "group") %in% colnames(md)))
    expect_setequal(rownames(md), u$spots)

    labels <- setNames(rep(c("x", "y"), length.out = length(u$spots)), u$spots)
    obj2 <- mfn(".set_spot_metadata")(obj, "my_label", labels)
    got <- mfn(".get_spot_metadata")(obj2)[["my_label"]]
    names(got) <- rownames(mfn(".get_spot_metadata")(obj2))
    expect_equal(got[u$spots], labels[u$spots])
  })

  test_that(sprintf("[%s] registry set/get round-trips", ct), {
    skip_if_not_implemented(".get_registry", ".set_registry", ".new_registry")
    skip_container(ct)
    obj <- tf_container(ct)

    reg <- mfn(".new_registry")()  # complete registry; setter validates strictly
    obj2 <- mfn(".set_registry")(obj, reg)
    expect_equal(mfn(".get_registry")(obj2)$schema_version, "1.0.0")
  })

  test_that(sprintf("[%s] .set_registry rejects an incomplete registry", ct), {
    skip_if_not_implemented(".set_registry")
    skip_container(ct)
    obj <- tf_container(ct)
    # Missing package_version / history / reference_versions.
    bad <- list(schema_version = "1.0.0", graphs = list(), artifacts = list())
    expect_error(mfn(".set_registry")(obj, bad), regexp = "missing|slot")
  })

  test_that(sprintf("[%s] feature-result matrix round-trips", ct), {
    skip_if_not_implemented(".set_feature_result", ".get_feature_result")
    skip_container(ct)
    u <- tf_universe(); obj <- tf_container(ct, u)

    scores <- matrix(seq_len(3 * length(u$spots)), nrow = 3,
                     dimnames = list(c("collagens", "glycoproteins", "proteoglycans"),
                                     u$spots))
    obj2 <- mfn(".set_feature_result")(obj, "matrisome_scores", scores, type = "score")
    got <- mfn(".get_feature_result")(obj2, "matrisome_scores")
    expect_equal(as.matrix(got)[rownames(scores), u$spots], scores,
                 tolerance = TOL_LOOSE)
  })

  test_that(sprintf("[%s] accessors are reorder-safe (align by id, not position)", ct), {
    skip_if_not_implemented(".get_expression", ".get_coordinates")
    skip_container(ct)
    u <- tf_universe(); obj <- tf_container(ct, u)

    perm <- rev(seq_len(length(u$spots)))
    # SeuratObject emits benign "Not validating ..." chatter when subsetting an
    # FOV object; that is not what this test exercises, so muffle just the
    # container op (the accessor calls below stay unsuppressed).
    obj_perm <- suppressWarnings(obj[, perm])

    expr <- get_expr(ct, obj_perm)
    expect_equal(as.matrix(expr)[u$genes, u$spots], as.matrix(u$logcounts),
                 tolerance = TOL_LOOSE)
    xy <- mfn(".get_coordinates")(obj_perm)
    expect_equal(as_xy(xy)[u$spots, ], as_xy(u$coords)[u$spots, ],
                 tolerance = TOL_COORD)
  })

  test_that(sprintf("[%s] accessors survive subsetting", ct), {
    skip_if_not_implemented(".get_expression", ".get_spot_metadata")
    skip_container(ct)
    u <- tf_universe(); obj <- tf_container(ct, u)

    keep <- u$spots[1:6]
    sub <- suppressWarnings(obj[, keep])  # muffle SeuratObject FOV-subset chatter
    expr <- get_expr(ct, sub)
    expect_setequal(colnames(expr), keep)
    expect_setequal(rownames(mfn(".get_spot_metadata")(sub)), keep)
  })
}

# ---- The actual "RNA" regression guard: accessors must not hardcode a name ---

test_that("[seurat] .get_expression reads the assay by name, not a hardcoded 'RNA'", {
  skip_if_not_implemented(".get_expression")
  skip_if_not_installed("Seurat")
  u <- tf_universe()
  spatial_obj <- tf_seurat(u, assay = "Spatial")
  rna_obj     <- tf_seurat(u, assay = "RNA")

  e_spatial <- mfn(".get_expression")(spatial_obj, assay = "Spatial", layer = "data")
  e_rna     <- mfn(".get_expression")(rna_obj, assay = "RNA", layer = "data")
  # Same underlying data returned regardless of the assay's name.
  expect_equal(as.matrix(e_spatial)[u$genes, u$spots],
               as.matrix(e_rna)[u$genes, u$spots], tolerance = TOL_LOOSE)
})

# ---- Missing values must pass through, not be silently zero-filled ----------

test_that("[spe] .get_expression preserves NA rather than coercing to 0", {
  skip_if_not_implemented(".get_expression")
  skip_if_not_installed("SpatialExperiment")
  u <- tf_universe()
  dense <- as.matrix(u$logcounts)
  dense[1, 1] <- NA_real_
  u$logcounts <- Matrix::Matrix(dense, sparse = TRUE)
  obj <- tf_spe(u)

  expr <- mfn(".get_expression")(obj, assay = "logcounts", layer = NULL)
  expect_true(is.na(as.matrix(expr)[u$genes[1], u$spots[1]]))
})

# ---- Image membership: the coordinate-frame identity, distinct from replicate -

for (ct in c("seurat", "spe")) {
  test_that(sprintf("[%s] .get_image_membership maps every spot to one image", ct), {
    skip_if_not_implemented(".get_image_membership")
    skip_container(ct)
    u <- tf_universe(n_images = 2); obj <- tf_container(ct, u)
    mem <- mfn(".get_image_membership")(obj)
    expect_setequal(names(mem), u$spots)
    expect_setequal(unique(unname(mem)), u$images)
    expect_equal(unname(mem[u$spots]), u$image_ids)
    # image identity is NOT the biological replicate
    expect_false(identical(unname(mem[u$spots]), u$replicate_ids[match(u$spots, u$spots)]))
  })
}

test_that("[seurat] a spot with no image is an error at graph construction", {
  skip_if_not_implemented("build_spatial_graph")
  skip_if_not_installed("Seurat")
  u <- tf_universe()
  # A Seurat object carrying expression + metadata but NO FOV/image.
  bare <- SeuratObject::CreateSeuratObject(counts = u$counts,
            meta.data = u$metadata, assay = "Spatial")
  expect_error(build_spatial_graph(bare, method = "knn", k = 4, graph_name = "g"),
               regexp = "image|coordinate|FOV")
})

test_that("[seurat] a spot in two FOVs is rejected (exactly-one-image rule)", {
  skip_if_not_implemented(".get_image_membership")
  skip_if_not_installed("Seurat")
  u <- tf_universe(n_spots = 12, n_images = 1)
  obj <- tf_seurat(u)  # FOV 'image1' holds all 12 cells
  # Add a second FOV whose cells overlap the first.
  cc <- u$coords[1:6, , drop = FALSE]
  cents <- SeuratObject::CreateCentroids(
    data.frame(x = cc[, "x"], y = cc[, "y"], cell = rownames(cc)))
  fov2 <- SeuratObject::CreateFOV(cents, type = "centroids", assay = "Spatial",
                                  key = "dup_")
  obj <- suppressWarnings({ obj[["dup"]] <- fov2; obj })
  expect_error(mfn(".get_image_membership")(obj),
               regexp = "more than one image|exactly one")
})

test_that("[spe] sample_id with NA or empty library id is rejected", {
  skip_if_not_implemented(".get_image_membership")
  skip_if_not_installed("SpatialExperiment")
  u <- tf_universe(); spe <- tf_spe(u)
  # SPE guards colData(sample_id)<- against imgData, so corrupt the slot
  # directly to exercise the defensive NA/empty check.
  spe@colData[["sample_id"]][1] <- NA_character_
  expect_error(mfn(".get_image_membership")(spe), regexp = "NA|empty")
})

test_that("[spe] fewer than two coordinate dimensions is an error", {
  skip_if_not_implemented(".get_coordinates")
  skip_if_not_installed("SpatialExperiment")
  u <- tf_universe()
  spe <- SpatialExperiment::SpatialExperiment(
    assays = list(counts = u$counts, logcounts = u$logcounts),
    spatialCoords = u$coords[, 1, drop = FALSE],  # 1-D only
    colData = S4Vectors::DataFrame(u$metadata),
    sample_id = u$image_ids)
  expect_error(mfn(".get_coordinates")(spe), regexp = "2-D|coordinate|column")
})

test_that("set_spot_metadata rejects a value with duplicated spot names", {
  skip_if_not_implemented(".set_spot_metadata")
  skip_if_not_installed("SpatialExperiment")
  u <- tf_universe(); obj <- tf_container("spe", u)
  val <- setNames(seq_len(length(u$spots) + 1), c(u$spots, u$spots[1]))
  expect_error(mfn(".set_spot_metadata")(obj, "lab", val), regexp = "duplicat")
})

test_that("[spe] feature retrieval follows the manifest storage, not the key convention", {
  skip_if_not_implemented(".get_feature_result", ".new_manifest", ".set_registry",
                          ".new_registry")
  skip_if_not_installed("SpatialExperiment")
  u <- tf_universe(); obj <- tf_container("spe", u)
  scores <- matrix(seq_len(2 * length(u$spots)), nrow = 2,
                   dimnames = list(c("a", "b"), u$spots))
  # Store under a name that does NOT match .key_feature_result("myresult").
  se <- SummarizedExperiment::SummarizedExperiment(assays = list(data = scores))
  SingleCellExperiment::altExp(obj, "weird_storage_name") <- se
  reg <- mfn(".new_registry")()
  reg$artifacts[["myresult"]] <- mfn(".new_manifest")(
    storage = "weird_storage_name", layer = "data", type = "score")
  obj <- mfn(".set_registry")(obj, reg)

  got <- mfn(".get_feature_result")(obj, "myresult")
  expect_equal(as.matrix(got)[rownames(scores), u$spots], scores)
})

test_that("set_feature_result validates matrix identifiers before storage", {
  skip_if_not_implemented(".set_feature_result")
  skip_if_not_installed("SpatialExperiment")
  u <- tf_universe(); obj <- tf_container("spe", u)
  # Missing an object spot column.
  m1 <- matrix(1, nrow = 1, ncol = length(u$spots) - 1,
               dimnames = list("a", u$spots[-1]))
  expect_error(mfn(".set_feature_result")(obj, "r", m1, type = "score"),
               regexp = "missing")
  # Duplicated feature row names.
  m2 <- matrix(1, nrow = 2, ncol = length(u$spots),
               dimnames = list(c("a", "a"), u$spots))
  expect_error(mfn(".set_feature_result")(obj, "r", m2, type = "score"),
               regexp = "unique|feature")
})

for (ct in c("seurat", "spe")) {
  test_that(sprintf("[%s] an unknown image_id is an actionable error", ct), {
    skip_if_not_implemented(".get_coordinates")
    skip_container(ct)
    u <- tf_universe(n_images = 2); obj <- tf_container(ct, u)
    expect_error(mfn(".get_coordinates")(obj, image_id = "no_such_image"),
                 regexp = "unknown image")
  })
}

test_that("[spe] a physical assay without a registry artifact is not discoverable", {
  skip_if_not_implemented(".get_feature_result")
  skip_if_not_installed("SpatialExperiment")
  u <- tf_universe(); obj <- tf_container("spe", u)
  scores <- matrix(1, nrow = 1, ncol = length(u$spots),
                   dimnames = list("a", u$spots))
  se <- SummarizedExperiment::SummarizedExperiment(assays = list(data = scores))
  SingleCellExperiment::altExp(obj, "matrispace_ghost") <- se
  # No manifest registered -> not a matrispace result.
  expect_error(mfn(".get_feature_result")(obj, "ghost"),
               regexp = "no registered|artifact")
})
