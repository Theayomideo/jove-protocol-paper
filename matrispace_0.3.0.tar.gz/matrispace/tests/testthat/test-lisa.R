# Local indicators of spatial association (arch doc s3, s5.3). LISA must report
# the LOCAL statistic and inferential significance; quadrant labels alone are
# descriptive, not a significance test. FDR applies across the tested family.
# plot_lisa consumes the result, it must not recompute.

LISA_COLS <- c("spot_id", "image_id", "lisa", "quadrant", "p_value", "p_adjusted")

# A collinear path SPE (points 0..n-1); radius 1.5 yields the n-node path graph.
# `vals1`/`vals2` become genes g1/g2 in a dense counts assay (so NA survives).
lisa_path_spe <- function(vals1, vals2 = NULL) {
  n <- length(vals1); spots <- paste0("s", seq_len(n))
  coords <- cbind(x = seq_len(n) - 1, y = 0); rownames(coords) <- spots
  g2 <- if (is.null(vals2)) vals1 else vals2
  m <- rbind(g1 = vals1, g2 = g2); colnames(m) <- spots
  SpatialExperiment::SpatialExperiment(
    assays = list(counts = m), spatialCoords = coords,
    colData = S4Vectors::DataFrame(replicate_id = rep("r", n), row.names = spots),
    sample_id = rep("img", n))
}

test_that("univariate local Moran matches the path-graph hand oracle", {
  skip_if_not_implemented("build_spatial_graph", "compute_lisa")
  skip_if_not_installed("SpatialExperiment")
  # x = 1:4 on the row-standardized 4-node path: m2 = 1.25, local I = .6/.2/.2/.6.
  obj <- build_spatial_graph(lisa_path_spe(c(1, 2, 3, 4)), method = "radius",
                             radius = 1.5, graph_name = "g")
  res <- compute_lisa(obj, feature1 = "g1", graph = "g", n_perm = 19, seed = 1)
  res <- res[match(paste0("s", 1:4), res$spot_id), ]
  expect_equal(res$lisa, c(0.6, 0.2, 0.2, 0.6), tolerance = TOL)
  # low-low for the two low-value spots, high-high for the two high-value spots.
  expect_equal(res$quadrant, c("LL", "LL", "HH", "HH"))
})

test_that("Moran and LISA conventions agree with MERINGUE on a complete case", {
  skip_if_not_installed("SpatialExperiment")
  # MERINGUE master (functions.cpp::moranTest_C and lisaTest) row-unitizes W,
  # uses I = n/S0 * z'Wz/z'z and Ii = z_i/m2 * sum_j(w_ij z_j), and asserts
  # mean(Ii) == I. This dependency-free fixture locks that shared convention.
  x <- c(1, 2, 3, 4)
  obj <- build_spatial_graph(lisa_path_spe(x), method = "radius",
                             radius = 1.5, graph_name = "g")
  g <- get_matrispace_graph(obj, "g")
  res <- compute_lisa(obj, feature1 = "g1", graph = "g", n_perm = 19, seed = 1)
  global <- mfn(".morans_i")(x, g$connectivities, row_standardized = TRUE)
  expect_equal(mean(res$lisa), as.numeric(global), tolerance = TOL)

  W <- as.matrix(g$connectivities)
  rs <- rowSums(W); rs[rs == 0] <- 1; W <- W / rs
  z <- x - mean(x); m2 <- sum(z^2) / length(z)
  meringue_local <- (z / m2) * as.numeric(W %*% z)
  expect_equal(res$lisa, meringue_local, tolerance = TOL)
})

test_that("bivariate LISA matches the hand oracle", {
  skip_if_not_implemented("build_spatial_graph", "compute_lisa")
  skip_if_not_installed("SpatialExperiment")
  # feature1 = 1:4, feature2 = 4:1 -> I = (z1/m2) * lag(z2) = -.6/-.2/-.2/-.6.
  obj <- build_spatial_graph(lisa_path_spe(c(1, 2, 3, 4), c(4, 3, 2, 1)),
                             method = "radius", radius = 1.5, graph_name = "g")
  res <- compute_lisa(obj, feature1 = "g1", feature2 = "g2", graph = "g",
                      n_perm = 19, seed = 1)
  res <- res[match(paste0("s", 1:4), res$spot_id), ]
  expect_equal(res$lisa, c(-0.6, -0.2, -0.2, -0.6), tolerance = TOL)
})

test_that("LISA uses the finite induced subgraph, not zero-filled lags", {
  skip_if_not_implemented("build_spatial_graph", "compute_lisa")
  skip_if_not_installed("SpatialExperiment")
  # Path s1-s2-s3-s4 with s2 missing. In the induced graph on {s1,s3,s4}, s1's
  # only neighbour (s2) is gone -> s1 is isolated -> NA. Zero-filling would
  # instead give s1 a finite (zero-lag) value, so this distinguishes them.
  obj <- build_spatial_graph(lisa_path_spe(c(1, NA, 3, 4)), method = "radius",
                             radius = 1.5, graph_name = "g")
  res <- compute_lisa(obj, feature1 = "g1", graph = "g", n_perm = 19, seed = 1)
  res <- res[match(paste0("s", 1:4), res$spot_id), ]
  expect_true(is.na(res$lisa[1]))   # isolated in the induced graph
  expect_true(is.na(res$lisa[2]))   # missing feature
  expect_false(is.na(res$lisa[3]))  # s3-s4 edge survives
  expect_false(is.na(res$lisa[4]))
  expect_equal(res$n_spots_used[1], 3)  # induced image size
})

test_that("conditional permutation samples values, not 1:pool (length-one pool)", {
  skip_if_not_implemented("build_spatial_graph", "compute_lisa")
  skip_if_not_installed("SpatialExperiment")
  # Two connected spots: each focal spot's only permissible neighbor value is the
  # other spot's. Every permuted null must equal the observed statistic, so the
  # two-sided p-value is exactly 1. (A length-one numeric pool would otherwise
  # trip sample()'s 1:x shorthand and randomize the null.)
  obj <- build_spatial_graph(lisa_path_spe(c(0, 10)), method = "radius",
                             radius = 1.5, graph_name = "g")
  res <- compute_lisa(obj, feature1 = "g1", graph = "g", n_perm = 19, seed = 1)
  expect_true(all(res$p_value == 1))
})

test_that("LISA p_adjusted is BH within each image", {
  skip_if_not_implemented("build_spatial_graph", "compute_lisa")
  skip_if_not_installed("SpatialExperiment")
  u <- tf_universe(n_spots = 24, n_images = 2)
  obj <- build_spatial_graph(tf_container("spe", u), method = "knn", k = 4,
                             graph_name = "g")
  res <- compute_lisa(obj, feature1 = u$genes[1], graph = "g", n_perm = 99, seed = 1)
  for (im in u$images) {
    sub <- res[res$image_id == im & !is.na(res$p_value), ]
    expect_equal(sub$p_adjusted, stats::p.adjust(sub$p_value, "BH"))
  }
})

test_that("univariate local Moran reports statistic, quadrant, p and FDR", {
  skip_if_not_implemented("build_spatial_graph", "compute_lisa")
  skip_if_not_installed("SpatialExperiment")
  u <- tf_universe()
  obj <- build_spatial_graph(tf_container("spe", u), method = "knn", k = 4,
                             graph_name = "g")
  res <- compute_lisa(obj, feature1 = u$genes[1], graph = "g", n_perm = 49, seed = 1)

  expect_s3_class(res, "data.frame")
  expect_true(all(LISA_COLS %in% colnames(res)))
  expect_equal(nrow(res), length(u$spots))
  expect_true(all(res$p_value >= 0 & res$p_value <= 1))
  # Quadrants come from the standard HH/LL/HL/LH labelling.
  expect_true(all(res$quadrant %in% c("HH", "LL", "HL", "LH", NA)))
})

test_that("bivariate LISA accepts two features and stays spot-aligned", {
  skip_if_not_implemented("build_spatial_graph", "compute_lisa")
  skip_if_not_installed("SpatialExperiment")
  u <- tf_universe()
  obj <- build_spatial_graph(tf_container("spe", u), method = "knn", k = 4,
                             graph_name = "g")
  res <- compute_lisa(obj, feature1 = u$genes[1], feature2 = u$genes[2],
                      graph = "g", n_perm = 49, seed = 1)
  expect_setequal(res$spot_id, u$spots)
})

test_that("significance is inferential, not merely a quadrant label", {
  skip_if_not_implemented("build_spatial_graph", "compute_lisa")
  skip_if_not_installed("SpatialExperiment")
  u <- tf_universe()
  obj <- build_spatial_graph(tf_container("spe", u), method = "knn", k = 4,
                             graph_name = "g")
  res <- compute_lisa(obj, feature1 = u$genes[1], graph = "g", n_perm = 99, seed = 1)
  # Every spot has a quadrant, but significance is a separate p-value column;
  # p_adjusted must exist and dominate p_value (FDR across the family).
  expect_false(all(res$p_value == res$p_adjusted) && length(unique(res$p_value)) > 1)
  expect_true(all(res$p_adjusted >= res$p_value - TOL))
})

test_that("compute_lisa requires an explicit, existing graph (no Shiny string dispatch)", {
  skip_if_not_implemented("build_spatial_graph", "compute_lisa")
  skip_if_not_installed("SpatialExperiment")
  obj <- build_spatial_graph(tf_container("spe"), method = "knn", k = 4,
                             graph_name = "g")
  # Legacy Shiny type strings / empty selections must not be accepted.
  expect_error(compute_lisa(obj, feature1 = "", graph = "g"))
  expect_error(compute_lisa(obj, feature1 = tf_universe()$genes[1], graph = "missing"))
})

test_that("isolated spots get NA local statistic, quadrant and p-value", {
  skip_if_not_implemented("build_spatial_graph", "compute_lisa")
  skip_if_not_installed("SpatialExperiment")
  u <- tf_universe_with_outlier(n_spots = 12)
  obj <- build_spatial_graph(tf_container("spe", u), method = "radius",
                             radius = 2, graph_name = "g")
  res <- compute_lisa(obj, feature1 = u$genes[1], graph = "g", n_perm = 19, seed = 1)
  row <- res[res$spot_id == u$outlier, ]
  expect_true(is.na(row$lisa))
  expect_true(is.na(row$p_value))
  expect_true(is.na(row$quadrant))
})

test_that("plot_lisa consumes a LISA result and does not recompute", {
  skip_if_not_implemented("compute_lisa", "plot_lisa")
  skip_if_not_installed("SpatialExperiment")
  skip_if_not_installed("ggplot2")
  u <- tf_universe()
  obj <- build_spatial_graph(tf_container("spe", u), method = "knn", k = 4,
                             graph_name = "g")
  res <- compute_lisa(obj, feature1 = u$genes[1], graph = "g", n_perm = 19, seed = 1)
  # plot_lisa takes the computed result (+ coords), returns a ggplot.
  p <- plot_lisa(obj, res)
  expect_s3_class(p, "ggplot")
})
