# Optional histology rendering (FIX_GUIDE s1): image adapters, scale-factor
# alignment, top-left orientation, cropping, image_scale, alpha, multi-image
# composition, and the coordinate-only fallback. The SPE image path is exercised
# end-to-end (imgData is cheaply constructible); the Seurat raster path is
# covered for its NULL/fallback behaviour on image-free FOV objects.

# TRUE when the plot carries a reversed continuous y scale.
hist_reverse_y <- function(p) {
  any(vapply(p$scales$scales, function(s) {
    if (!("y" %in% s$aesthetics)) return(FALSE)
    tr <- s$transformation %||% s$trans
    !is.null(tr) && identical(tr$name, "reverse")
  }, logical(1)))
}
geom_classes <- function(p) vapply(p$layers, function(l) class(l$geom)[1],
                                   character(1))

# An SPE with a histology raster in imgData: top half red, bottom half blue, so
# vertical orientation is detectable. Coordinates are full-resolution; the low/
# hires scale factors map them into the raster's pixel space.
spe_with_image <- function(scale_lowres = 0.1, scale_hires = 0.3,
                           hires = FALSE, h = 20L, w = 8L) {
  ns <- 3L
  cnt <- matrix(seq_len(3L * ns), 3L, ns,
                dimnames = list(paste0("g", 1:3), paste0("s", seq_len(ns))))
  coords <- cbind(x = c(20, 40, 60), y = c(0, 50, 100))
  rownames(coords) <- colnames(cnt)
  cols <- matrix("#0000FF", h, w); cols[seq_len(h / 2L), ] <- "#FF0000"
  spi <- SpatialExperiment::SpatialImage(grDevices::as.raster(cols))
  spe <- SpatialExperiment::SpatialExperiment(
    assays = list(counts = cnt, logcounts = cnt), spatialCoords = coords,
    sample_id = rep("img1", ns))
  rows <- S4Vectors::DataFrame(sample_id = "img1", image_id = "lowres",
                               data = I(list(spi)), scaleFactor = scale_lowres)
  if (hires) {
    spi2 <- SpatialExperiment::SpatialImage(grDevices::as.raster(
      matrix("#00FF00", h * 2L, w * 2L)))
    rows <- rbind(rows, S4Vectors::DataFrame(
      sample_id = "img1", image_id = "hires", data = I(list(spi2)),
      scaleFactor = scale_hires))
  }
  SpatialExperiment::imgData(spe) <- rows
  spe
}

spe_two_images <- function() {
  ns <- 4L
  cnt <- matrix(seq_len(3L * ns), 3L, ns,
                dimnames = list(paste0("g", 1:3), paste0("s", seq_len(ns))))
  coords <- cbind(x = c(10, 20, 10, 20), y = c(0, 50, 0, 50))
  rownames(coords) <- colnames(cnt)
  spe <- SpatialExperiment::SpatialExperiment(
    assays = list(counts = cnt, logcounts = cnt), spatialCoords = coords,
    sample_id = c("img1", "img1", "img2", "img2"))
  mk <- function() SpatialExperiment::SpatialImage(
    grDevices::as.raster(matrix("#888888", 10L, 6L)))
  SpatialExperiment::imgData(spe) <- S4Vectors::DataFrame(
    sample_id = c("img1", "img2"), image_id = c("lowres", "lowres"),
    data = I(list(mk(), mk())), scaleFactor = c(0.1, 0.1))
  spe
}

# ---- adapters ---------------------------------------------------------------

test_that("SPE adapters expose the raster + scale factor, NULL when image-free", {
  skip_if_not_implemented(".get_spatial_image", ".get_spatial_scale_factor")
  skip_if_not_installed("SpatialExperiment")
  spe <- spe_with_image()
  expect_equal(mfn(".get_spatial_scale_factor")(spe, "img1", "lowres"), 0.1)
  r <- mfn(".get_spatial_image")(spe, "img1", "lowres")
  expect_s3_class(r, "raster")
  expect_equal(dim(r), c(20L, 8L))

  # An image-free object returns NULL from both adapters (fallback path).
  u <- tf_universe(); bare <- tf_spe(u)
  expect_null(mfn(".get_spatial_scale_factor")(bare, u$images[1], "lowres"))
  expect_null(mfn(".get_spatial_image")(bare, u$images[1], "lowres"))
})

test_that("an image-free Seurat FOV has no scale factor, so histology falls back", {
  skip_if_not_implemented(".get_spatial_scale_factor", "plot_spatial")
  skip_if_not_installed("Seurat")
  u <- tf_universe(); obj <- tf_container("seurat", u)
  # A centroids FOV carries no spatial scale factor -- the operative gate for
  # histology rendering -- even though GetImage() may synthesize a placeholder.
  expect_null(mfn(".get_spatial_scale_factor")(obj, u$images[1], "lowres"))
  # So image = TRUE cannot render a real histology overlay and errors clearly,
  # while the default coordinate-only path still works.
  expect_error(plot_spatial(obj, feature = u$genes[1], image = TRUE),
               "no histology raster")
  expect_false("GeomRasterAnn" %in%
                 geom_classes(plot_spatial(obj, feature = u$genes[1])))
})

test_that("hires image_scale selects the high-resolution image", {
  skip_if_not_implemented(".get_spatial_scale_factor")
  skip_if_not_installed("SpatialExperiment")
  spe <- spe_with_image(hires = TRUE)
  expect_equal(mfn(".get_spatial_scale_factor")(spe, "img1", "hires"), 0.3)
  expect_equal(dim(mfn(".get_spatial_image")(spe, "img1", "hires")), c(40L, 16L))
})

# ---- plotting: overlay, orientation, scale ----------------------------------

test_that("plot_spatial(image=TRUE) overlays a scaled, top-left-oriented raster", {
  skip_if_not_implemented("plot_spatial")
  skip_if_not_installed("SpatialExperiment")
  skip_if_not_installed("ggplot2")
  spe <- spe_with_image()
  p <- plot_spatial(spe, feature = "g1", image = TRUE)
  expect_s3_class(p, "ggplot")
  expect_true("GeomRasterAnn" %in% geom_classes(p))   # histology layer present
  expect_true(hist_reverse_y(p))                       # top-left origin

  b <- ggplot2::ggplot_build(p)
  pts <- b$data[[which(geom_classes(p) == "GeomPoint")]]
  # Coordinates scaled into raster pixel space: x = c(20,40,60) * 0.1.
  expect_setequal(round(sort(pts$x), 3), c(2, 4, 6))
  # The spot with the smallest pixel-y (image top) sits at the top of the panel.
  expect_equal(which.max(pts$y), which.min(b$plot$data$y))
})

test_that("crop zooms to the spot bounding box; no crop shows the full raster", {
  skip_if_not_implemented("plot_spatial")
  skip_if_not_installed("SpatialExperiment")
  skip_if_not_installed("ggplot2")
  spe <- spe_with_image()
  fr <- ggplot2::ggplot_build(
    plot_spatial(spe, "g1", image = TRUE, crop = FALSE))$layout$panel_params[[1]]$x.range
  cr <- ggplot2::ggplot_build(
    plot_spatial(spe, "g1", image = TRUE, crop = TRUE))$layout$panel_params[[1]]$x.range
  expect_equal(round(fr), c(0, 8))                     # full raster width
  expect_true(cr[1] >= fr[1] && cr[2] <= fr[2])
  expect_lt(diff(cr), diff(fr))                        # genuinely tighter
})

test_that("image=TRUE without a raster errors; image=FALSE stays coordinate-only", {
  skip_if_not_implemented("plot_spatial")
  skip_if_not_installed("SpatialExperiment")
  u <- tf_universe(); bare <- tf_spe(u)
  expect_error(plot_spatial(bare, feature = u$genes[1], image = TRUE),
               "no histology raster")
  p <- plot_spatial(bare, feature = u$genes[1])        # default path
  expect_false("GeomRasterAnn" %in% geom_classes(p))
  expect_false(hist_reverse_y(p))                      # plain x/y is Cartesian
  expect_true(hist_reverse_y(plot_spatial(bare, feature = u$genes[1],
                                          flip_y = TRUE)))
})

test_that("multiple histology images compose into one patchwork", {
  skip_if_not_implemented("plot_spatial")
  skip_if_not_installed("SpatialExperiment")
  skip_if_not_installed("patchwork")
  skip_if_not_installed("ggplot2")
  spe <- spe_two_images()
  p <- plot_spatial(spe, feature = "g1", image = TRUE)
  expect_s3_class(p, "patchwork")
  # Restricting to one image_id yields a single ggplot panel.
  one <- plot_spatial(spe, feature = "g1", image = TRUE, image_id = "img1")
  expect_s3_class(one, "ggplot")
  expect_false(methods::is(one, "patchwork"))
})

# ---- validation + helpers ---------------------------------------------------

test_that("image parameters are validated", {
  skip_if_not_implemented("plot_spatial")
  skip_if_not_installed("SpatialExperiment")
  spe <- spe_with_image()
  expect_error(plot_spatial(spe, "g1", image = "yes"), "`image`")
  expect_error(plot_spatial(spe, "g1", image = TRUE, image_alpha = 2), "image_alpha")
  expect_error(plot_spatial(spe, "g1", image = TRUE, crop = NA), "`crop`")
  expect_error(plot_spatial(spe, "g1", image = TRUE, image_scale = "medium"))
})

test_that(".apply_raster_alpha scales opacity for #RRGGBB, named, and pre-alpha colors", {
  skip_if_not_implemented(".apply_raster_alpha")
  aa <- mfn(".apply_raster_alpha")
  cell <- function(r) as.matrix(r)[1, 1]
  # Plain #RRGGBB: 0.5 * 255 = 128 = 0x80.
  expect_match(cell(aa(grDevices::as.raster(matrix("#00FF00", 1, 1)), 0.5)),
               "^#00FF0080$", ignore.case = TRUE)
  # Named color is converted, not passed through unchanged.
  expect_match(cell(aa(grDevices::as.raster(matrix("red", 1, 1)), 0.5)),
               "^#FF000080$", ignore.case = TRUE)
  # Existing alpha is MULTIPLIED: 128 * 0.5 = 64 = 0x40.
  expect_match(cell(aa(grDevices::as.raster(matrix("#FF000080", 1, 1)), 0.5)),
               "^#FF000040$", ignore.case = TRUE)
  # A fully-transparent pixel stays transparent.
  expect_match(cell(aa(grDevices::as.raster(matrix("#FF000000", 1, 1)), 0.5)),
               "^#FF000000$", ignore.case = TRUE)
  # Full opacity is a no-op.
  r <- grDevices::as.raster(matrix("#00FF00", 1, 1))
  expect_identical(aa(r, 1), r)
})

test_that(".valid_scale_factor accepts only a single finite, strictly positive value", {
  skip_if_not_implemented(".valid_scale_factor")
  v <- mfn(".valid_scale_factor")
  expect_true(v(0.5))
  expect_true(v(1L))
  expect_false(v(0))
  expect_false(v(-1))
  expect_false(v(NA_real_))
  expect_false(v(Inf))
  expect_false(v(c(0.1, 0.2)))
  expect_false(v(NULL))
  # Non-numeric scalars must be rejected cleanly (no coercion/error/warning):
  expect_false(v(TRUE))                 # logical is not a scale factor
  expect_false(v(list(1)))              # would otherwise error in is.finite()
  expect_false(v(factor("1")))          # would otherwise warn / return NA
  expect_false(v("0.5"))                # character
})

test_that("a non-positive SPE scale factor is rejected (NULL, so histology errors)", {
  skip_if_not_implemented(".get_spatial_scale_factor")
  skip_if_not_installed("SpatialExperiment")
  expect_null(mfn(".get_spatial_scale_factor")(
    spe_with_image(scale_lowres = 0), "img1", "lowres"))
  expect_null(mfn(".get_spatial_scale_factor")(
    spe_with_image(scale_lowres = -0.1), "img1", "lowres"))
  expect_error(plot_spatial(spe_with_image(scale_lowres = 0), "g1", image = TRUE),
               "no histology raster")
})

test_that("Seurat histology path renders via mocked GetImage/ScaleFactors", {
  skip_if_not_implemented(".get_spatial_image", "plot_spatial")
  skip_if_not_installed("Seurat")
  skip_if_not_installed("ggplot2")
  u <- tf_universe(); obj <- tf_container("seurat", u); im <- u$images[1]
  ras <- grDevices::as.raster(matrix("#FF0000", 12L, 9L))
  # The adapter is class-agnostic (same GetImage/ScaleFactors generics back
  # VisiumV1 and VisiumV2), so mocking them exercises the positive Seurat path.
  local_mocked_bindings(
    ScaleFactors = function(object, ...)
      list(spot = 1, fiducial = 1, hires = 0.2, lowres = 0.05),
    .package = "Seurat")
  local_mocked_bindings(
    GetImage = function(object, mode = "grob", ...) ras,
    .package = "SeuratObject")

  expect_equal(mfn(".get_spatial_scale_factor")(obj, im, "lowres"), 0.05)
  expect_s3_class(mfn(".get_spatial_image")(obj, im, "lowres"), "raster")

  p <- plot_spatial(obj, feature = u$genes[1], image = TRUE, image_id = im)
  expect_true("GeomRasterAnn" %in% geom_classes(p))
  expect_false(hist_reverse_y(p))                      # factory image is an FOV
  expect_true(hist_reverse_y(plot_spatial(
    obj, feature = u$genes[1], image = TRUE, image_id = im, flip_y = TRUE)))
  b <- ggplot2::ggplot_build(p)
  pts <- b$data[[which(geom_classes(p) == "GeomPoint")]]
  coords <- mfn(".get_coordinates")(obj, image_id = im)
  # Coordinates scaled into raster space by the mocked lowres factor.
  expect_equal(sort(round(pts$x, 6)),
               sort(round(unname(coords[, "x"]) * 0.05, 6)))
})
