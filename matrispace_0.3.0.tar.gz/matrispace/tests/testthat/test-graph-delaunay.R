# Delaunay spatial graphs (SPATIAL_EXTENSIONS_IMPLEMENTATION_SPEC s3). A third
# base-graph method built on geometry::delaunayn (Qhull): symmetric, sparse,
# reorder-safe, image/partition-blocked, with optional absolute max-edge pruning
# and deterministic, actionable degeneracy errors.

# Build a Delaunay-friendly SPE from explicit coords (>= 3 non-collinear points
# per block), optionally with an image and within-image partition column.
del_spe <- function(coords, image_ids = rep("img1", nrow(coords)),
                    region = NULL) {
  spe <- tf_spe_from_coords(coords, image_ids = image_ids,
                            replicate_ids = rep("r", nrow(coords)))
  if (!is.null(region)) SummarizedExperiment::colData(spe)$region <- region
  spe
}

# Undirected edge set (as "min-max" keys) from a connectivity matrix.
edge_keys <- function(C) {
  C <- as.matrix(C); ij <- which(C != 0 & upper.tri(C), arr.ind = TRUE)
  sort(paste(rownames(C)[ij[, 1]], colnames(C)[ij[, 2]], sep = "--"))
}

# Direct geometry::delaunayn oracle (package-default options) -> undirected edge
# keys over the spot ids.
oracle_edges <- function(coords) {
  tri <- geometry::delaunayn(coords)
  ee <- rbind(tri[, c(1, 2)], tri[, c(1, 3)], tri[, c(2, 3)])
  a <- pmin(ee[, 1], ee[, 2]); b <- pmax(ee[, 1], ee[, 2])
  u <- unique(cbind(a, b))
  sort(paste(rownames(coords)[u[, 1]], rownames(coords)[u[, 2]], sep = "--"))
}

# ---- fixed hand-built edge set ----------------------------------------------

test_that("delaunay of a triangle + interior point yields the exact expected edges", {
  skip_if_not_implemented("build_spatial_graph", "get_matrispace_graph")
  skip_if_not_installed("SpatialExperiment")
  skip_if_not_installed("geometry")
  # Outer triangle A,B,C with interior point P: Delaunay subdivides into PAB, PBC,
  # PCA, so P connects to all three vertices and the three hull edges are present
  # (all 6 pairs among the 4 points).
  coords <- rbind(A = c(0, 0), B = c(6, 0), C = c(3, 6), P = c(3, 2))
  colnames(coords) <- c("x", "y")
  g <- get_matrispace_graph(
    build_spatial_graph(del_spe(coords), method = "delaunay", graph_name = "d"), "d")
  expect_setequal(edge_keys(g$connectivities),
                  c("A--B", "A--C", "B--C", "A--P", "B--P", "C--P"))
  expect_equal(g$method, "delaunay")
  expect_true(Matrix::isSymmetric(g$connectivities))
  expect_true(all(g$distances@x > 0))                 # distinct points
})

# ---- agreement with a direct delaunayn oracle -------------------------------

test_that("connectivity + distances match a direct delaunayn oracle (non-complete)", {
  skip_if_not_implemented("build_spatial_graph", "get_matrispace_graph")
  skip_if_not_installed("SpatialExperiment")
  skip_if_not_installed("geometry")
  coords <- rbind(s1 = c(0, 0), s2 = c(4, 0), s3 = c(8, 1), s4 = c(1, 5),
                  s5 = c(5, 5), s6 = c(9, 6))
  colnames(coords) <- c("x", "y")
  g <- get_matrispace_graph(
    build_spatial_graph(del_spe(coords), method = "delaunay", graph_name = "d"), "d")
  expect_equal(edge_keys(g$connectivities), oracle_edges(coords))
  # Genuinely sparse: not a complete graph, and within the planar bound 3n-6.
  n <- nrow(coords)
  expect_lt(length(g$distances@x) / 2, n * (n - 1) / 2)
  expect_lte(length(g$distances@x) / 2, 3 * n - 6)
  # Stored edge lengths equal the Euclidean coordinate distances.
  ij <- which(as.matrix(g$connectivities) != 0, arr.ind = TRUE)
  d <- sqrt(rowSums((coords[ij[, 1], ] - coords[ij[, 2], ])^2))
  expect_equal(as.matrix(g$distances)[ij], unname(d), tolerance = 1e-9)
})

# ---- reorder invariance + sparsity ------------------------------------------

test_that("delaunay is invariant to host spot ordering", {
  skip_if_not_implemented("build_spatial_graph", "get_matrispace_graph")
  skip_if_not_installed("SpatialExperiment")
  skip_if_not_installed("geometry")
  coords <- rbind(s1 = c(0, 0), s2 = c(4, 0), s3 = c(8, 1), s4 = c(1, 5),
                  s5 = c(5, 5), s6 = c(9, 6))
  colnames(coords) <- c("x", "y")
  spe <- del_spe(coords)
  g1 <- get_matrispace_graph(
    build_spatial_graph(spe, method = "delaunay", graph_name = "d"), "d")
  perm <- c(4, 1, 6, 2, 5, 3)
  g2 <- get_matrispace_graph(
    build_spatial_graph(spe[, perm], method = "delaunay", graph_name = "d"), "d")
  C1 <- as.matrix(g1$connectivities)
  C2 <- as.matrix(g2$connectivities)[rownames(C1), colnames(C1)]
  expect_equal(C1, C2)
})

test_that("delaunay output is a sparse CsparseMatrix within the planar edge bound", {
  skip_if_not_implemented("build_spatial_graph", "get_matrispace_graph")
  skip_if_not_installed("SpatialExperiment")
  skip_if_not_installed("geometry")
  set_coords <- cbind(x = (seq_len(40) * 2) %% 13 + (seq_len(40) %% 3) * 0.37,
                      y = seq_len(40) * 0.53 + (seq_len(40) %% 5) * 0.29)
  rownames(set_coords) <- sprintf("s%02d", seq_len(40))
  g <- get_matrispace_graph(
    build_spatial_graph(del_spe(set_coords), method = "delaunay", graph_name = "d"), "d")
  expect_s4_class(g$connectivities, "CsparseMatrix")
  expect_lte(length(g$distances@x) / 2, 3 * 40 - 6)   # planar Delaunay bound
})

test_that("delaunay construction never allocates a condensed/full distance matrix", {
  # Mirrors the kNN Rprofmem guard (spec s3.4): output sparsity alone does not
  # prove the build avoided a dense/condensed dist(); target the condensed size.
  skip_if_not_implemented("build_spatial_graph")
  skip_if_not_installed("SpatialExperiment")
  skip_if_not_installed("geometry")
  skip_if(!capabilities("profmem"),
          "this R was built without memory profiling (Rprofmem unavailable)")
  n <- 1000L
  set.seed(7)
  coords <- cbind(x = runif(n, 0, 100), y = runif(n, 0, 100))   # generic position
  rownames(coords) <- sprintf("s%04d", seq_len(n)); colnames(coords) <- c("x", "y")
  obj <- del_spe(coords)
  threshold <- floor(0.9 * n * (n - 1) / 2 * 8)                 # condensed dist size
  tf <- tempfile(fileext = ".out"); on.exit(unlink(tf), add = TRUE)
  utils::Rprofmem(tf, threshold = threshold)
  build_spatial_graph(obj, method = "delaunay", graph_name = "d")
  utils::Rprofmem(NULL)
  lines <- if (file.exists(tf)) readLines(tf, warn = FALSE) else character(0)
  nums <- suppressWarnings(as.numeric(sub("^([0-9]+).*$", "\\1", lines)))
  expect_length(lines[!is.na(nums) & nums >= threshold], 0)
})

test_that("delaunay provenance is structurally validated (engine + version)", {
  skip_if_not_implemented("build_spatial_graph", "get_matrispace_graph",
                          ".validate_matrispace_graph")
  skip_if_not_installed("SpatialExperiment")
  skip_if_not_installed("geometry")
  coords <- rbind(A = c(0, 0), B = c(4, 0), C = c(2, 4), P = c(2, 1))
  colnames(coords) <- c("x", "y")
  g <- get_matrispace_graph(
    build_spatial_graph(del_spe(coords), method = "delaunay", graph_name = "d"), "d")
  expect_equal(g$parameters$engine, "geometry::delaunayn")
  expect_true(nzchar(g$parameters$engine_version))
  validate <- mfn(".validate_matrispace_graph")
  bad_engine <- g; bad_engine$parameters$engine <- ""
  expect_error(validate(bad_engine), "engine must be")
  bad_engine2 <- g; bad_engine2$parameters$engine <- 1
  expect_error(validate(bad_engine2), "engine must be")
  bad_ver <- g; bad_ver$parameters$engine_version <- ""
  expect_error(validate(bad_ver), "engine_version")
  bad_ver2 <- g; bad_ver2$parameters$engine_version <- c("1", "2")
  expect_error(validate(bad_ver2), "engine_version")
})

# ---- image / partition blocking ---------------------------------------------

test_that("delaunay never joins spots across images (overlapping local frames)", {
  skip_if_not_implemented("build_spatial_graph", "get_matrispace_graph")
  skip_if_not_installed("SpatialExperiment")
  skip_if_not_installed("geometry")
  # Two images share an identical local frame; only within-image edges may exist.
  one <- rbind(c(0, 0), c(4, 0), c(2, 4), c(2, 1))
  coords <- rbind(one, one)
  rownames(coords) <- c(paste0("a", 1:4), paste0("b", 1:4))
  colnames(coords) <- c("x", "y")
  images <- c(rep("i1", 4), rep("i2", 4))
  g <- get_matrispace_graph(
    build_spatial_graph(del_spe(coords, image_ids = images),
                        method = "delaunay", graph_name = "d"), "d")
  img <- stats::setNames(images, rownames(coords))
  ij <- which(as.matrix(g$connectivities) != 0, arr.ind = TRUE)
  expect_true(all(img[rownames(coords)[ij[, 1]]] == img[rownames(coords)[ij[, 2]]]))
  expect_true(Matrix::isSymmetric(g$connectivities))
})

test_that("delaunay respects an optional within-image partition", {
  skip_if_not_implemented("build_spatial_graph", "get_matrispace_graph")
  skip_if_not_installed("SpatialExperiment")
  skip_if_not_installed("geometry")
  coords <- rbind(c(0, 0), c(1, 0), c(0, 1),      # region P
                  c(10, 10), c(11, 10), c(10, 11)) # region Q (same image)
  rownames(coords) <- paste0("s", 1:6); colnames(coords) <- c("x", "y")
  region <- c("P", "P", "P", "Q", "Q", "Q")
  spe <- del_spe(coords, region = region)
  g <- get_matrispace_graph(
    build_spatial_graph(spe, method = "delaunay", graph_name = "d",
                        partition_within_image = "region"), "d")
  part <- stats::setNames(region, rownames(coords))
  ij <- which(as.matrix(g$connectivities) != 0, arr.ind = TRUE)
  expect_true(all(part[rownames(coords)[ij[, 1]]] == part[rownames(coords)[ij[, 2]]]))
})

# ---- pruning ----------------------------------------------------------------

test_that("max_edge_distance prunes long edges and may create isolates", {
  skip_if_not_implemented("build_spatial_graph", "get_matrispace_graph")
  skip_if_not_installed("SpatialExperiment")
  skip_if_not_installed("geometry")
  # A tight triangle plus a far outlier; pruning drops the long outlier edges.
  coords <- rbind(A = c(0, 0), B = c(1, 0), C = c(0, 1), F = c(50, 50))
  colnames(coords) <- c("x", "y")
  spe <- del_spe(coords)
  full <- get_matrispace_graph(
    build_spatial_graph(spe, method = "delaunay", graph_name = "d"), "d")
  pruned <- get_matrispace_graph(
    build_spatial_graph(spe, method = "delaunay", graph_name = "d",
                        max_edge_distance = 2), "d")
  expect_lt(length(pruned$distances@x), length(full$distances@x))
  expect_lte(max(pruned$distances@x), 2)
  expect_equal(pruned$parameters$max_edge_distance, 2)
  # The outlier F is isolated after pruning (all-zero row), still retained.
  expect_equal(unname(Matrix::rowSums(pruned$connectivities)["F"]), 0)
  expect_true("F" %in% pruned$spot_ids)
})

# ---- degeneracy + argument errors -------------------------------------------

test_that("duplicated coordinates error and name the conflicting spots", {
  skip_if_not_implemented("build_spatial_graph")
  skip_if_not_installed("SpatialExperiment")
  skip_if_not_installed("geometry")
  coords <- rbind(s1 = c(0, 0), s2 = c(1, 0), s3 = c(0, 0), s4 = c(2, 2))
  colnames(coords) <- c("x", "y")
  expect_error(
    build_spatial_graph(del_spe(coords), method = "delaunay", graph_name = "d"),
    "distinct coordinates.*s1.*s3")
})

test_that("fewer-than-three and collinear blocks error deterministically", {
  skip_if_not_implemented("build_spatial_graph")
  skip_if_not_installed("SpatialExperiment")
  skip_if_not_installed("geometry")
  two <- rbind(s1 = c(0, 0), s2 = c(1, 1)); colnames(two) <- c("x", "y")
  expect_error(
    build_spatial_graph(del_spe(two), method = "delaunay", graph_name = "d"),
    "at least 3")
  line <- rbind(s1 = c(0, 0), s2 = c(1, 1), s3 = c(2, 2), s4 = c(3, 3))
  colnames(line) <- c("x", "y")
  expect_error(
    build_spatial_graph(del_spe(line), method = "delaunay", graph_name = "d"),
    "collinear")
})

test_that("delaunay rejects k, radius, directed, symmetrize, and misplaced pruning", {
  skip_if_not_implemented("build_spatial_graph")
  skip_if_not_installed("SpatialExperiment")
  skip_if_not_installed("geometry")
  coords <- rbind(A = c(0, 0), B = c(4, 0), C = c(2, 4), P = c(2, 1))
  colnames(coords) <- c("x", "y")
  spe <- del_spe(coords)
  expect_error(build_spatial_graph(spe, method = "delaunay", k = 4, graph_name = "d"),
               "do not use `k`")
  expect_error(build_spatial_graph(spe, method = "delaunay", radius = 3, graph_name = "d"),
               "do not use `radius`")
  expect_error(build_spatial_graph(spe, method = "delaunay", directed = TRUE,
                                   graph_name = "d"), "undirected")
  expect_error(build_spatial_graph(spe, method = "delaunay", symmetrize = "mutual",
                                   graph_name = "d"), "symmetrization")
  expect_error(build_spatial_graph(spe, method = "delaunay", max_edge_distance = -1,
                                   graph_name = "d"), "max_edge_distance")
  # max_edge_distance is invalid for the other methods.
  expect_error(build_spatial_graph(spe, method = "knn", k = 2, graph_name = "d",
                                   max_edge_distance = 3),
               "only valid for method = 'delaunay'")
})

# ---- staleness + coexistence ------------------------------------------------

test_that("a delaunay graph goes stale when coordinates change", {
  skip_if_not_implemented("build_spatial_graph", ".validate_graph_against")
  skip_if_not_installed("SpatialExperiment")
  skip_if_not_installed("geometry")
  coords <- rbind(A = c(0, 0), B = c(4, 0), C = c(2, 4), P = c(2, 1))
  colnames(coords) <- c("x", "y")
  spe <- del_spe(coords)
  obj <- build_spatial_graph(spe, method = "delaunay", graph_name = "d")
  g <- get_matrispace_graph(obj, "d")
  moved <- spe
  SpatialExperiment::spatialCoords(moved)[1, 1] <-
    SpatialExperiment::spatialCoords(moved)[1, 1] + 5
  expect_error(mfn(".validate_graph_against")(g, moved), "stale")
})

test_that("delaunay coexists with knn and radius graphs in the registry", {
  skip_if_not_implemented("build_spatial_graph", "matrispace_graphs")
  skip_if_not_installed("SpatialExperiment")
  skip_if_not_installed("geometry")
  coords <- rbind(A = c(0, 0), B = c(4, 0), C = c(2, 4), P = c(2, 1), Q = c(3, 2))
  colnames(coords) <- c("x", "y")
  spe <- del_spe(coords)
  obj <- build_spatial_graph(spe, method = "knn", k = 2, graph_name = "gk")
  obj <- build_spatial_graph(obj, method = "radius", radius = 3, graph_name = "gr")
  obj <- build_spatial_graph(obj, method = "delaunay", graph_name = "gd")
  expect_setequal(matrispace_graphs(obj), c("gk", "gr", "gd"))
  expect_equal(get_matrispace_graph(obj, "gd")$method, "delaunay")
  expect_equal(get_matrispace_graph(obj, "gk")$method, "knn")
})

# ---- multi-image smoke (automated stand-in for the real VisiumV2 audit) -----

test_that("delaunay multi-image smoke: symmetric, blocked, finite positive lengths", {
  skip_if_not_implemented("build_spatial_graph", "get_matrispace_graph")
  skip_if_not_installed("SpatialExperiment")
  skip_if_not_installed("geometry")
  set.seed(1)
  mk <- function(off) {
    m <- cbind(x = runif(30, 0, 20) + off, y = runif(30, 0, 20))
    m
  }
  coords <- rbind(mk(0), mk(100))
  rownames(coords) <- sprintf("s%03d", seq_len(60)); colnames(coords) <- c("x", "y")
  images <- c(rep("v1", 30), rep("v2", 30))
  g <- get_matrispace_graph(
    build_spatial_graph(del_spe(coords, image_ids = images),
                        method = "delaunay", graph_name = "d"), "d")
  expect_true(Matrix::isSymmetric(g$connectivities))
  expect_true(all(is.finite(g$distances@x)) && all(g$distances@x > 0))
  img <- stats::setNames(images, rownames(coords))
  ij <- which(as.matrix(g$connectivities) != 0, arr.ind = TRUE)
  expect_true(all(img[rownames(coords)[ij[, 1]]] == img[rownames(coords)[ij[, 2]]]))
})
