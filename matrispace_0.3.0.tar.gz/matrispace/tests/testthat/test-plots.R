# Visualization (SPEC s11). Every plot_* returns a composable ggplot and is a
# PURE consumer: it reads stored results / explicit inputs through the accessor
# contract only and NEVER mutates the container, registry, metadata, assays, the
# RNG, or a graphics device. plot_lisa() consumes a supplied compute_lisa()
# result and never recomputes. Plots are image-aware (facet by image_id).

# ---- helpers ---------------------------------------------------------------

# The variable a mapping points at (e.g. "value"), container/version-independent.
map_var <- function(p, aesthetic) {
  m <- p$mapping[[aesthetic]]
  if (is.null(m)) return(NA_character_)
  lab <- rlang::as_label(m)                          # e.g. `.data[["value"]]`
  sub('^\\.data\\[\\["(.*)"\\]\\]$', "\\1", lab)     # -> "value"
}
plot_label <- function(p, aesthetic) {
  labs <- ggplot2::get_labs(p)
  labs[[aesthetic]] %||% NA_character_
}
n_scales <- function(p) length(p$scales$scales)

# ---- return class + required mappings/scales -------------------------------

test_that("plot_spatial returns a ggplot with x/y/colour mappings and a colour scale", {
  skip_if_not_implemented("plot_spatial")
  skip_if_not_installed("SpatialExperiment")
  skip_if_not_installed("ggplot2")
  u <- tf_universe()
  obj <- tf_container("spe", u)
  p <- plot_spatial(obj, feature = u$genes[1])
  expect_s3_class(p, "ggplot")
  expect_setequal(intersect(c("x", "y", "colour"), names(p$mapping)),
                  c("x", "y", "colour"))
  expect_equal(map_var(p, "x"), "x")
  expect_equal(map_var(p, "y"), "y")
  expect_gte(n_scales(p), 1)                       # an explicit colour scale
  expect_equal(plot_label(p, "colour"), u$genes[1])
})

test_that("plot_dotplot maps group/feature/size/colour and plot_violin fills by group", {
  skip_if_not_implemented("plot_dotplot")
  skip_if_not_installed("SpatialExperiment")
  skip_if_not_installed("ggplot2")
  u <- tf_universe()
  obj <- tf_container("spe", u)
  d <- plot_dotplot(obj, features = u$genes[1:3], group_by = "group")
  expect_s3_class(d, "ggplot")
  expect_true(all(c("x", "y", "size", "colour") %in% names(d$mapping)))
  v <- plot_violin(obj, feature = u$genes[1], group_by = "group")
  expect_s3_class(v, "ggplot")
  expect_equal(map_var(v, "fill"), "group")
})

# ---- multi-image faceting + local coordinate orientation -------------------

test_that("plot_spatial facets overlapping images and preserves local coordinates", {
  skip_if_not_implemented("plot_spatial")
  skip_if_not_installed("SpatialExperiment")
  skip_if_not_installed("ggplot2")
  # Two images share an OVERLAPPING local frame (factory design); faceting keeps
  # them apart and each panel keeps its own coordinates (no global rescale).
  u <- tf_universe(n_images = 2L, n_spots = 24)
  obj <- tf_container("spe", u)
  p <- plot_spatial(obj, feature = u$genes[1])
  expect_s3_class(p$facet, "FacetWrap")
  built <- ggplot2::ggplot_build(p)$plot$data
  coords <- mfn(".get_coordinates")(obj)
  ord <- match(built$spot_id, rownames(coords))
  expect_equal(built$x, unname(coords[ord, "x"]), tolerance = TOL_COORD)
  expect_equal(built$y, unname(coords[ord, "y"]), tolerance = TOL_COORD)
  # coord_fixed keeps spatial aspect honest (equal x/y units).
  expect_equal(p$coordinates$ratio, 1)
})

test_that("plot_spatial with a single image is not faceted", {
  skip_if_not_implemented("plot_spatial")
  skip_if_not_installed("SpatialExperiment")
  skip_if_not_installed("ggplot2")
  u <- tf_universe(n_images = 1L)
  p <- plot_spatial(tf_container("spe", u), feature = u$genes[1])
  expect_s3_class(p$facet, "FacetNull")
})

# ---- NA behavior + stable named palettes -----------------------------------

test_that("plot_spatial retains (does not silently drop) spots with NA feature values", {
  skip_if_not_implemented("plot_spatial")
  skip_if_not_installed("SpatialExperiment")
  skip_if_not_installed("ggplot2")
  u <- tf_universe()
  u$metadata$partial <- c(NA_real_, tail(seq_len(nrow(u$metadata)), -1))
  obj <- tf_container("spe", u)
  p <- plot_spatial(obj, feature = "partial")
  built <- ggplot2::ggplot_build(p)$plot$data
  expect_equal(nrow(built), length(u$spots))       # NA spot kept, not filtered
  expect_true(anyNA(built$value))
})

test_that("palettes are stable, named, and valid colors", {
  skip_if_not_implemented("palette_ecm_niche")
  for (pal in list(palette_ecm_niche(), palette_matrisome_category(),
                   palette_annotation())) {
    expect_type(pal, "character")
    expect_false(is.null(names(pal)))
    expect_true(all(nzchar(names(pal))))
    expect_identical(anyDuplicated(names(pal)), 0L)
    expect_error(grDevices::col2rgb(pal), NA)        # every entry is a valid color
  }
  expect_identical(palette_ecm_niche(), palette_ecm_niche())  # deterministic
})

# ---- purity: no registry/metadata/assay/RNG/graphics-device mutation --------

test_that("plot_* do not mutate the container", {
  skip_if_not_implemented("plot_spatial")
  skip_if_not_installed("SpatialExperiment")
  skip_if_not_installed("ggplot2")
  u <- tf_universe()
  obj <- tf_container("spe", u)
  snapshot <- obj
  plot_spatial(obj, feature = u$genes[1])
  plot_blend(obj, u$genes[1], u$genes[2])
  plot_dotplot(obj, u$genes[1:3], group_by = "group")
  plot_violin(obj, u$genes[1], group_by = "group")
  expect_equal(obj, snapshot)                        # bit-for-bit unchanged
})

test_that("plot_* do not advance the RNG or open a graphics device", {
  skip_if_not_implemented("plot_spatial")
  skip_if_not_installed("SpatialExperiment")
  skip_if_not_installed("ggplot2")
  u <- tf_universe()
  obj <- tf_container("spe", u)
  set.seed(123)
  before_seed <- .Random.seed
  before_dev <- grDevices::dev.list()
  plot_spatial(obj, feature = u$genes[1])
  plot_dotplot(obj, u$genes[1:3], group_by = "group")
  expect_identical(.Random.seed, before_seed)        # no randomness consumed
  expect_identical(grDevices::dev.list(), before_dev) # no device opened
})

# ---- plot_lisa consumes a supplied result and never recomputes --------------

test_that("plot_lisa consumes the supplied LISA result verbatim (no recomputation)", {
  skip_if_not_implemented("plot_lisa")
  skip_if_not_installed("SpatialExperiment")
  skip_if_not_installed("ggplot2")
  u <- tf_universe(n_images = 2L, n_spots = 24)
  obj <- tf_container("spe", u)                      # NOTE: no stored graph
  # Arbitrary quadrant labels NOT derivable from the data: if plot_lisa recomputed
  # it would need a graph (absent) and would not reproduce these exact labels.
  quad <- rep(c("high-high", "low-high", "low-low", "high-low"),
              length.out = length(u$spots))
  res <- data.frame(spot_id = u$spots, image_id = u$image_ids, quadrant = quad,
                    p_value = 0.01, p_adjusted = NA_real_, stringsAsFactors = FALSE)
  p <- plot_lisa(obj, res)
  expect_s3_class(p, "ggplot")
  built <- ggplot2::ggplot_build(p)$plot$data
  built <- built[match(res$spot_id, built$spot_id), ]
  expect_identical(built$quadrant, res$quadrant)     # verbatim, not recomputed
  expect_equal(map_var(p, "colour"), "quadrant")
  expect_s3_class(p$facet, "FacetWrap")              # image-aware
})

test_that("plot_lisa rejects a table missing required columns or unknown spots", {
  skip_if_not_implemented("plot_lisa")
  skip_if_not_installed("SpatialExperiment")
  skip_if_not_installed("ggplot2")
  u <- tf_universe()
  obj <- tf_container("spe", u)
  expect_error(plot_lisa(obj, data.frame(spot_id = u$spots)), "quadrant")
  bad <- data.frame(spot_id = c(u$spots, "ghost_spot"),
                    image_id = "image1", quadrant = "high-high",
                    stringsAsFactors = FALSE)
  expect_error(plot_lisa(obj, bad), "coordinates")
})

test_that("plot_lisa validates image membership, duplicates, p_value, and alpha", {
  skip_if_not_implemented("plot_lisa")
  skip_if_not_installed("SpatialExperiment")
  skip_if_not_installed("ggplot2")
  u <- tf_universe(n_images = 2L, n_spots = 24)
  obj <- tf_container("spe", u)
  good <- data.frame(spot_id = u$spots, image_id = u$image_ids,
                     quadrant = "high-high", p_value = 0.01,
                     stringsAsFactors = FALSE)
  # A spot assigned to the wrong coordinate frame is rejected (not mis-faceted).
  wrong <- good; wrong$image_id[1] <- "image_wrong"
  expect_error(plot_lisa(obj, wrong), "image_id disagrees")
  # An NA image id is a mismatch too (literal rejection contract).
  na_img <- good; na_img$image_id[1] <- NA_character_
  expect_error(plot_lisa(obj, na_img), "image_id disagrees")
  # Duplicated spot rows.
  expect_error(plot_lisa(obj, rbind(good, good[1, ])), "duplicated spot_id")
  # significance needs a p_value column and a valid alpha.
  nop <- good; nop$p_value <- NULL
  expect_error(plot_lisa(obj, nop, significance = 0.05), "p_value")
  for (bad_alpha in list(NA_real_, Inf, -0.1, 1.5)) {
    expect_error(plot_lisa(obj, good, significance = bad_alpha), "\\[0, 1\\]")
  }
  expect_s3_class(plot_lisa(obj, good, significance = 0.05), "ggplot")
})

test_that("plot_blend and plot_violin reject categorical metadata", {
  skip_if_not_implemented("plot_blend")
  skip_if_not_installed("SpatialExperiment")
  skip_if_not_installed("ggplot2")
  u <- tf_universe()
  u$metadata$fac <- factor(rep(c("x", "y"), length.out = nrow(u$metadata)))
  obj <- tf_container("spe", u)
  expect_error(plot_blend(obj, "group", u$genes[1]), "categorical")   # character
  expect_error(plot_blend(obj, u$genes[1], "fac"), "categorical")     # factor
  expect_error(plot_violin(obj, "group", group_by = "group"), "categorical")
  # Numeric metadata is fine.
  expect_s3_class(plot_violin(obj, "total_counts", group_by = "group"), "ggplot")
  # Values must be aligned by spot id, not silently NA (regression guard for
  # name-stripping during numeric coercion).
  pb <- plot_blend(obj, u$genes[1], u$genes[2])
  built <- ggplot2::ggplot_build(pb)$plot$data
  expect_false(all(is.na(built$feature1)))
  expect_false(all(is.na(built$feature2)))
})

# ---- heatmap is schema-agnostic across terminal tables ----------------------

test_that("plot_heatmap consumes DE, matrisome-pair, and matrix inputs without a fixed schema", {
  skip_if_not_implemented("plot_heatmap")
  skip_if_not_installed("ggplot2")
  # DE-style table (log2FoldChange inferred as the fill).
  de <- data.frame(feature = rep(sprintf("Gene%02d", 1:3), each = 2),
                   group = rep(c("A", "B"), 3), log2FoldChange = seq_len(6),
                   stringsAsFactors = FALSE)
  hd <- plot_heatmap(de)
  expect_s3_class(hd, "ggplot")
  expect_equal(plot_label(hd, "fill"), "log2FoldChange")
  # matrisome-pair enrichment-style table with an explicitly named value column.
  lr <- data.frame(pair_id = rep(c("p1", "p2"), each = 2),
                   label = rep(c("A", "B"), 2), activity = c(0.1, 0.2, 0.3, 0.4),
                   stringsAsFactors = FALSE)
  expect_s3_class(plot_heatmap(lr, row = "pair_id", column = "label",
                               value = "activity"), "ggplot")
  # A plain numeric matrix (features x groups).
  m <- matrix(1:6, 2, 3, dimnames = list(c("r1", "r2"), c("c1", "c2", "c3")))
  expect_s3_class(plot_heatmap(m), "ggplot")
})

test_that("plot_heatmap errors when axes/value cannot be inferred", {
  skip_if_not_implemented("plot_heatmap")
  skip_if_not_installed("ggplot2")
  expect_error(plot_heatmap(data.frame(only_one = letters[1:3])), "infer")
})

test_that("plot_heatmap infers real find_matrisome_pair_enrichment output as pair x group", {
  skip_if_not_implemented("plot_heatmap")
  skip_if_not_implemented("find_matrisome_pair_enrichment")
  skip_if_not_installed("SpatialExperiment")
  skip_if_not_installed("ggplot2")
  u <- tf_universe()
  obj <- tf_container("spe", u)
  obj <- build_spatial_graph(obj, method = "knn", k = 4, graph_name = "spatial")
  pairs <- tf_lr_pairs(u$genes)
  obj <- score_matrisome_pair_coexpression(obj, pairs, graph = "spatial", assay = "logcounts",
                           layer = NULL)
  enr <- find_matrisome_pair_enrichment(obj, group_by = "group")
  p <- plot_heatmap(enr)                              # inference only
  expect_s3_class(p, "ggplot")
  # ligand/receptor are the FIRST character columns but must NOT be chosen: the
  # semantic row is the pair and the column is the group, so no tiles overlap.
  built <- ggplot2::ggplot_build(p)$plot$data
  expect_equal(nrow(built),
               length(unique(enr$pair_id)) * length(unique(enr$group)))
  expect_equal(anyDuplicated(built[, c("row", "column")]), 0L)
  expect_equal(plot_label(p, "fill"), "mean_coexpression")
})

test_that("plot_heatmap rejects duplicate row-column cells", {
  skip_if_not_implemented("plot_heatmap")
  skip_if_not_installed("ggplot2")
  dup <- data.frame(feature = c("G1", "G1"), group = c("A", "A"),
                    value = c(1, 2), stringsAsFactors = FALSE)
  expect_error(plot_heatmap(dup), "duplicate row-column")
})

test_that("plot_dotplot errors on a mixture of present and missing features", {
  skip_if_not_implemented("plot_dotplot")
  skip_if_not_installed("SpatialExperiment")
  skip_if_not_installed("ggplot2")
  u <- tf_universe()
  obj <- tf_container("spe", u)
  expect_error(
    plot_dotplot(obj, features = c(u$genes[1], "MISSPELLED", u$genes[2]),
                 group_by = "group"),
    "MISSPELLED")
})

# ---- container independence -------------------------------------------------

test_that("plot_spatial and plot_blend also work on Seurat", {
  skip_if_not_implemented("plot_spatial")
  skip_if_not_installed("Seurat")
  skip_if_not_installed("ggplot2")
  u <- tf_universe(n_images = 2L, n_spots = 24)
  obj <- tf_container("seurat", u)
  expect_s3_class(plot_spatial(obj, feature = u$genes[1], assay = "Spatial",
                               layer = "data"), "ggplot")
  expect_s3_class(plot_blend(obj, u$genes[1], u$genes[2], assay = "Spatial",
                             layer = "data"), "ggplot")
})

test_that("theme_matrispace is a ggplot theme", {
  skip_if_not_implemented("theme_matrispace")
  skip_if_not_installed("ggplot2")
  expect_s3_class(theme_matrispace(), "theme")
})

test_that("spatial-family plots omit coordinate furniture and grid lines", {
  skip_if_not_installed("SpatialExperiment")
  skip_if_not_installed("ggplot2")
  u <- tf_universe()
  obj <- tf_container("spe", u)
  graph <- build_spatial_graph(obj, method = "knn", k = 3, graph_name = "g")
  lisa <- compute_lisa(graph, feature1 = u$genes[1], graph = "g", n_perm = 19)
  plots <- list(
    plot_spatial(obj, u$genes[1]),
    plot_blend(obj, u$genes[1], u$genes[2]),
    plot_lisa(graph, lisa)
  )
  for (p in plots) {
    expect_null(p$labels$x)
    expect_null(p$labels$y)
    expect_s3_class(p$theme$panel.grid, "element_blank")
    expect_s3_class(p$theme$axis.title, "element_blank")
    expect_s3_class(p$theme$axis.text, "element_blank")
    expect_s3_class(p$theme$axis.ticks, "element_blank")
  }
})

test_that("non-spatial grid lines are chosen by plot semantics", {
  skip_if_not_installed("SpatialExperiment")
  skip_if_not_installed("ggplot2")
  u <- tf_universe()
  obj <- tf_container("spe", u)

  # Violin plots keep horizontal value guides, but drop vertical group guides.
  violin <- plot_violin(obj, u$genes[1], group_by = "group")
  expect_s3_class(violin$theme$panel.grid.major.x, "element_blank")
  expect_false(inherits(violin$theme$panel.grid.major.y, "element_blank"))

  # Heatmap tiles provide their own matrix structure, so no panel grid is used.
  heatmap <- plot_heatmap(matrix(1:4, 2, 2))
  expect_s3_class(heatmap$theme$panel.grid, "element_blank")

  # Dot plots retain matrix guides to trace feature-by-group cells.
  dot <- plot_dotplot(obj, u$genes[1:2], group_by = "group")
  expect_false(inherits(dot$theme$panel.grid.major, "element_blank"))
})

# ---- focused plotting revision ---------------------------------------------

test_that("plot_spatial supports explicit discrete semantics and compact style", {
  skip_if_not_installed("SpatialExperiment")
  u <- tf_universe(); obj <- tf_container("spe", u)
  SummarizedExperiment::colData(obj)$integer_cluster <-
    rep(0:3, length.out = ncol(obj))
  p <- plot_spatial(obj, "integer_cluster", feature_type = "discrete",
                    point_size = 0.7, point_alpha = 0.8)
  expect_true(p$scales$get_scales("colour")$is_discrete())
  expect_equal(p$layers[[1]]$aes_params$size, 0.7)
  expect_equal(p$layers[[1]]$aes_params$alpha, 0.8)
  expect_length(palette_annotation(14), 14)
})

test_that("plot_heatmap uses conventional orientation, explicit NA cells, and signed scale", {
  m <- matrix(c(-2, 1, 3, NA), 2, 2,
              dimnames = list(c("first", "second"), c("A", "B")))
  p <- plot_heatmap(m)
  expect_identical(p$scales$get_scales("y")$limits, c("second", "first"))
  expect_true(anyNA(p$data$value))
  expect_equal(tolower(p$scales$get_scales("fill")$palette(0.5)), "#f7f7f7")

  sparse <- data.frame(feature = c("g1", "g2"), group = c("A", "B"),
                       value = c(1, 2))
  ps <- plot_heatmap(sparse, complete = TRUE)
  expect_equal(nrow(ps$data), 4)
  expect_equal(sum(is.na(ps$data$value)), 2)
})

test_that("plot_heatmap and dotplot offer within-feature scaling", {
  m <- matrix(c(1, 2, 3, 10, 20, 30), 2, 3, byrow = TRUE,
              dimnames = list(c("g1", "g2"), c("A", "B", "C")))
  p <- plot_heatmap(m, scale_by = "row")
  expect_equal(as.numeric(tapply(p$data$value, p$data$row, mean)), c(0, 0),
               tolerance = 1e-12)

  skip_if_not_installed("SpatialExperiment")
  u <- tf_universe(); obj <- tf_container("spe", u)
  d <- plot_dotplot(obj, u$genes[1:2], "group", scale_by = "feature")
  expect_match(ggplot2::get_labs(d)$colour, "z-score", fixed = TRUE)
})

test_that("blend carries an explanatory corner legend and LISA prefers adjusted p", {
  skip_if_not_installed("SpatialExperiment")
  u <- tf_universe(); obj <- tf_container("spe", u)
  b <- plot_blend(obj, u$genes[1], u$genes[2])
  expect_equal(ggplot2::get_labs(b)$colour, "Bivariate blend")
  expect_length(b$scales$get_scales("colour")$breaks, 4)

  res <- data.frame(spot_id = u$spots, image_id = u$image_ids,
                    quadrant = "HH", p_value = 0.001,
                    p_adjusted = rep(c(0.01, 0.2), length.out = length(u$spots)))
  l <- plot_lisa(obj, res, significance = 0.05)
  expect_equal(l$data$plot_quadrant,
               ifelse(res$p_adjusted <= 0.05, "HH", "Not significant"))
  expect_null(l$labels$alpha)                         # no redundant alpha legend
})

test_that("violin can add compact summaries without a redundant legend", {
  skip_if_not_installed("SpatialExperiment")
  u <- tf_universe(); obj <- tf_container("spe", u)
  p <- plot_violin(obj, u$genes[1], "group", box = TRUE, jitter = TRUE,
                   show_n = TRUE)
  expect_equal(p$theme$legend.position, "none")
  expect_equal(length(p$layers), 3)
  expect_match(as.character(p$scales$get_scales("x")$labels[[1]]), "n=")
})

test_that("plot_sample_comparison draws range whiskers, points and P brackets", {
  d <- data.frame(condition = rep(c("control", "IPF"), each = 4), a = 1:8, b = 8:1)
  p <- plot_sample_comparison(d, c("a", "b"), p_values = c(0.029, 0.5),
                              labels = c(a = "Feature A", b = "Feature B"))
  expect_s3_class(p, "ggplot")
  b <- ggplot2::ggplot_build(p)$data[[1]]
  b <- b[b$PANEL == 1, ]
  expect_identical(b$ymin[order(b$x)], c(1, 5))
  expect_identical(b$ymax[order(b$x)], c(4, 8))
  expect_true(any(vapply(p$layers, function(l) inherits(l$geom, "GeomText"), logical(1))))
  expect_identical(levels(p$data$feature), c("Feature A", "Feature B"))
  expect_error(plot_sample_comparison(d, "a", group = "a"), "exactly two")
  expect_error(plot_sample_comparison(d, "a", p_values = c(1, 2)), "one number per feature")
})

test_that("plot_heatmap accepts figure colours, labels and italics", {
  m <- matrix(c(-1, 0, 1, 2), 2, dimnames = list(c("COMP__ITGAV", "B"), c("x", "y")))
  p <- plot_heatmap(m, colours = palette_diverging(), legend_title = "log2 fold change",
                    row_labels = function(x) sub("__", "-", x), italic = "rows",
                    x_angle = 45, legend_position = "bottom")
  expect_s3_class(p, "ggplot")
  expect_identical(p$labels$fill, "log2 fold change")
  expect_identical(p$theme$axis.text.y$face, "italic")
  expect_error(plot_heatmap(m, colours = "red"), "at least two")
})

test_that("plot_spatial supports the spectral scale, titles and a scale bar", {
  skip_if_not_installed("SpatialExperiment")
  u <- tf_universe()
  obj <- tf_container("spe", u)
  p <- plot_spatial(obj, feature = u$genes[1], colour_scale = "spectral",
                    title = "Gene", legend_title = "Expression", scale_bar = 2,
                    scale_bar_label = "2 units")
  expect_s3_class(p, "ggplot")
  expect_identical(p$labels$title, "Gene")
  sc <- p$scales$get_scales("colour")
  expect_identical(sc$name, "Expression")
  geoms <- vapply(p$layers, function(l) class(l$geom)[1], character(1))
  expect_true(all(c("GeomSegment", "GeomText") %in% geoms))
  expect_error(plot_spatial(obj, feature = u$genes[1], scale_bar = -1), "positive")
})
