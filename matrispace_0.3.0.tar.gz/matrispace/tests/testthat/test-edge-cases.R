# Malformed-input edge cases (arch doc s2.6): duplicated / missing spot IDs
# must be rejected with a clear error, not silently mis-aligned. Tested at the
# validation-helper level so the guarantee holds for every entry point.

test_that(".validate_spot_ids rejects duplicated ids", {
  skip_if_not_implemented(".validate_spot_ids")
  expect_error(mfn(".validate_spot_ids")(c("spot1", "spot2", "spot1")),
               regexp = "duplicat")
})

test_that(".validate_spot_ids rejects missing / empty ids", {
  skip_if_not_implemented(".validate_spot_ids")
  expect_error(mfn(".validate_spot_ids")(c("spot1", NA, "spot3")))
  expect_error(mfn(".validate_spot_ids")(c("spot1", "", "spot3")))
  expect_error(mfn(".validate_spot_ids")(NULL))
})

test_that(".validate_spot_ids passes a clean unique id vector", {
  skip_if_not_implemented(".validate_spot_ids")
  ids <- sprintf("spot%03d", 1:5)
  expect_silent(mfn(".validate_spot_ids")(ids))
})

test_that("building a graph on duplicated spot ids errors", {
  skip_if_not_implemented("build_spatial_graph")
  skip_if_not_installed("SpatialExperiment")
  u <- tf_universe(n_spots = 6, n_images = 1)
  obj <- tf_container("spe", u)
  # Force a duplicate id into the container.
  colnames(obj) <- c(u$spots[1], u$spots[1], u$spots[3:6])
  expect_error(build_spatial_graph(obj, method = "knn", k = 2, graph_name = "g"))
})
