# ECM spatial variability via nnSVG (SPATIAL_EXTENSIONS_IMPLEMENTATION_SPEC s5).
# The optional nnSVG fit is isolated behind .run_nnsvg(); most tests mock it (no
# long model fit), with one real end-to-end smoke test gated on nnSVG.

SVG_SCHEMA <- c("feature", "image_id", "rank", "sigma_sq", "tau_sq",
                "length_scale", "prop_sv", "lr_statistic", "p_value",
                "p_adjusted", "status", "assay", "layer", "n_spots",
                "n_neighbors", "order")

# Shared logical data (one gene, FLAT, is deliberately constant/unfit).
svg_universe <- function(ns = 12L, n_images = 1L) {
  withr::with_seed(1, {
    genes <- c("COL1A1", "COL1A2", "FN1", "FLAT")
    spots <- sprintf("s%02d", seq_len(ns))
    counts <- matrix(abs(stats::rpois(length(genes) * ns, 5)), length(genes), ns,
                     dimnames = list(genes, spots))
    logm <- log1p(counts); logm["FLAT", ] <- 2          # zero-variance feature
    coords <- cbind(x = (seq_len(ns) %% 4) * 10 + stats::runif(ns, -0.1, 0.1),
                    y = (seq_len(ns) %/% 4) * 10 + stats::runif(ns, -0.1, 0.1))
    rownames(coords) <- spots
    cond <- rep(c("a", "b"), length.out = ns)
    list(genes = genes, spots = spots, counts = counts, logcounts = logm,
         coords = coords, cond = cond,
         images = rep(sprintf("img%d", seq_len(n_images)), length.out = ns))
  })
}

svg_spe <- function(u = svg_universe(), extra = NULL) {
  cd <- S4Vectors::DataFrame(cond = u$cond, row.names = u$spots)
  if (!is.null(extra)) for (nm in names(extra)) cd[[nm]] <- extra[[nm]]
  SpatialExperiment::SpatialExperiment(
    assays = list(counts = Matrix::Matrix(u$counts, sparse = TRUE),
                  logcounts = Matrix::Matrix(u$logcounts, sparse = TRUE)),
    spatialCoords = u$coords, colData = cd, sample_id = u$images)
}

svg_seurat <- function(u = svg_universe()) {
  obj <- SeuratObject::CreateSeuratObject(
    counts = Matrix::Matrix(u$counts, sparse = TRUE),
    meta.data = data.frame(cond = u$cond, row.names = u$spots), assay = "Spatial")
  SeuratObject::LayerData(obj, layer = "data", assay = "Spatial") <-
    Matrix::Matrix(u$logcounts, sparse = TRUE)
  for (im in unique(u$images)) {
    idx <- u$images == im; cc <- u$coords[idx, , drop = FALSE]
    cents <- SeuratObject::CreateCentroids(
      data.frame(x = cc[, "x"], y = cc[, "y"], cell = rownames(cc)))
    obj[[im]] <- SeuratObject::CreateFOV(cents, type = "centroids",
                                         assay = "Spatial", key = paste0(im, "_"))
  }
  obj
}

# A mock .run_nnsvg that (optionally) records its inputs and returns canned stats.
mock_nnsvg <- function(rec = NULL) {
  function(mat, coords, X, n_neighbors, order, n_threads) {
    if (!is.null(rec)) {
      rec$mat <- mat; rec$coords <- coords; rec$X <- X
      rec$n_neighbors <- n_neighbors; rec$order <- order; rec$n_threads <- n_threads
    }
    g <- rownames(mat)
    data.frame(feature = g, rank = seq_along(g), sigma_sq = 0.5, tau_sq = 0.2,
               length_scale = 10, prop_sv = seq(0.9, 0.5, length.out = length(g)),
               lr_statistic = 5, p_value = seq(0.01, 0.2, length.out = length(g)),
               stringsAsFactors = FALSE)
  }
}

# ---- dependency + failure semantics -----------------------------------------

test_that("an absent nnSVG dependency errors with an install instruction", {
  skip_if_not_implemented("find_spatially_variable_ecm")
  skip_if_not_installed("SpatialExperiment")
  testthat::local_mocked_bindings(.nnsvg_installed = function() FALSE,
                                  .package = "matrispace")
  expect_error(
    find_spatially_variable_ecm(svg_spe(), features = "COL1A1",
                                assay = "logcounts", layer = "x"),
    "requires the optional 'nnSVG'")
})

test_that("assay and layer are mandatory with actionable layer diagnostics", {
  skip_if_not_implemented("find_spatially_variable_ecm")
  skip_if_not_installed("Seurat")
  testthat::local_mocked_bindings(.nnsvg_installed = function() TRUE,
                                  .run_nnsvg = mock_nnsvg(), .package = "matrispace")
  obj <- svg_seurat()
  expect_error(find_spatially_variable_ecm(obj, features = "COL1A1", layer = "data"),
               "`assay` is required")
  expect_error(find_spatially_variable_ecm(obj, features = "COL1A1", assay = "Spatial"),
               "`layer` is required")
  expect_error(find_spatially_variable_ecm(obj, features = "COL1A1",
                                           assay = "Spatial", layer = "pflog"),
               "no layer 'pflog'")
})

# ---- selector contract ------------------------------------------------------

test_that("features/include are mutually exclusive and preserve requested order", {
  skip_if_not_implemented("find_spatially_variable_ecm")
  skip_if_not_installed("SpatialExperiment")
  testthat::local_mocked_bindings(.nnsvg_installed = function() TRUE,
                                  .run_nnsvg = mock_nnsvg(), .package = "matrispace")
  spe <- svg_spe()
  expect_error(
    find_spatially_variable_ecm(spe, features = "COL1A1", include = "collagens",
                                assay = "logcounts", layer = "x"),
    "exactly one of")
  d <- find_spatially_variable_ecm(spe, features = c("FN1", "COL1A1", "COL1A2"),
                                   assay = "logcounts", layer = "x")
  expect_equal(d$feature, c("FN1", "COL1A1", "COL1A2"))       # requested order
  # A missing CUSTOM feature is a named, actionable error.
  expect_error(
    find_spatially_variable_ecm(spe, features = c("COL1A1", "NOPE"),
                                assay = "logcounts", layer = "x"),
    "NOPE")
})

test_that("bundled include tolerates absent genes as status = absent", {
  skip_if_not_implemented("find_spatially_variable_ecm")
  skip_if_not_installed("SpatialExperiment")
  testthat::local_mocked_bindings(.nnsvg_installed = function() TRUE,
                                  .run_nnsvg = mock_nnsvg(), .package = "matrispace")
  d <- find_spatially_variable_ecm(svg_spe(), include = "collagens",
                                   assay = "logcounts", layer = "x")
  # collagens genes present in the tiny dataset are tested; the rest are retained
  # with status 'absent' (not silently dropped, not an error).
  expect_true("COL1A1" %in% d$feature)
  expect_true(any(d$status == "absent"))
  expect_equal(nrow(d), length(matrisome_signatures$collagens))
  expect_true(all(is.na(d$p_value[d$status == "absent"])))
})

# ---- unfit features, schema, BH ---------------------------------------------

test_that("every requested feature is retained with tested/constant status rows", {
  skip_if_not_implemented("find_spatially_variable_ecm")
  skip_if_not_installed("SpatialExperiment")
  testthat::local_mocked_bindings(.nnsvg_installed = function() TRUE,
                                  .run_nnsvg = mock_nnsvg(), .package = "matrispace")
  d <- find_spatially_variable_ecm(svg_spe(),
                                   features = c("COL1A1", "FN1", "FLAT"),
                                   assay = "logcounts", layer = "x")
  expect_equal(names(d), SVG_SCHEMA)
  expect_setequal(d$feature, c("COL1A1", "FN1", "FLAT"))
  expect_equal(d$status[d$feature == "FLAT"], "constant")     # zero variance
  expect_true(is.na(d$p_value[d$feature == "FLAT"]))
  expect_true(all(d$status[d$feature %in% c("COL1A1", "FN1")] == "tested"))
})

test_that("p_adjusted is exactly BH over the successfully tested features", {
  skip_if_not_implemented("find_spatially_variable_ecm")
  skip_if_not_installed("SpatialExperiment")
  testthat::local_mocked_bindings(.nnsvg_installed = function() TRUE,
                                  .run_nnsvg = mock_nnsvg(), .package = "matrispace")
  d <- find_spatially_variable_ecm(svg_spe(),
                                   features = c("COL1A1", "COL1A2", "FN1", "FLAT"),
                                   assay = "logcounts", layer = "x")
  ok <- d$status == "tested"
  expect_equal(d$p_adjusted[ok], stats::p.adjust(d$p_value[ok], "BH"))
  expect_true(all(is.na(d$p_adjusted[!ok])))
})

# ---- container equivalence + alignment --------------------------------------

test_that("Seurat and SpatialExperiment yield equivalent nnSVG inputs + schema", {
  skip_if_not_implemented("find_spatially_variable_ecm")
  skip_if_not_installed("Seurat")
  skip_if_not_installed("SpatialExperiment")
  u <- svg_universe()
  rec_spe <- new.env(); rec_seu <- new.env()
  feats <- c("COL1A1", "COL1A2", "FN1")

  testthat::with_mocked_bindings({
    d_spe <- find_spatially_variable_ecm(svg_spe(u), features = feats,
                                         assay = "logcounts", layer = "x")
  }, .nnsvg_installed = function() TRUE, .run_nnsvg = mock_nnsvg(rec_spe),
     .package = "matrispace")
  testthat::with_mocked_bindings({
    d_seu <- find_spatially_variable_ecm(svg_seurat(u), features = feats,
                                         assay = "Spatial", layer = "data")
  }, .nnsvg_installed = function() TRUE, .run_nnsvg = mock_nnsvg(rec_seu),
     .package = "matrispace")

  expect_equal(names(d_spe), names(d_seu))                     # stable schema
  # Coordinates are aligned to the matrix by spot id in both containers.
  expect_identical(colnames(rec_spe$mat), rownames(rec_spe$coords))
  expect_identical(colnames(rec_seu$mat), rownames(rec_seu$coords))
  # Same logical input matrix/coords (within tolerance), independent of container.
  ord <- u$spots
  expect_equal(as.matrix(rec_seu$mat)[feats, ord],
               as.matrix(rec_spe$mat)[feats, ord], tolerance = 1e-8)
  expect_equal(rec_seu$coords[ord, ], rec_spe$coords[ord, ], tolerance = 1e-6)
})

test_that("spot alignment survives a host column reorder", {
  skip_if_not_implemented("find_spatially_variable_ecm")
  skip_if_not_installed("SpatialExperiment")
  u <- svg_universe(); rec <- new.env()
  testthat::with_mocked_bindings({
    find_spatially_variable_ecm(svg_spe(u)[, c(5, 1, 8, 2, 12, 3, 7, 4, 11, 6, 10, 9)],
                                features = c("COL1A1", "FN1"),
                                assay = "logcounts", layer = "x")
  }, .nnsvg_installed = function() TRUE, .run_nnsvg = mock_nnsvg(rec),
     .package = "matrispace")
  # Each column of the matrix passed to nnSVG matches its coordinate row by id.
  expect_identical(colnames(rec$mat), rownames(rec$coords))
})

# ---- image rules ------------------------------------------------------------

test_that("a multi-image object requires exactly one image_id", {
  skip_if_not_implemented("find_spatially_variable_ecm")
  skip_if_not_installed("SpatialExperiment")
  testthat::local_mocked_bindings(.nnsvg_installed = function() TRUE,
                                  .run_nnsvg = mock_nnsvg(), .package = "matrispace")
  spe <- svg_spe(svg_universe(ns = 12L, n_images = 2L))   # 6 spots per image
  expect_error(
    find_spatially_variable_ecm(spe, features = "COL1A1", assay = "logcounts"),
    "requires exactly one valid `image_id`")
  d <- find_spatially_variable_ecm(spe, features = "COL1A1", image_id = "img1",
                                   assay = "logcounts", n_neighbors = 3L)
  expect_equal(unique(d$image_id), "img1")
})

# ---- covariates -------------------------------------------------------------

test_that("covariate design is validated (missing col/value, one level, rank, dups)", {
  skip_if_not_implemented("find_spatially_variable_ecm")
  skip_if_not_installed("SpatialExperiment")
  rec <- new.env()
  testthat::local_mocked_bindings(.nnsvg_installed = function() TRUE,
                                  .run_nnsvg = mock_nnsvg(rec), .package = "matrispace")
  u <- svg_universe()
  fx <- function(spe, ...) find_spatially_variable_ecm(
    spe, features = "COL1A1", assay = "logcounts", ...)
  expect_error(fx(svg_spe(u), covariates = "nope"), "not found")
  expect_error(fx(svg_spe(u), covariates = c("cond", "cond")), "duplicate")
  one <- svg_spe(u, extra = list(flat = rep("z", length(u$spots))))
  expect_error(fx(one, covariates = "flat"), "only one level")
  na_cov <- u$cond; na_cov[1] <- NA
  expect_error(fx(svg_spe(u, extra = list(cna = na_cov)), covariates = "cna"),
               "missing values")
  # A non-finite numeric covariate is NOT caught by anyNA(); reject it explicitly.
  inf_cov <- as.numeric(seq_along(u$spots)); inf_cov[1] <- Inf
  expect_error(fx(svg_spe(u, extra = list(cinf = inf_cov)), covariates = "cinf"),
               "non-finite")
  expect_error(fx(svg_spe(u, extra = list(cond2 = u$cond)),
                  covariates = c("cond", "cond2")), "rank-deficient")
  # A valid covariate design reaches nnSVG WITH its intercept column (nnSVG 1.14
  # fits the null mean model as y ~ X - 1, so the intercept must be in X).
  d <- fx(svg_spe(u), covariates = "cond")
  expect_true("(Intercept)" %in% colnames(rec$X))
  expect_true("condb" %in% colnames(rec$X))
  expect_setequal(attr(d, "matrispace")$covariate_terms, c("(Intercept)", "condb"))
})

test_that("a real nnSVG covariate fit runs with the full (intercept) design", {
  skip_if_not_implemented("find_spatially_variable_ecm")
  skip_if_not_installed("SpatialExperiment")
  skip_if_not_installed("nnSVG")
  u <- svg_universe(ns = 70L)
  d <- suppressWarnings(suppressMessages(
    find_spatially_variable_ecm(svg_spe(u), features = c("COL1A1", "COL1A2", "FN1"),
                                assay = "logcounts", covariates = "cond")))
  expect_true(all(d$status == "tested"))
  expect_true(all(d$p_value >= 0 & d$p_value <= 1))
})

# ---- provenance -------------------------------------------------------------

test_that("provenance records dependency versions and the computation inputs", {
  skip_if_not_implemented("find_spatially_variable_ecm")
  skip_if_not_installed("SpatialExperiment")
  skip_if_not_installed("nnSVG")
  testthat::local_mocked_bindings(.nnsvg_installed = function() TRUE,
                                  .run_nnsvg = mock_nnsvg(), .package = "matrispace")
  d <- find_spatially_variable_ecm(svg_spe(), features = c("COL1A1", "FLAT"),
                                   assay = "logcounts", layer = "x",
                                   n_neighbors = 8L, order = "AMMD")
  p <- attr(d, "matrispace")
  expect_equal(p$producer, "find_spatially_variable_ecm")
  expect_equal(p$assay, "logcounts")
  expect_equal(p$n_neighbors, 8L)
  expect_equal(p$n_tested, 1L); expect_equal(p$n_constant, 1L)
  expect_true(nzchar(p$nnSVG_version))
  # The result is standalone: it is a plain data.frame, not written to the object.
  expect_s3_class(d, "data.frame")
})

# ---- optional real end-to-end smoke -----------------------------------------

test_that("real nnSVG smoke test fits and returns the schema", {
  skip_if_not_implemented("find_spatially_variable_ecm")
  skip_if_not_installed("SpatialExperiment")
  skip_if_not_installed("nnSVG")
  # AMMD ordering needs >= 65 points; use a real (small) section.
  u <- svg_universe(ns = 70L)
  d <- suppressWarnings(suppressMessages(
    find_spatially_variable_ecm(svg_spe(u), features = c("COL1A1", "COL1A2", "FN1"),
                                assay = "logcounts", layer = "x")))
  expect_equal(names(d), SVG_SCHEMA)
  expect_true(all(d$status == "tested"))
  expect_true(all(d$prop_sv >= 0 & d$prop_sv <= 1))
  expect_true(all(d$p_value >= 0 & d$p_value <= 1))
})

# ---- default selection, SPE layer, upstream guards, adapter validation ------

test_that("omitting both selectors is present-only (no absent rows)", {
  skip_if_not_implemented("find_spatially_variable_ecm")
  skip_if_not_installed("SpatialExperiment")
  testthat::local_mocked_bindings(.nnsvg_installed = function() TRUE,
                                  .run_nnsvg = mock_nnsvg(), .package = "matrispace")
  # The dataset holds only COL1A1/COL1A2/FN1 (of the whole matrisome); the default
  # tests exactly those present genes, with no 'absent' rows.
  d <- find_spatially_variable_ecm(svg_spe(), assay = "logcounts")
  expect_false(any(d$status == "absent"))
  expect_true(all(d$feature %in% c("COL1A1", "COL1A2", "FN1", "FLAT")))
  expect_true(all(d$feature %in% unlist(matrisome_signatures)))
})

test_that("SpatialExperiment allows layer = NULL and records it as NA", {
  skip_if_not_implemented("find_spatially_variable_ecm")
  skip_if_not_installed("SpatialExperiment")
  testthat::local_mocked_bindings(.nnsvg_installed = function() TRUE,
                                  .run_nnsvg = mock_nnsvg(), .package = "matrispace")
  d <- find_spatially_variable_ecm(svg_spe(), features = "COL1A1",
                                   assay = "logcounts")            # no layer
  expect_true(all(is.na(d$layer)))
  expect_true(is.na(attr(d, "matrispace")$layer))
})

test_that("non-finite coordinates and n_neighbors >= n_spots error before nnSVG", {
  skip_if_not_implemented("find_spatially_variable_ecm")
  skip_if_not_installed("SpatialExperiment")
  testthat::local_mocked_bindings(.nnsvg_installed = function() TRUE,
                                  .run_nnsvg = mock_nnsvg(), .package = "matrispace")
  u <- svg_universe()
  bad <- u; bad$coords[2, 1] <- Inf
  # A non-finite coordinate is rejected before nnSVG (by the SPE accessor's own
  # finiteness check, or by our post-extraction guard for Seurat).
  expect_error(
    find_spatially_variable_ecm(svg_spe(bad), features = "COL1A1", assay = "logcounts"),
    "non-finite")
  expect_error(
    find_spatially_variable_ecm(svg_spe(u), features = "COL1A1", assay = "logcounts",
                                n_neighbors = 999L),
    "must be less than the number of spots")
})

test_that(".run_nnsvg rejects an nnSVG feature set that mismatches the request", {
  skip_if_not_implemented(".run_nnsvg")
  skip_if_not_installed("nnSVG")
  # Mock the real nnSVG to return an EXTRA feature row; the adapter's coverage
  # guard (real .run_nnsvg) must fail loudly rather than misalign later status.
  fake <- function(input, spatial_coords, X = NULL, n_neighbors, order,
                   n_threads, ...) {
    matrix(0.1, nrow(input) + 1L, 14,
           dimnames = list(c(rownames(input), "EXTRA"),
             c("sigma.sq", "tau.sq", "phi", "loglik", "runtime", "mean", "var",
               "spcov", "prop_sv", "loglik_lm", "LR_stat", "rank", "pval", "padj")))
  }
  testthat::local_mocked_bindings(nnSVG = fake, .package = "nnSVG")
  mat <- matrix(1, 2, 5, dimnames = list(c("g1", "g2"), paste0("s", 1:5)))
  coords <- cbind(x = 1:5, y = 1:5); rownames(coords) <- colnames(mat)
  expect_error(mfn(".run_nnsvg")(mat, coords, NULL, 3L, "AMMD", 1L),
               "does not exactly match the submitted features")
})

test_that("nnSVG uses an explicit platform-supported BiocParallel backend", {
  skip_if_not_implemented(".nnsvg_bpparam")
  skip_if_not_installed("BiocParallel")
  one <- mfn(".nnsvg_bpparam")(1L)
  expect_s4_class(one, "SerialParam")
  many <- mfn(".nnsvg_bpparam")(2L)
  if (.Platform$OS.type == "windows") {
    expect_s4_class(many, "SnowParam")
  } else {
    expect_s4_class(many, "MulticoreParam")
  }
  expect_equal(BiocParallel::bpnworkers(many), 2L)
})

test_that("a per-feature nnSVG fit with non-finite stats is marked failed", {
  skip_if_not_implemented("find_spatially_variable_ecm")
  skip_if_not_installed("SpatialExperiment")
  # nnSVG returns NA p_value for FN1 -> that feature is 'failed', not 'tested',
  # and is excluded from the BH family.
  mock_fail <- function(mat, coords, X, n_neighbors, order, n_threads) {
    g <- rownames(mat)
    pv <- ifelse(g == "FN1", NA_real_, 0.02)
    data.frame(feature = g, rank = seq_along(g), sigma_sq = 0.5, tau_sq = 0.2,
               length_scale = 10, prop_sv = ifelse(g == "FN1", NA_real_, 0.7),
               lr_statistic = 5, p_value = pv, stringsAsFactors = FALSE)
  }
  testthat::local_mocked_bindings(.nnsvg_installed = function() TRUE,
                                  .run_nnsvg = mock_fail, .package = "matrispace")
  d <- find_spatially_variable_ecm(svg_spe(), features = c("COL1A1", "FN1"),
                                   assay = "logcounts")
  expect_equal(d$status[d$feature == "FN1"], "failed")
  expect_true(is.na(d$p_value[d$feature == "FN1"]))
  expect_true(is.na(d$p_adjusted[d$feature == "FN1"]))
  expect_equal(d$status[d$feature == "COL1A1"], "tested")
})

test_that("any invalid required fit statistic marks a feature failed", {
  skip_if_not_implemented("find_spatially_variable_ecm")
  skip_if_not_installed("SpatialExperiment")
  ns <- 12L; genes <- paste0("G", 1:5)
  mat <- withr::with_seed(1, log1p(matrix(abs(stats::rpois(5L * ns, 5)) + 1, 5L, ns,
                dimnames = list(genes, sprintf("s%02d", seq_len(ns))))))
  coords <- withr::with_seed(2, cbind(x = stats::runif(ns), y = stats::runif(ns)))
  rownames(coords) <- colnames(mat)
  spe <- SpatialExperiment::SpatialExperiment(
    assays = list(logcounts = Matrix::Matrix(mat, sparse = TRUE)),
    spatialCoords = coords,
    colData = S4Vectors::DataFrame(row.names = colnames(mat)), sample_id = rep("i", ns))
  # Each feature gets a different kind of invalid required statistic.
  mock_invalid <- function(mat, coords, X, n_neighbors, order, n_threads) {
    g <- rownames(mat)
    d <- data.frame(feature = g, rank = seq_along(g), sigma_sq = 0.5, tau_sq = 0.2,
                    length_scale = 10, prop_sv = 0.7, lr_statistic = 5,
                    p_value = 0.02, stringsAsFactors = FALSE)
    d$sigma_sq[1] <- Inf         # non-finite variance component
    d$prop_sv[2] <- 1.5          # prop_sv outside [0, 1]
    d$rank[3] <- NA_real_        # NA rank
    d$length_scale[4] <- -1      # non-positive length scale
    d$p_value[5] <- 2            # p_value outside [0, 1]
    d
  }
  testthat::local_mocked_bindings(.nnsvg_installed = function() TRUE,
                                  .run_nnsvg = mock_invalid, .package = "matrispace")
  d <- find_spatially_variable_ecm(spe, features = genes, assay = "logcounts")
  expect_true(all(d$status == "failed"))            # every invalid fit -> failed
  expect_true(all(is.na(d$p_value)) && all(is.na(d$p_adjusted)) &&
                all(is.na(d$sigma_sq)) && all(is.na(d$rank)))
  # A valid mix still yields tested for the good rows only.
  mock_mixed <- function(mat, coords, X, n_neighbors, order, n_threads) {
    d <- mock_invalid(mat, coords, X, n_neighbors, order, n_threads)
    d$sigma_sq[1] <- 0.5; d$prop_sv[2] <- 0.7        # repair G1, G2
    d
  }
  testthat::local_mocked_bindings(.run_nnsvg = mock_mixed, .package = "matrispace")
  d2 <- find_spatially_variable_ecm(spe, features = genes, assay = "logcounts")
  expect_equal(d2$status[d2$feature %in% c("G1", "G2")], c("tested", "tested"))
  expect_true(all(d2$status[d2$feature %in% c("G3", "G4", "G5")] == "failed"))
  expect_equal(d2$p_adjusted[d2$status == "tested"],
               stats::p.adjust(d2$p_value[d2$status == "tested"], "BH"))
})
