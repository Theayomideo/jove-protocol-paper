# Ligand-receptor activity (arch doc s2.4, s5.2, Phase 5). Rewritten against a
# NAMED graph: no hardcoded six-neighbour Visium assumption, no dense
# expression / adjacency conversion, reorder- and multi-sample-safe.

# Two connected spots (radius graph) with an explicit logcounts assay carrying
# ligand L and receptor R, for exact hand oracles.
lr_two_spot_spe <- function(L, R) {
  spots <- c("s1", "s2"); coords <- cbind(x = c(0, 1), y = 0)
  rownames(coords) <- spots
  m <- rbind(L = L, R = R); colnames(m) <- spots
  SpatialExperiment::SpatialExperiment(
    assays = list(logcounts = m), spatialCoords = coords,
    colData = S4Vectors::DataFrame(replicate_id = rep("r", 2),
                                   group = c("A", "B"), row.names = spots),
    sample_id = rep("img", 2))
}

test_that("L-R activity matches the orientation hand oracle", {
  skip_if_not_implemented("build_spatial_graph", "score_lr_activity", "get_lr_activity")
  skip_if_not_installed("SpatialExperiment")
  # W[i,j] = sender j -> receiver i. ligand L=(4,0), receptor R=(0,9),
  # row-standardized single-edge graph: activity(s2) = sqrt(9)*W*sqrt(4) = 6.
  obj <- build_spatial_graph(lr_two_spot_spe(c(4, 0), c(0, 9)), method = "radius",
                             radius = 1.5, graph_name = "g")
  lr <- data.frame(ligand = "L", receptor = "R", stringsAsFactors = FALSE)
  act <- get_lr_activity(score_lr_activity(obj, pairs = lr, graph = "g",
         assay = "logcounts", layer = NULL))
  expect_equal(as.numeric(act[1, c("s1", "s2")]), c(0, 6), tolerance = TOL)
})

test_that("negative expression is truncated to 0 before sqrt (no NaN)", {
  skip_if_not_implemented("build_spatial_graph", "score_lr_activity", "get_lr_activity")
  skip_if_not_installed("SpatialExperiment")
  # ligand L=(-4,9) -> sqrt(max(.,0)) = (0,3); receptor R=(9,4) -> (3,2).
  # activity(s1)=sqrt(9)*W*sqrt(max(9,0))=3*3=9; activity(s2)=sqrt(4)*W*sqrt(0)=0.
  obj <- build_spatial_graph(lr_two_spot_spe(c(-4, 9), c(9, 4)), method = "radius",
                             radius = 1.5, graph_name = "g")
  lr <- data.frame(ligand = "L", receptor = "R", stringsAsFactors = FALSE)
  act <- get_lr_activity(score_lr_activity(obj, pairs = lr, graph = "g",
         assay = "logcounts", layer = NULL))
  vals <- as.numeric(act[1, c("s1", "s2")])
  expect_true(all(is.finite(vals)))            # no NaN from sqrt of a negative
  expect_equal(vals, c(9, 0), tolerance = TOL)
})

# Collinear spots with an explicit logcounts assay carrying ligand L and receptor R.
lr_line_spe <- function(coords_x, L, R, images = rep("img", length(coords_x))) {
  spots <- paste0("s", seq_along(coords_x))
  coords <- cbind(x = coords_x, y = 0); rownames(coords) <- spots
  m <- rbind(L = L, R = R); colnames(m) <- spots
  SpatialExperiment::SpatialExperiment(
    assays = list(logcounts = m), spatialCoords = coords,
    colData = S4Vectors::DataFrame(replicate_id = rep("r", length(spots)),
                                   group = rep("A", length(spots)), row.names = spots),
    sample_id = images)
}

test_that("directed orientation changes the result (asymmetric hand oracle)", {
  skip_if_not_implemented("build_spatial_graph", "score_lr_activity", "get_lr_activity")
  skip_if_not_installed("SpatialExperiment")
  # Spots at 0,1,3; ligand at s3, receptor at s2. Directed knn k=1 gives s2->s1
  # only, so s2 never sees s3's ligand -> activity(s2)=0. Undirected (union) adds
  # s2<->s3, so s2 aggregates s3's ligand -> activity(s2)=3.
  spe <- lr_line_spe(c(0, 1, 3), L = c(0, 0, 4), R = c(0, 9, 0))
  lr <- data.frame(ligand = "L", receptor = "R", stringsAsFactors = FALSE)
  obj <- build_spatial_graph(spe, method = "knn", k = 1, graph_name = "d", directed = TRUE)
  obj <- build_spatial_graph(obj, method = "knn", k = 1, graph_name = "u", directed = FALSE)
  ad <- get_lr_activity(score_lr_activity(obj, pairs = lr, graph = "d",
        assay = "logcounts", layer = NULL))
  au <- get_lr_activity(score_lr_activity(obj, pairs = lr, graph = "u",
        assay = "logcounts", layer = NULL))
  expect_equal(as.numeric(ad[1, "s2"]), 0, tolerance = TOL)
  expect_equal(as.numeric(au[1, "s2"]), 3, tolerance = TOL)
})

test_that("ligand in one image cannot contribute to a receptor in another", {
  skip_if_not_implemented("build_spatial_graph", "score_lr_activity", "get_lr_activity")
  skip_if_not_installed("SpatialExperiment")
  # image1 = s1,s2 (ligand); image2 = s3,s4 (receptor). Block-diagonal graph.
  spe <- lr_line_spe(c(0, 1, 0, 1), L = c(4, 4, 0, 0), R = c(0, 0, 9, 9),
                     images = c("i1", "i1", "i2", "i2"))
  obj <- build_spatial_graph(spe, method = "knn", k = 1, graph_name = "g")
  lr <- data.frame(ligand = "L", receptor = "R", stringsAsFactors = FALSE)
  act <- get_lr_activity(score_lr_activity(obj, pairs = lr, graph = "g",
         assay = "logcounts", layer = NULL))
  expect_true(all(as.numeric(act[1, ]) == 0))        # no cross-image contribution
})

test_that("[seurat] L-R activity round-trips through storage", {
  skip_if_not_implemented("build_spatial_graph", "score_lr_activity", "get_lr_activity")
  skip_if_not_installed("Seurat")
  u <- tf_universe(); lr <- tf_lr_pairs(u$genes)
  obj <- build_spatial_graph(tf_container("seurat", u), method = "knn", k = 4,
                             graph_name = "g")
  obj <- score_lr_activity(obj, pairs = lr, graph = "g", assay = "Spatial", layer = "data")
  act <- get_lr_activity(obj)
  expect_setequal(colnames(act), u$spots)
  expect_equal(nrow(act), nrow(lr))
})

test_that("weight choice (binary vs row-standardized) changes L-R activity", {
  skip_if_not_implemented("build_spatial_graph", "score_lr_activity", "get_lr_activity")
  skip_if_not_installed("SpatialExperiment")
  u <- tf_universe(n_spots = 36); lr <- tf_lr_pairs(u$genes)
  obj <- build_spatial_graph(tf_container("spe", u), method = "knn", k = 4,
                             graph_name = "g")
  a <- get_lr_activity(score_lr_activity(obj, pairs = lr, graph = "g",
       weight = "row_standardize", assay = "logcounts", layer = NULL))
  b <- get_lr_activity(score_lr_activity(obj, pairs = lr, graph = "g",
       weight = "binary", assay = "logcounts", layer = NULL))
  expect_false(isTRUE(all.equal(as.matrix(a), as.matrix(b))))
})

test_that("duplicate pairs are deduplicated before scoring", {
  skip_if_not_implemented("build_spatial_graph", "score_lr_activity", "get_lr_activity")
  skip_if_not_installed("SpatialExperiment")
  u <- tf_universe()
  lr <- data.frame(ligand = rep(u$genes[1], 2), receptor = rep(u$genes[10], 2),
                   stringsAsFactors = FALSE)
  obj <- build_spatial_graph(tf_container("spe", u), method = "knn", k = 4,
                             graph_name = "g")
  act <- get_lr_activity(score_lr_activity(obj, pairs = lr, graph = "g",
         assay = "logcounts", layer = NULL))
  expect_equal(nrow(act), 1L)
})

test_that("a missing-gene pair is not stored as a row but is recorded as missing", {
  skip_if_not_implemented("build_spatial_graph", "score_lr_activity", "get_lr_activity",
                          "lr_missing_pairs")
  skip_if_not_installed("SpatialExperiment")
  u <- tf_universe()
  lr <- data.frame(ligand = c(u$genes[1], "ABSENT"),
                   receptor = c(u$genes[10], u$genes[11]), stringsAsFactors = FALSE)
  obj <- build_spatial_graph(tf_container("spe", u), method = "knn", k = 4,
                             graph_name = "g")
  obj <- score_lr_activity(obj, pairs = lr, graph = "g", assay = "logcounts", layer = NULL)
  act <- get_lr_activity(obj)
  expect_equal(nrow(act), 1L)                       # only the scorable pair is a row
  miss <- lr_missing_pairs(obj)                      # missing pair recorded structurally
  expect_equal(miss$ligand, "ABSENT")
  expect_equal(miss$receptor, u$genes[11])
})

test_that("many missing pairs do not densify the stored result", {
  skip_if_not_implemented("build_spatial_graph", "score_lr_activity")
  skip_if_not_installed("SpatialExperiment")
  skip_if(!capabilities("profmem"), "no memory profiling")
  u <- tf_universe(n_spots = 400, n_images = 1)
  # 1 scorable pair + 2000 pairs whose genes are absent from the dataset.
  lr <- rbind(
    data.frame(ligand = u$genes[1], receptor = u$genes[2], stringsAsFactors = FALSE),
    data.frame(ligand = sprintf("ABS%04d", 1:2000),
               receptor = sprintf("ABS%04d", 1:2000), stringsAsFactors = FALSE))
  obj <- build_spatial_graph(tf_container("spe", u), method = "knn", k = 6,
                             graph_name = "g")
  n <- length(u$spots)
  # Materializing NA rows would allocate ~2000 x 400 x 8 bytes; the sparse
  # scorable-only representation allocates nothing near that.
  threshold <- floor(2000 * n * 8 * 0.5)
  tf <- tempfile(fileext = ".out"); on.exit(unlink(tf), add = TRUE)
  utils::Rprofmem(tf, threshold = threshold)
  score_lr_activity(obj, pairs = lr, graph = "g", assay = "logcounts", layer = NULL)
  utils::Rprofmem(NULL)
  lines <- if (file.exists(tf)) readLines(tf, warn = FALSE) else character(0)
  nums <- suppressWarnings(as.numeric(sub("^([0-9]+).*$", "\\1", lines)))
  expect_length(lines[!is.na(nums) & nums >= threshold], 0)
})

test_that("L-R manifest records reproducible, definition-aware provenance", {
  skip_if_not_implemented("build_spatial_graph", "score_lr_activity", ".get_registry")
  skip_if_not_installed("SpatialExperiment")
  u <- tf_universe(); lr <- tf_lr_pairs(u$genes)
  build <- function() build_spatial_graph(tf_container("spe", u), method = "knn",
                                          k = 4, graph_name = "g")
  obj <- score_lr_activity(build(), pairs = lr, graph = "g", assay = "logcounts",
                           layer = NULL, chunk_size = 2, database = "MatriComDB")
  p <- mfn(".get_registry")(obj)$artifacts$lr_activity$parameters
  man <- mfn(".get_registry")(obj)$artifacts$lr_activity
  expect_equal(man$producer, "score_lr_activity")
  expect_equal(man$input_assay, "logcounts")
  expect_equal(man$type, "activity")
  expect_equal(p$graph, "g")
  expect_true(nzchar(p$graph_fingerprint))
  expect_equal(p$weight, "row_standardize")
  expect_false(p$directed)
  expect_equal(p$n_missing, 0L)
  expect_equal(p$database, "MatriComDB")
  expect_equal(p$chunk_size, 2L)
  expect_equal(p$chunk_size_effective, min(2L, nrow(lr)))   # not oversized
  expect_true(p$materialized)                              # physical result present
  # Digest sensitivity: a different pair set -> a different digest.
  p2 <- mfn(".get_registry")(score_lr_activity(build(),
          pairs = data.frame(ligand = u$genes[2], receptor = u$genes[11]),
          graph = "g", assay = "logcounts", layer = NULL))$artifacts$lr_activity$parameters
  expect_false(identical(p$pair_digest, p2$pair_digest))
})

test_that("pair id is collision-resistant and the digest preserves associations", {
  skip_if_not_implemented(".lr_pair_id", ".lr_pairs_digest")
  id <- mfn(".lr_pair_id"); dg <- mfn(".lr_pairs_digest")
  # ("a__b","c") vs ("a","b__c") -> distinct machine ids (display would collide).
  expect_false(identical(id("a__b", "c"), id("a", "b__c")))
  # Crossed pairs differ; pair order does not matter.
  expect_false(identical(dg(c("L1", "L2"), c("R1", "R2")),
                         dg(c("L1", "L2"), c("R2", "R1"))))
  expect_equal(dg(c("L1", "L2"), c("R1", "R2")),
               dg(c("L2", "L1"), c("R2", "R1")))
})

test_that("colliding-display tuples score, store, retrieve, and enrich distinctly", {
  skip_if_not_implemented("build_spatial_graph", "score_lr_activity", "get_lr_activity",
                          "find_lr_enrichment")
  skip_if_not_installed("SpatialExperiment")
  # genes named so ("a__b","c") and ("a","b__c") both display as "a__b__c".
  spots <- c("s1", "s2"); coords <- cbind(x = c(0, 1), y = 0); rownames(coords) <- spots
  m <- rbind(`a__b` = c(2, 1), c = c(3, 4), a = c(1, 2), `b__c` = c(4, 3))
  colnames(m) <- spots
  spe <- SpatialExperiment::SpatialExperiment(assays = list(logcounts = m),
    spatialCoords = coords, colData = S4Vectors::DataFrame(group = c("A", "B"),
    row.names = spots), sample_id = rep("img", 2))
  obj <- build_spatial_graph(spe, method = "radius", radius = 1.5, graph_name = "g")
  lr <- data.frame(ligand = c("a__b", "a"), receptor = c("c", "b__c"),
                   stringsAsFactors = FALSE)
  obj <- score_lr_activity(obj, pairs = lr, graph = "g", assay = "logcounts", layer = NULL)
  act <- get_lr_activity(obj)
  expect_equal(nrow(act), 2L)                        # two distinct rows, no collision
  expect_equal(length(unique(rownames(act))), 2L)
  res <- find_lr_enrichment(obj, group_by = "group")
  expect_equal(length(unique(res$pair_id)), 2L)      # distinguishable in enrichment
})

for (ct in c("spe", "seurat")) {
  test_that(sprintf("[%s] an all-missing database stores and retrieves cleanly", ct), {
    skip_if_not_implemented("build_spatial_graph", "score_lr_activity", "get_lr_activity",
                            "lr_missing_pairs", "find_lr_enrichment")
    skip_if_not_installed(if (ct == "seurat") "Seurat" else "SpatialExperiment")
    u <- tf_universe()
    lr <- data.frame(ligand = c("ABS1", "ABS2"), receptor = c("ABS3", "ABS4"),
                     stringsAsFactors = FALSE)
    args <- tf_expr_args(ct)
    obj <- build_spatial_graph(tf_container(ct, u), method = "knn", k = 4, graph_name = "g")
    obj <- do.call(score_lr_activity, c(list(obj, pairs = lr, graph = "g"), args))
    act <- get_lr_activity(obj)
    expect_equal(nrow(act), 0L)                       # nothing scorable
    expect_equal(nrow(lr_missing_pairs(obj)), 2L)     # every pair missing
    p <- mfn(".get_registry")(obj)$artifacts$lr_activity$parameters
    expect_equal(p$chunk_size_effective, 0L)          # no chunk ran
    res <- find_lr_enrichment(obj, group_by = "group")
    expect_true(all(is.na(res$mean_activity)))        # NA for all pairs
  })
}

for (ct in c("spe", "seurat")) {
  test_that(sprintf("[%s] rescoring all-missing removes the stale physical result", ct), {
    skip_if_not_implemented("build_spatial_graph", "score_lr_activity", "get_lr_activity",
                            "lr_missing_pairs")
    skip_if_not_installed(if (ct == "seurat") "Seurat" else "SpatialExperiment")
    u <- tf_universe(); args <- tf_expr_args(ct)
    akey <- mfn(".key_feature_result")("lr_activity")
    has_phys <- function(o) {
      if (ct == "seurat") akey %in% SeuratObject::Assays(o)
      else akey %in% SingleCellExperiment::altExpNames(o)
    }
    obj <- build_spatial_graph(tf_container(ct, u), method = "knn", k = 4, graph_name = "g")
    obj <- do.call(score_lr_activity, c(list(obj, pairs = tf_lr_pairs(u$genes),
                                             graph = "g"), args))
    expect_true(has_phys(obj))                        # physical exists after scoring

    # Rescore with an all-missing database.
    obj <- do.call(score_lr_activity, c(list(obj,
             pairs = data.frame(ligand = c("ABS1", "ABS2"),
                                receptor = c("ABS3", "ABS4"), stringsAsFactors = FALSE),
             graph = "g"), args))
    expect_false(has_phys(obj))                       # stale physical removed
    expect_equal(nrow(get_lr_activity(obj)), 0L)      # accessor returns empty
    expect_equal(nrow(lr_missing_pairs(obj)), 2L)
    p <- mfn(".get_registry")(obj)$artifacts$lr_activity$parameters
    expect_false(p$materialized)
  })
}

test_that("all-missing accessors survive host subsetting", {
  skip_if_not_implemented("build_spatial_graph", "score_lr_activity", "get_lr_activity",
                          "find_lr_enrichment")
  skip_if_not_installed("SpatialExperiment")
  u <- tf_universe()
  obj <- build_spatial_graph(tf_container("spe", u), method = "knn", k = 4, graph_name = "g")
  obj <- score_lr_activity(obj, pairs = data.frame(ligand = "ABS1", receptor = "ABS2"),
                           graph = "g", assay = "logcounts", layer = NULL)
  sub <- obj[, u$spots[1:10]]
  act <- get_lr_activity(sub)
  expect_equal(nrow(act), 0L)
  expect_setequal(colnames(act), u$spots[1:10])       # synthesized empty adapts to subset
  expect_s3_class(find_lr_enrichment(sub, group_by = "group"), "data.frame")
})

test_that("empty-string group labels are treated as absent", {
  skip_if_not_implemented("build_spatial_graph", "score_lr_activity", "find_lr_enrichment")
  skip_if_not_installed("SpatialExperiment")
  u <- tf_universe(); lr <- tf_lr_pairs(u$genes)
  obj <- build_spatial_graph(tf_container("spe", u), method = "knn", k = 4, graph_name = "g")
  obj <- score_lr_activity(obj, pairs = lr, graph = "g", assay = "logcounts", layer = NULL)
  obj$group <- ""
  expect_equal(nrow(find_lr_enrichment(obj, group_by = "group")), 0L)
})

test_that("find_lr_enrichment returns a typed empty table when all labels are NA", {
  skip_if_not_implemented("build_spatial_graph", "score_lr_activity", "find_lr_enrichment")
  skip_if_not_installed("SpatialExperiment")
  u <- tf_universe(); lr <- tf_lr_pairs(u$genes)
  obj <- build_spatial_graph(tf_container("spe", u), method = "knn", k = 4, graph_name = "g")
  obj <- score_lr_activity(obj, pairs = lr, graph = "g", assay = "logcounts", layer = NULL)
  obj$group <- NA_character_                          # wipe all group labels
  res <- find_lr_enrichment(obj, group_by = "group")
  expect_s3_class(res, "data.frame")                  # not NULL
  expect_equal(nrow(res), 0L)
})

test_that("score_lr_activity rejects empty pairs, bad database, and non-finite input", {
  skip_if_not_implemented("build_spatial_graph", "score_lr_activity")
  skip_if_not_installed("SpatialExperiment")
  u <- tf_universe()
  obj <- build_spatial_graph(tf_container("spe", u), method = "knn", k = 4, graph_name = "g")
  expect_error(score_lr_activity(obj,
    pairs = data.frame(ligand = character(0), receptor = character(0)),
    graph = "g", assay = "logcounts", layer = NULL), "empty")
  expect_error(score_lr_activity(obj, pairs = tf_lr_pairs(u$genes), graph = "g",
    assay = "logcounts", layer = NULL, database = c("a", "b")), "database")
  # Non-finite expression is rejected (negatives are allowed and truncated).
  spe <- lr_line_spe(c(0, 1), L = c(4, NA), R = c(0, 9))
  obj2 <- build_spatial_graph(spe, method = "radius", radius = 1.5, graph_name = "g")
  expect_error(score_lr_activity(obj2,
    pairs = data.frame(ligand = "L", receptor = "R"), graph = "g",
    assay = "logcounts", layer = NULL), "non-finite")
})

test_that("find_lr_enrichment reports exact per-group means and NA for missing pairs", {
  skip_if_not_implemented("build_spatial_graph", "score_lr_activity", "find_lr_enrichment")
  skip_if_not_installed("SpatialExperiment")
  # activity = c(s1=0, s2=6); group A = s1, group B = s2 (see the orientation
  # oracle). Plus a missing pair that must report NA.
  spe <- lr_two_spot_spe(c(4, 0), c(0, 9))
  obj <- build_spatial_graph(spe, method = "radius", radius = 1.5, graph_name = "g")
  lr <- data.frame(ligand = c("L", "ABSENT"), receptor = c("R", "R"),
                   stringsAsFactors = FALSE)
  obj <- score_lr_activity(obj, pairs = lr, graph = "g", assay = "logcounts", layer = NULL)
  res <- find_lr_enrichment(obj, group_by = "group")
  expect_equal(res$mean_activity[res$pair == "L__R" & res$group == "A"], 0, tolerance = TOL)
  expect_equal(res$mean_activity[res$pair == "L__R" & res$group == "B"], 6, tolerance = TOL)
  expect_true(all(is.na(res$mean_activity[res$pair == "ABSENT__R"])))   # missing -> NA
})

test_that("chunked scoring equals unchunked scoring", {
  skip_if_not_implemented("build_spatial_graph", "score_lr_activity", "get_lr_activity")
  skip_if_not_installed("SpatialExperiment")
  u <- tf_universe(); lr <- tf_lr_pairs(u$genes)
  obj <- build_spatial_graph(tf_container("spe", u), method = "knn", k = 4,
                             graph_name = "g")
  a <- get_lr_activity(score_lr_activity(obj, pairs = lr, graph = "g",
       assay = "logcounts", layer = NULL))
  b <- get_lr_activity(score_lr_activity(obj, pairs = lr, graph = "g",
       chunk_size = 1, assay = "logcounts", layer = NULL))
  expect_equal(as.matrix(a), as.matrix(b), tolerance = TOL)
})

test_that("L-R scoring never allocates a dense adjacency/expression", {
  skip_if_not_implemented("build_spatial_graph", "score_lr_activity")
  skip_if_not_installed("SpatialExperiment")
  skip_if(!capabilities("profmem"), "no memory profiling")
  u <- tf_universe(n_genes = 50, n_spots = 400, n_images = 1)
  lr <- tf_lr_pairs(u$genes)
  obj <- build_spatial_graph(tf_container("spe", u), method = "knn", k = 6,
                             graph_name = "g")
  n <- length(u$spots)
  threshold <- n * n * 8                          # a dense n x n adjacency
  tf <- tempfile(fileext = ".out"); on.exit(unlink(tf), add = TRUE)
  utils::Rprofmem(tf, threshold = threshold)
  score_lr_activity(obj, pairs = lr, graph = "g", assay = "logcounts", layer = NULL)
  utils::Rprofmem(NULL)
  lines <- if (file.exists(tf)) readLines(tf, warn = FALSE) else character(0)
  nums <- suppressWarnings(as.numeric(sub("^([0-9]+).*$", "\\1", lines)))
  expect_length(lines[!is.na(nums) & nums >= threshold], 0)
})

test_that("find_lr_enrichment does not mutate the object", {
  skip_if_not_implemented("build_spatial_graph", "score_lr_activity", "find_lr_enrichment")
  skip_if_not_installed("SpatialExperiment")
  u <- tf_universe(); lr <- tf_lr_pairs(u$genes)
  obj <- build_spatial_graph(tf_container("spe", u), method = "knn", k = 4,
                             graph_name = "g")
  obj <- score_lr_activity(obj, pairs = lr, graph = "g", assay = "logcounts", layer = NULL)
  snap <- obj
  res <- find_lr_enrichment(obj, group_by = "group")
  expect_equal(obj, snap)                       # pure consumer
  expect_s3_class(res, "data.frame")
})

test_that("score_lr_activity consumes a named graph and returns the object", {
  skip_if_not_implemented("build_spatial_graph", "score_lr_activity")
  skip_if_not_installed("SpatialExperiment")
  u <- tf_universe(); lr <- tf_lr_pairs(u$genes)
  obj <- build_spatial_graph(tf_container("spe", u), method = "knn", k = 4,
                             graph_name = "g")
  obj2 <- score_lr_activity(obj, pairs = lr, graph = "g", assay = "logcounts",
                            layer = NULL)
  expect_s4_class(obj2, class(obj))
})

test_that("L-R activity is stored as a feature result discoverable via registry", {
  skip_if_not_implemented("build_spatial_graph", "score_lr_activity",
                          "get_lr_activity")
  skip_if_not_installed("SpatialExperiment")
  u <- tf_universe(); lr <- tf_lr_pairs(u$genes)
  obj <- build_spatial_graph(tf_container("spe", u), method = "knn", k = 4,
                             graph_name = "g")
  obj <- score_lr_activity(obj, pairs = lr, graph = "g", assay = "logcounts", layer = NULL)
  act <- get_lr_activity(obj)
  expect_setequal(colnames(act), u$spots)
  expect_equal(nrow(act), nrow(lr))
})

test_that("no hardcoded 6-neighbour assumption: graph choice changes the result", {
  skip_if_not_implemented("build_spatial_graph", "score_lr_activity", "get_lr_activity")
  skip_if_not_installed("SpatialExperiment")
  u <- tf_universe(n_spots = 36, n_images = 1); lr <- tf_lr_pairs(u$genes)
  obj <- tf_container("spe", u)
  obj <- build_spatial_graph(obj, method = "knn", k = 3, graph_name = "k3")
  obj <- build_spatial_graph(obj, method = "knn", k = 8, graph_name = "k8")

  a <- get_lr_activity(score_lr_activity(obj, pairs = lr, graph = "k3",
       assay = "logcounts", layer = NULL))
  b <- get_lr_activity(score_lr_activity(obj, pairs = lr, graph = "k8",
       assay = "logcounts", layer = NULL))
  expect_false(isTRUE(all.equal(as.matrix(a), as.matrix(b))))
})

test_that("L-R activity is reorder-safe (aligned by spot id)", {
  skip_if_not_implemented("build_spatial_graph", "score_lr_activity", "get_lr_activity")
  skip_if_not_installed("SpatialExperiment")
  u <- tf_universe(); lr <- tf_lr_pairs(u$genes)
  obj <- build_spatial_graph(tf_container("spe", u), method = "knn", k = 4,
                             graph_name = "g")

  a <- get_lr_activity(score_lr_activity(obj, pairs = lr, graph = "g",
       assay = "logcounts", layer = NULL))
  perm <- rev(seq_len(ncol(obj)))
  obj_p <- build_spatial_graph(tf_container("spe", u)[, perm], method = "knn",
           k = 4, graph_name = "g")
  b <- get_lr_activity(score_lr_activity(obj_p, pairs = lr, graph = "g",
       assay = "logcounts", layer = NULL))
  expect_equal(as.matrix(a)[, u$spots], as.matrix(b)[, u$spots], tolerance = TOL_LOOSE)
})

test_that("find_lr_enrichment returns a terminal result table", {
  skip_if_not_implemented("build_spatial_graph", "score_lr_activity",
                          "find_lr_enrichment")
  skip_if_not_installed("SpatialExperiment")
  u <- tf_universe(); lr <- tf_lr_pairs(u$genes)
  obj <- build_spatial_graph(tf_container("spe", u), method = "knn", k = 4,
                             graph_name = "g")
  obj <- score_lr_activity(obj, pairs = lr, graph = "g", assay = "logcounts", layer = NULL)
  res <- find_lr_enrichment(obj, group_by = "group")
  expect_s3_class(res, "data.frame")
})
