# Matrisome scoring (arch doc s4, s5.4). score_* returns the modified object.
# Machine keys are separate from display labels; no duplicate display columns
# are written; results are discoverable through the registry; scores agree
# across containers; scaling is explicit (no silent SCTransform).

test_that("score_matrisome returns the object and registers a score artifact", {
  skip_if_not_implemented("score_matrisome", "has_matrisome_scores")
  skip_if_not_installed("SpatialExperiment")
  skip_if_not_installed("UCell")
  u <- tf_universe(); sig <- tf_signatures(u$genes)
  obj <- tf_container("spe", u)
  expect_false(has_matrisome_scores(obj))

  obj2 <- score_matrisome(obj, signatures = sig$signatures, assay = "logcounts",
                          layer = NULL)
  expect_s4_class(obj2, class(obj))
  expect_true(has_matrisome_scores(obj2))
})

test_that("scores use stable machine keys, not display labels", {
  skip_if_not_implemented("score_matrisome", "get_matrisome_scores")
  skip_if_not_installed("SpatialExperiment")
  skip_if_not_installed("UCell")
  u <- tf_universe(); sig <- tf_signatures(u$genes)
  obj <- score_matrisome(tf_container("spe", u), signatures = sig$signatures,
                         assay = "logcounts", layer = NULL)
  scores <- get_matrisome_scores(obj)
  # Rows/cols keyed by signature keys x spots.
  expect_true(all(names(sig$signatures) %in% rownames(scores)))
  expect_setequal(colnames(scores), u$spots)
})

test_that("no duplicate human-facing display columns leak into spot metadata", {
  skip_if_not_implemented("score_matrisome", ".get_spot_metadata")
  skip_if_not_installed("SpatialExperiment")
  skip_if_not_installed("UCell")
  u <- tf_universe(); sig <- tf_signatures(u$genes)
  obj <- score_matrisome(tf_container("spe", u), signatures = sig$signatures,
                         assay = "logcounts", layer = NULL)
  md_cols <- colnames(mfn(".get_spot_metadata")(obj))
  # The legacy pattern wrote a spaced display column ("Collagens") AND a raw
  # UCell column. Neither should appear as a duplicate metadata column.
  expect_false(any(unname(sig$labels) %in% md_cols))
  expect_false(any(paste0(names(sig$signatures), "_UCell") %in% md_cols))
})

test_that("identical scores across Seurat and SpatialExperiment", {
  skip_if_not_implemented("score_matrisome", "get_matrisome_scores")
  skip_if_not_installed("Seurat")
  skip_if_not_installed("SpatialExperiment")
  skip_if_not_installed("UCell")
  u <- tf_universe(); sig <- tf_signatures(u$genes)

  s_args <- tf_expr_args("seurat"); e_args <- tf_expr_args("spe")
  s <- get_matrisome_scores(do.call(score_matrisome, c(
       list(tf_container("seurat", u), signatures = sig$signatures), s_args)))
  e <- get_matrisome_scores(do.call(score_matrisome, c(
       list(tf_container("spe", u), signatures = sig$signatures), e_args)))
  keys <- names(sig$signatures)
  expect_equal(as.matrix(s)[keys, u$spots], as.matrix(e)[keys, u$spots],
               tolerance = TOL_LOOSE)
})

test_that("score_matrisome rejects a non-normalized or non-finite scale", {
  skip_if_not_implemented("score_matrisome")
  skip_if_not_installed("SpatialExperiment")
  skip_if_not_installed("UCell")
  u <- tf_universe(); sig <- tf_signatures(u$genes)
  make <- function(val) {
    uu <- u; d <- as.matrix(u$logcounts); d[1, 1] <- val
    uu$logcounts <- Matrix::Matrix(d, sparse = TRUE); tf_spe(uu)
  }
  expect_error(score_matrisome(make(-1), signatures = sig$signatures,
               assay = "logcounts", layer = NULL), "non-negative")
  expect_error(score_matrisome(make(Inf), signatures = sig$signatures,
               assay = "logcounts", layer = NULL), "non-finite")
  expect_error(score_matrisome(make(NA_real_), signatures = sig$signatures,
               assay = "logcounts", layer = NULL), "non-finite")
})

test_that("score_matrisome validates min_genes and maxRank", {
  skip_if_not_implemented("score_matrisome")
  skip_if_not_installed("SpatialExperiment")
  skip_if_not_installed("UCell")
  u <- tf_universe(); sig <- tf_signatures(u$genes); obj <- tf_container("spe", u)
  expect_error(score_matrisome(obj, signatures = sig$signatures, assay = "logcounts",
                               min_genes = 0), "min_genes")
  expect_error(score_matrisome(obj, signatures = sig$signatures, assay = "logcounts",
                               maxRank = 1.5), "maxRank")
  expect_error(score_matrisome(obj, signatures = sig$signatures, assay = "logcounts",
                               maxRank = 2^31), "maxRank")   # integer overflow
})

test_that(".definition_digest is order-invariant but gene-set-sensitive", {
  skip_if_not_implemented(".definition_digest")
  d <- mfn(".definition_digest")
  a  <- list(x = c("G1", "G2"), y = c("G3", "G4"))
  b  <- list(y = c("G4", "G3"), x = c("G2", "G1"))       # reordered keys + genes
  cc <- list(x = c("G1", "G9"), y = c("G3", "G4"))       # one gene changed
  expect_equal(d(a), d(b))
  expect_false(identical(d(a), d(cc)))
  # Nested marker definitions: reordered niches AND roles -> same digest.
  m1 <- list(N1 = list(positive = "G1", negative = "G2"),
             N2 = list(positive = "G3", negative = "G4"))
  m2 <- list(N2 = list(negative = "G4", positive = "G3"),
             N1 = list(negative = "G2", positive = "G1"))
  expect_equal(d(m1), d(m2))
})

test_that("score_matrisome rejects signatures with NA or empty gene names", {
  skip_if_not_implemented("score_matrisome")
  skip_if_not_installed("SpatialExperiment")
  skip_if_not_installed("UCell")
  u <- tf_universe(); obj <- tf_container("spe", u)
  expect_error(score_matrisome(obj, signatures = list(collagens = c(u$genes[1], NA)),
                               assay = "logcounts", layer = NULL), "NA or empty")
  expect_error(score_matrisome(obj, signatures = list(collagens = c(u$genes[1], "")),
                               assay = "logcounts", layer = NULL), "NA or empty")
})

test_that("score_matrisome records reproducible, definition-aware provenance", {
  skip_if_not_implemented("score_matrisome", ".get_registry")
  skip_if_not_installed("SpatialExperiment")
  skip_if_not_installed("UCell")
  u <- tf_universe()
  m1 <- mfn(".get_registry")(score_matrisome(tf_spe(u),
          signatures = list(collagens = u$genes[1:5]),
          assay = "logcounts", layer = NULL))$artifacts$matrisome
  m2 <- mfn(".get_registry")(score_matrisome(tf_spe(u),
          signatures = list(collagens = u$genes[6:10]),
          assay = "logcounts", layer = NULL))$artifacts$matrisome

  # Same key, different gene sets -> distinguishable provenance.
  expect_false(identical(m1$parameters$signature_digest,
                         m2$parameters$signature_digest))
  # Direct manifest field assertions (previously unchecked).
  expect_equal(m1$producer, "score_matrisome")
  expect_equal(m1$input_assay, "logcounts")
  expect_equal(m1$type, "score")
  expect_equal(unname(m1$parameters$matched_genes[["collagens"]]), 5L)
})

test_that("scoring does not silently normalise (explicit layer required)", {
  skip_if_not_implemented("score_matrisome")
  skip_if_not_installed("SpatialExperiment")
  skip_if_not_installed("UCell")
  u <- tf_universe(); sig <- tf_signatures(u$genes)
  obj <- tf_container("spe", u)
  before <- SummarizedExperiment::assayNames(
    score_matrisome(obj, signatures = sig$signatures, assay = "logcounts", layer = NULL))
  # No SCTransform / new normalisation assay is created as a side effect.
  expect_false("SCT" %in% before)
})

test_that("ECM-niche signature scoring is a named specialization of UCell scoring", {
  skip_if_not_installed("SpatialExperiment")
  skip_if_not_installed("UCell")
  u <- tf_universe(); sig <- tf_signatures(u$genes)$signatures
  a <- score_ecm_niche_signatures(tf_spe(u), signatures = sig,
                                  assay = "logcounts", layer = NULL)
  b <- score_matrisome(tf_spe(u), signatures = sig,
                       assay = "logcounts", layer = NULL)
  expect_equal(as.matrix(get_ecm_niche_signature_scores(a)),
               as.matrix(get_matrisome_scores(b)), tolerance = TOL_LOOSE)
  reg <- mfn(".get_registry")(a)
  expect_true("ecm_niche_signature_scores" %in% names(reg$artifacts))
  expect_equal(reg$artifacts$ecm_niche_signature_scores$producer,
               "score_ecm_niche_signatures")
})

test_that("continuous niche scores and classification scores never overwrite", {
  skip_if_not_installed("SpatialExperiment")
  skip_if_not_installed("UCell")
  u <- tf_universe(); sig <- tf_signatures(u$genes)$signatures
  obj <- score_ecm_niche_signatures(tf_spe(u), signatures = sig,
                                    assay = "logcounts", layer = NULL)
  obj <- annotate_ecm_niches(obj, markers = tf_markers(u$genes),
                             assay = "logcounts", layer = NULL)
  reg <- mfn(".get_registry")(obj)
  expect_true(all(c("ecm_niche_signature_scores",
                    "ecm_niche_classification_scores") %in% names(reg$artifacts)))
  expect_equal(ncol(get_ecm_niche_signature_scores(obj)), ncol(obj))
  expect_equal(ncol(get_ecm_niche_classification_scores(obj)), ncol(obj))
})
