# Discoverability API (FIX_GUIDE s5): manifest listing/filtering, niche mode
# availability, and the score/annotate selector contract (custom vs bundled
# selection, requested order, conflicting/unknown/empty selectors, and overwrite
# fingerprinting across two bundled selections).

# ---- manifest listing + filtering -------------------------------------------

test_that("list_matrisome_signatures returns the manifest with the documented schema", {
  skip_if_not_implemented("list_matrisome_signatures")
  m <- list_matrisome_signatures()
  expect_s3_class(m, "data.frame")
  expect_identical(names(m), c("key", "label", "level", "category", "n_genes",
                               "reference_version"))
  expect_setequal(m$key, names(matrisome_signatures))
  expect_true(all(m$n_genes > 0L))
  expect_true(all(m$level %in% c("category", "subcategory")))
  # The six broad ECM categories are present and flagged as such.
  expect_setequal(m$key[m$level == "category"],
                  c("ecm_glycoproteins", "collagens", "proteoglycans",
                    "ecm_regulators", "secreted_factors", "ecm_affiliated_proteins"))
})

test_that("list_matrisome_signatures filters by level and category", {
  skip_if_not_implemented("list_matrisome_signatures")
  cats <- list_matrisome_signatures(level = "category")
  expect_true(all(cats$level == "category"))
  expect_equal(nrow(cats), 6L)

  subs <- list_matrisome_signatures(level = "subcategory")
  expect_true(all(subs$level == "subcategory"))
  expect_gt(nrow(subs), 0L)
  expect_equal(nrow(cats) + nrow(subs), nrow(list_matrisome_signatures()))

  # Category filter (case-insensitive) keeps the collagens category itself.
  coll <- list_matrisome_signatures(category = "collagens")
  expect_true("collagens" %in% coll$key)
  expect_true(all(grepl("Collagens", coll$category)))

  expect_error(list_matrisome_signatures(level = "family"), "level")
})

# ---- niche mode availability ------------------------------------------------

test_that("list_ecm_niches shows continuous vs classification availability", {
  skip_if_not_implemented("list_ecm_niches")
  all_n <- list_ecm_niches()
  expect_identical(names(all_n), c("niche", "continuous", "classification"))
  expect_setequal(all_n$niche, union(names(ecm_markers), names(ecm_signatures)))

  # vascular is classification-only in the current reference snapshot.
  vasc <- all_n[all_n$niche == "vascular", ]
  expect_false(vasc$continuous)
  expect_true(vasc$classification)

  cont <- list_ecm_niches(mode = "continuous")
  expect_true(all(cont$continuous))
  expect_false("vascular" %in% cont$niche)

  clas <- list_ecm_niches(mode = "classification")
  expect_true(all(clas$classification))
  expect_true("vascular" %in% clas$niche)

  expect_error(list_ecm_niches(mode = "nonsense"))
})

# ---- selector contract on score_matrisome -----------------------------------

# A universe whose genes are real bundled signature symbols, so `include=` scores
# actually match and store non-NA rows.
bundled_universe <- function() {
  g <- unique(c(matrisome_signatures$collagens[1:6],
                matrisome_signatures$proteoglycans[1:6]))
  tf_universe(genes = g, n_genes = length(g))
}

test_that("include selects bundled signatures in the requested order", {
  skip_if_not_installed("SpatialExperiment")
  skip_if_not_installed("UCell")
  u <- bundled_universe()
  obj <- score_matrisome(tf_spe(u), include = c("proteoglycans", "collagens"),
                         assay = "logcounts", layer = NULL)
  sc <- get_matrisome_scores(obj)
  expect_equal(rownames(sc), c("proteoglycans", "collagens"))   # requested order
})

test_that("omitting both signatures and include scores all bundled keys", {
  skip_if_not_installed("SpatialExperiment")
  skip_if_not_installed("UCell")
  u <- bundled_universe()
  obj <- suppressWarnings(
    score_matrisome(tf_spe(u), assay = "logcounts", layer = NULL))
  expect_setequal(rownames(get_matrisome_scores(obj)),
                  names(matrisome_signatures))
})

test_that("custom signatures still work and are mutually exclusive with include", {
  skip_if_not_installed("SpatialExperiment")
  skip_if_not_installed("UCell")
  u <- tf_universe(); sig <- tf_signatures(u$genes)$signatures
  obj <- score_matrisome(tf_spe(u), signatures = sig, assay = "logcounts",
                         layer = NULL)
  expect_setequal(rownames(get_matrisome_scores(obj)), names(sig))

  expect_error(
    score_matrisome(tf_spe(u), signatures = sig, include = "collagens",
                    assay = "logcounts", layer = NULL),
    "exactly one of")
})

test_that("unknown, duplicate, and empty selectors give focused errors", {
  skip_if_not_installed("SpatialExperiment")
  u <- tf_universe(); obj <- tf_spe(u)
  expect_error(
    score_matrisome(obj, include = c("collagens", "not_a_key"),
                    assay = "logcounts", layer = NULL),
    "unknown matrisome signature")
  expect_error(
    score_matrisome(obj, include = c("collagens", "collagens"),
                    assay = "logcounts", layer = NULL),
    "duplicate")
  expect_error(
    score_matrisome(obj, include = character(0), assay = "logcounts",
                    layer = NULL),
    "non-empty")
})

test_that("niche selectors work for continuous scoring and classification", {
  skip_if_not_installed("SpatialExperiment")
  skip_if_not_installed("UCell")
  u <- bundled_universe()
  # Continuous scoring only offers niches present in ecm_signatures.
  expect_error(
    score_ecm_niche_signatures(tf_spe(u), niches = "vascular",
                               assay = "logcounts", layer = NULL),
    "unknown ECM niche")
  # Classification offers vascular; build a universe whose genes match its
  # positive markers so the ScType kernel has something to score.
  vg <- unique(ecm_markers$vascular$positive[1:8])
  uv <- tf_universe(genes = vg, n_genes = length(vg))
  cls <- annotate_ecm_niches(tf_spe(uv), niches = "vascular",
                             assay = "logcounts", layer = NULL)
  expect_true("vascular" %in%
                rownames(get_ecm_niche_classification_scores(cls)))
})

# ---- fingerprint interacts correctly with bundled selections ----------------

test_that("two different bundled selections are distinct under the overwrite guard", {
  skip_if_not_installed("SpatialExperiment")
  skip_if_not_installed("UCell")
  u <- bundled_universe()
  obj <- score_matrisome(tf_spe(u), include = "collagens", assay = "logcounts",
                         layer = NULL)
  # A different selection -> different fingerprint -> guarded.
  expect_error(
    score_matrisome(obj, include = "proteoglycans", assay = "logcounts",
                    layer = NULL),
    "overwrite = TRUE")
  # The identical selection -> returned untouched.
  before <- as.matrix(get_matrisome_scores(obj))
  obj2 <- score_matrisome(obj, include = "collagens", assay = "logcounts",
                          layer = NULL)
  expect_equal(as.matrix(get_matrisome_scores(obj2)), before)
})
