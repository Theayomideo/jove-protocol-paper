# Versioned registry contract (arch doc s2.1, s2.8). The registry is the
# discovery mechanism and the provenance ledger; storage names go through one
# canonical key module, never ad hoc.

test_that("a fresh registry carries schema + package version and empty slots", {
  skip_if_not_implemented(".new_registry")
  reg <- mfn(".new_registry")()

  expect_equal(reg$schema_version, "1.0.0")
  expect_true(nzchar(reg$package_version))
  expect_true(all(c("graphs", "artifacts", "history") %in% names(reg)))
  expect_length(reg$graphs, 0)
  expect_length(reg$artifacts, 0)
})

test_that("registry validation rejects a missing schema version", {
  skip_if_not_implemented(".new_registry", ".validate_registry")
  reg <- mfn(".new_registry")()
  reg$schema_version <- NULL
  expect_error(mfn(".validate_registry")(reg))
})

test_that("an unknown FUTURE schema version fails with an actionable error", {
  skip_if_not_implemented(".new_registry", ".validate_registry")
  reg <- mfn(".new_registry")()
  reg$schema_version <- "999.0.0"
  expect_error(mfn(".validate_registry")(reg), regexp = "version|schema|migrat")
})

test_that("canonical storage keys are centralised and stable", {
  skip_if_not_implemented(".key_graph", ".key_feature_result")
  # A key module owns naming; analysis code must not build names ad hoc.
  expect_type(mfn(".key_graph")("spatial_knn6"), "character")
  expect_true(grepl("spatial_knn6", mfn(".key_graph")("spatial_knn6"), fixed = TRUE))
  # Namespaced / collision-resistant.
  expect_match(mfn(".key_feature_result")("matrisome"), "matrispace", fixed = TRUE)
})

test_that("manifest validation enforces field shape and domain, not just presence", {
  skip_if_not_implemented(".new_manifest", ".validate_manifest")
  ok <- mfn(".new_manifest")(storage = "matrispace_x", layer = "data", type = "score")
  expect_silent(mfn(".validate_manifest")(ok))

  bad_type <- ok; bad_type$type <- "garbage"
  expect_error(mfn(".validate_manifest")(bad_type), regexp = "type")

  bad_storage <- ok; bad_storage$storage <- NA_character_
  expect_error(mfn(".validate_manifest")(bad_storage), regexp = "storage")

  bad_layer <- ok; bad_layer$layer <- ""
  expect_error(mfn(".validate_manifest")(bad_layer), regexp = "layer")

  bad_params <- ok; bad_params$parameters <- "not-a-list"
  expect_error(mfn(".validate_manifest")(bad_params), regexp = "parameters")
})

test_that("command history is append-only and provenance-stamped", {
  skip_if_not_implemented(".new_registry", ".registry_append_history")
  reg <- mfn(".new_registry")()
  reg <- mfn(".registry_append_history")(reg, command = "score_matrisome",
                                         params = list(assay = "RNA"))
  reg <- mfn(".registry_append_history")(reg, command = "build_spatial_graph",
                                         params = list(method = "knn", k = 6))
  expect_length(reg$history, 2)
  last <- reg$history[[2]]
  expect_equal(last$command, "build_spatial_graph")
  expect_true(!is.null(last$params))
})

test_that("in-memory migration performs a real, non-destructive field transform", {
  skip_if_not_implemented(".migrate_registry")
  # Synthetic prior-schema fixture: 0.9.0 lacks the `history` slot and carries a
  # user graph. A genuine migration must dispatch, bump the version, ADD the
  # missing field, and preserve the existing graph. (A 1.0.0 -> 1.0.0 no-op
  # cannot exercise any of this.)
  old <- list(
    schema_version  = "0.9.0",
    package_version = "0.1.9",
    graphs          = list(spatial_knn6 = list(schema_version = "0.9.0")),
    artifacts       = list()
    # note: no `history`
  )
  migrated <- mfn(".migrate_registry")(old, to = "1.0.0")

  expect_equal(migrated$schema_version, "1.0.0")     # version bumped
  expect_true("history" %in% names(migrated))         # missing field added
  expect_true(is.list(migrated$history))
  expect_true("spatial_knn6" %in% names(migrated$graphs))  # existing data preserved
})

test_that(".set_registry rejects an unknown future schema", {
  skip_if_not_implemented(".set_registry", ".new_registry")
  skip_if_not_installed("SpatialExperiment")
  obj <- tf_container("spe")
  reg <- mfn(".new_registry")(); reg$schema_version <- "999.0.0"
  expect_error(mfn(".set_registry")(obj, reg), regexp = "newer|unsupported|future")
})

test_that(".get_registry migrates a stored 0.9.0 registry before returning it", {
  skip_if_not_implemented(".get_registry", "build_spatial_graph")
  skip_if_not_installed("SpatialExperiment")
  # Build a real graph, then downgrade its registry to a raw 0.9.0 (no history)
  # and plant it directly so we exercise migrate-on-read against full validation.
  built <- build_spatial_graph(tf_container("spe"), method = "knn", k = 4,
                               graph_name = "spatial_knn6")
  reg <- mfn(".get_registry")(built)
  old <- reg; old$schema_version <- "0.9.0"; old$history <- NULL
  S4Vectors::metadata(built)$matrispace <- old

  out <- mfn(".get_registry")(built)
  expect_equal(out$schema_version, "1.0.0")          # migrated in memory
  expect_true("history" %in% names(out))              # missing field added
  expect_true("spatial_knn6" %in% names(out$graphs))  # existing graph preserved
})

test_that(".get_registry errors on an unsupported older schema", {
  skip_if_not_implemented(".get_registry")
  skip_if_not_installed("SpatialExperiment")
  obj <- tf_container("spe")
  old <- list(schema_version = "0.5.0", package_version = "0.0.9",
              graphs = list(), artifacts = list(), history = list())
  S4Vectors::metadata(obj)$matrispace <- old
  # 0.5.0 is not a known source version -> no migration path -> error.
  expect_error(mfn(".get_registry")(obj), regexp = "unsupported|migration")
})

test_that("has_matrispace_graph inspects the registry, not metadata columns", {
  skip_if_not_implemented("has_matrispace_graph", "build_spatial_graph",
                          "matrispace_graphs")
  skip_if_not_installed("SpatialExperiment")
  obj <- tf_container("spe")
  expect_false(has_matrispace_graph(obj))

  # Stored graphs are now structurally validated, so use a real graph.
  obj2 <- build_spatial_graph(obj, method = "knn", k = 4, graph_name = "spatial_knn6")
  expect_true(has_matrispace_graph(obj2))
  expect_true("spatial_knn6" %in% matrispace_graphs(obj2))
})
