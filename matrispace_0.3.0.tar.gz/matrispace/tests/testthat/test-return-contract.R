# Return-shape contract (arch doc s3 amendment). One rule table governs every
# public function by verb prefix:
#   build_*/score_*/annotate_* -> return the modified host object
#   compute_*/find_*/compare_*/test_* -> return a standalone tidy result table
#   plot_*                     -> return a ggplot
#   get_*/has_*                -> inspect stored state without mutation

test_that("build_/score_/annotate_ return the same container class in, out", {
  skip_if_not_installed("SpatialExperiment")
  u <- tf_universe(); sig <- tf_signatures(u$genes); mk <- tf_markers(u$genes)
  obj <- tf_container("spe", u)

  cases <- list(
    list("build_spatial_graph", function(o) build_spatial_graph(o, method = "knn", k = 4, graph_name = "g")),
    list("score_matrisome",     function(o) score_matrisome(o, signatures = sig$signatures, assay = "logcounts", layer = NULL)),
    list("score_ecm_niche_signatures", function(o) score_ecm_niche_signatures(
      o, signatures = sig$signatures, assay = "logcounts", layer = NULL)),
    list("annotate_ecm_niches", function(o) annotate_ecm_niches(o, markers = mk, assay = "logcounts", layer = NULL))
  )
  ran <- FALSE
  for (cs in cases) {
    if (!rewrite_loaded() || !fn_exists(cs[[1]])) next
    if (startsWith(cs[[1]], "score_") && !requireNamespace("UCell", quietly = TRUE)) next
    ran <- TRUE
    out <- cs[[2]](obj)
    expect_s4_class(out, class(obj))
  }
  if (!ran) skip("no build_/score_/annotate_ functions implemented yet")
})

test_that("compute_/find_/compare_/test_ return standalone result tables", {
  skip_if_not_installed("SpatialExperiment")
  u <- tf_universe()
  obj <- tf_container("spe", u)
  ran <- FALSE

  if (rewrite_loaded() && fn_exists("compute_morans_i") && fn_exists("build_spatial_graph")) {
    ran <- TRUE
    g <- build_spatial_graph(obj, method = "knn", k = 4, graph_name = "g")
    res <- compute_morans_i(g, features = u$genes[1:2], graph = "g", n_perm = 19, seed = 1)
    expect_s3_class(res, "data.frame")
  }
  if (rewrite_loaded() && fn_exists("compare_ecm_groups")) {
    ran <- TRUE
    res <- compare_ecm_groups(obj, group_by = "group", ident.1 = "A", ident.2 = "B",
                              assay = "logcounts", layer = NULL,
                              matrisome = u$genes[1:3])
    expect_s3_class(res, "data.frame")
  }
  if (!ran) skip("no compute_/find_ functions implemented yet")
})

test_that("get_/has_ inspect without mutating the object", {
  skip_if_not_installed("SpatialExperiment")
  u <- tf_universe()
  obj <- tf_container("spe", u)

  if (!rewrite_loaded() || !fn_exists("has_matrispace_graph")) {
    skip("inspectors not implemented yet")
  }
  snapshot <- obj
  invisible(has_matrispace_graph(obj))
  invisible(matrispace_graphs(obj))
  expect_equal(obj, snapshot)
})
