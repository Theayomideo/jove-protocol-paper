# Regression tests for the real-data-audit FIX_GUIDE: spatial orientation
# (top-left origin, y reversed), metadata factor-level preservation, assay/layer
# diagnostics, readable LR heatmap labels, and the targeted-scoring overwrite
# guard + subset getters. Behavioural where possible (built plot state, not just
# `inherits(p, "ggplot")`).

# ---- s1: spatial orientation ------------------------------------------------

# TRUE when the plot carries a reversed continuous y scale (across ggplot2
# versions the transform lives in $transformation (>=3.5) or $trans).
has_reverse_y <- function(p) {
  any(vapply(p$scales$scales, function(s) {
    if (!("y" %in% s$aesthetics)) return(FALSE)
    tr <- s$transformation %||% s$trans
    !is.null(tr) && identical(tr$name, "reverse")
  }, logical(1)))
}

test_that("spatial, blend, and LISA plots honor explicit top-left orientation", {
  skip_if_not_implemented("plot_spatial", "plot_blend", "plot_lisa")
  skip_if_not_installed("SpatialExperiment")
  skip_if_not_installed("ggplot2")
  u <- tf_universe(); obj <- tf_container("spe", u)

  ps <- plot_spatial(obj, feature = u$genes[1], flip_y = TRUE)
  expect_true(has_reverse_y(ps))
  expect_equal(ps$coordinates$ratio, 1)              # aspect ratio still honest

  expect_true(has_reverse_y(plot_blend(obj, u$genes[1], u$genes[2], flip_y = TRUE)))

  gr <- build_spatial_graph(obj, method = "knn", k = 3, graph_name = "g")
  li <- compute_lisa(gr, feature1 = u$genes[1], graph = "g", n_perm = 19)
  expect_true(has_reverse_y(plot_lisa(gr, li, flip_y = TRUE)))
})

test_that("automatic orientation distinguishes Cartesian and image coordinates", {
  skip_if_not_installed("SpatialExperiment")
  u <- tf_universe(); plain <- tf_container("spe", u)
  expect_false(has_reverse_y(plot_spatial(plain, u$genes[1])))
  expect_true(has_reverse_y(plot_spatial(plain, u$genes[1], flip_y = TRUE)))
})

test_that("the smallest-y spot renders above the largest-y spot", {
  skip_if_not_implemented("plot_spatial")
  skip_if_not_installed("SpatialExperiment")
  skip_if_not_installed("ggplot2")
  # Asymmetric coordinates so a vertical reflection is detectable: build the
  # plot, then read back each spot's device y position after the reverse scale.
  coords <- cbind(x = c(0, 0, 0), y = c(0, 5, 20))
  rownames(coords) <- c("lo", "mid", "hi")
  spe <- tf_spe_from_coords(coords)
  p <- plot_spatial(spe, feature = "g1", flip_y = TRUE)
  b <- ggplot2::ggplot_build(p)
  # b$data[[1]] rows align with b$plot$data rows; $y is post-(reverse-)transform.
  data_y <- b$plot$data$y                              # original spatial y
  panel_y <- b$data[[1]]$y                             # transformed panel y
  # After scale_y_reverse, the smallest DATA y maps to the LARGEST panel y (top).
  expect_gt(panel_y[which.min(data_y)], panel_y[which.max(data_y)])
})

# ---- s2: metadata factor-level preservation ---------------------------------

# SPE with an integer-valued cluster column stored both as an ordered factor
# (levels 0..13) and as plain character (numeric-aware ordering must apply).
clustered_spe <- function() {
  u <- tf_universe(n_spots = 28)
  vals <- rep(0:13, length.out = length(u$spots))
  spe <- tf_container("spe", u)
  SummarizedExperiment::colData(spe)$clust_fac <-
    factor(as.character(vals), levels = as.character(0:13))
  SummarizedExperiment::colData(spe)$clust_chr <- as.character(vals)
  list(spe = spe, genes = u$genes)
}

test_that("plot_dotplot keeps factor levels and orders numeric text naturally", {
  skip_if_not_implemented("plot_dotplot")
  skip_if_not_installed("SpatialExperiment")
  skip_if_not_installed("ggplot2")
  cs <- clustered_spe()
  natural <- as.character(0:13)

  d_fac <- plot_dotplot(cs$spe, features = cs$genes[1:3], group_by = "clust_fac")
  expect_equal(levels(d_fac$data$group), natural)

  d_chr <- plot_dotplot(cs$spe, features = cs$genes[1:3], group_by = "clust_chr")
  expect_equal(levels(d_chr$data$group), natural)     # NOT 0,1,10,11,...,2
})

test_that("plot_violin preserves the grouping column's natural order", {
  skip_if_not_implemented("plot_violin")
  skip_if_not_installed("SpatialExperiment")
  skip_if_not_installed("ggplot2")
  cs <- clustered_spe()
  v <- plot_violin(cs$spe, feature = cs$genes[1], group_by = "clust_chr")
  expect_equal(levels(v$data$group), as.character(0:13))
})

test_that("compute_nhood_enrichment orders categories naturally, not lexically", {
  skip_if_not_implemented("build_spatial_graph", "compute_nhood_enrichment")
  skip_if_not_installed("SpatialExperiment")
  # groups "0".."10": lexical order would place "10" before "2".
  groups <- as.character(rep(c(0, 1, 2, 10), length.out = 8))
  n <- length(groups); spots <- paste0("s", seq_len(n))
  coords <- cbind(x = seq_len(n) - 1, y = 0); rownames(coords) <- spots
  cnts <- matrix(1, 2, n, dimnames = list(c("g1", "g2"), spots))
  spe <- SpatialExperiment::SpatialExperiment(
    assays = list(counts = cnts), spatialCoords = coords,
    colData = S4Vectors::DataFrame(group = groups, replicate_id = rep("r", n),
                                   row.names = spots),
    sample_id = rep("img", n))
  obj <- build_spatial_graph(spe, method = "radius", radius = 1.5, graph_name = "g")
  res <- compute_nhood_enrichment(obj, group_by = "group", graph = "g",
                                  n_perm = 19, seed = 1)
  expect_equal(res$categories, c("0", "1", "2", "10"))
  expect_equal(rownames(res$count), c("0", "1", "2", "10"))
})

test_that(".group_factor keeps existing factor levels and orders numeric text", {
  skip_if_not_implemented(".group_factor")
  gf <- mfn(".group_factor")
  # An existing factor keeps its own (meaningful) declared level order verbatim.
  f <- factor(c("high", "low"), levels = c("low", "medium", "high"))
  expect_equal(levels(gf(f)), c("low", "medium", "high"))
  # Numeric-valued text orders numerically (0,1,2,10), not lexically (0,1,10,2).
  expect_equal(levels(gf(c("0", "10", "2", "1"))), c("0", "1", "2", "10"))
  expect_equal(levels(gf(c("b", "a", "c"))), c("a", "b", "c"))  # non-numeric sorts
})

# ---- s3: assay/layer diagnostics --------------------------------------------

test_that("an absent layer errors with the available layers, before feature lookup", {
  skip_if_not_implemented("plot_spatial")
  skip_if_not_installed("Seurat")
  skip_if_not_installed("ggplot2")
  u <- tf_universe(); obj <- tf_container("seurat", u)
  # The Seurat factory has assay 'Spatial' with layers counts + data. Request a
  # missing layer: the error must name the layer and the available choices, not
  # claim the feature is absent.
  err <- tryCatch(
    plot_spatial(obj, feature = u$genes[1], assay = "Spatial", layer = "pflog"),
    error = function(e) conditionMessage(e))
  expect_match(err, "no layer 'pflog'")
  expect_match(err, "available:")
  expect_no_match(err, "not found in spot metadata")
})

test_that("an absent assay errors with the available assays", {
  skip_if_not_implemented("plot_spatial")
  skip_if_not_installed("Seurat")
  u <- tf_universe(); obj <- tf_container("seurat", u)
  err <- tryCatch(
    plot_spatial(obj, feature = u$genes[1], assay = "SCT", layer = "data"),
    error = function(e) conditionMessage(e))
  expect_match(err, "assay 'SCT' not found")
})

# ---- s6: readable LR heatmap labels -----------------------------------------

test_that("plot_heatmap prefers the readable `pair` over `pair_id`", {
  skip_if_not_installed("ggplot2")
  df <- data.frame(
    pair_id = c("p1", "p2", "p1", "p2"),
    pair    = c("A -> B", "C -> D", "A -> B", "C -> D"),
    group   = c("g1", "g1", "g2", "g2"),
    mean_activity = c(1, 2, 3, 4), stringsAsFactors = FALSE)
  p <- plot_heatmap(df)
  expect_setequal(unique(p$data$row), c("A -> B", "C -> D"))
})

test_that("plot_heatmap disambiguates colliding display labels with pair_id", {
  skip_if_not_installed("ggplot2")
  # Two DISTINCT pairs share the same display label within a group: neither is a
  # true duplicate cell (pair_id differs), so the labels are disambiguated.
  df <- data.frame(
    pair_id = c("p1", "p2", "p1", "p2"),
    pair    = c("A -> B", "A -> B", "A -> B", "A -> B"),
    group   = c("g1", "g1", "g2", "g2"),
    mean_activity = c(1, 2, 3, 4), stringsAsFactors = FALSE)
  p <- plot_heatmap(df)                                # must NOT error
  expect_setequal(unique(p$data$row), c("A -> B (p1)", "A -> B (p2)"))
})

test_that("plot_heatmap still rejects genuine duplicate cells", {
  skip_if_not_installed("ggplot2")
  df <- data.frame(
    pair_id = c("p1", "p1"), pair = c("A -> B", "A -> B"),
    group = c("g1", "g1"), mean_activity = c(1, 2), stringsAsFactors = FALSE)
  expect_error(plot_heatmap(df), "duplicate row-column cell")
})

test_that("plot_heatmap preserves matrix order and declared factor levels", {
  skip_if_not_installed("ggplot2")
  m <- matrix(seq_len(6), nrow = 2,
              dimnames = list(c("10", "2"), c("10", "2", "1")))
  p <- plot_heatmap(m)
  expect_identical(levels(p$data$row), rownames(m))
  expect_identical(levels(p$data$column), colnames(m))

  df <- data.frame(
    feature = rep(c("B", "A"), 2),
    group = factor(rep(c("late", "early"), each = 2),
                   levels = c("early", "late"), ordered = TRUE),
    value = 1:4)
  p_factor <- plot_heatmap(df)
  expect_identical(levels(p_factor$data$column), c("early", "late"))
  expect_true(is.ordered(p_factor$data$column))
})

# ---- s5: targeted scoring overwrite guard + subset getters ------------------

test_that("rescoring the same object with a different definition needs overwrite", {
  skip_if_not_installed("SpatialExperiment")
  skip_if_not_installed("UCell")
  u <- tf_universe()
  obj <- score_matrisome(tf_spe(u), signatures = list(collagens = u$genes[1:5]),
                         assay = "logcounts", layer = NULL)
  # Same definition -> idempotent (allowed).
  expect_no_error(score_matrisome(obj, signatures = list(collagens = u$genes[1:5]),
                                  assay = "logcounts", layer = NULL))
  # Different definition, default overwrite = FALSE -> error.
  expect_error(
    score_matrisome(obj, signatures = list(collagens = u$genes[6:10]),
                    assay = "logcounts", layer = NULL),
    "overwrite = TRUE")
  # Explicit overwrite = TRUE -> allowed.
  expect_no_error(
    score_matrisome(obj, signatures = list(collagens = u$genes[6:10]),
                    assay = "logcounts", layer = NULL, overwrite = TRUE))
})

test_that("annotate_ecm_niches guards overwrite of a different marker definition", {
  skip_if_not_installed("SpatialExperiment")
  u <- tf_universe(); m <- tf_markers(u$genes)
  obj <- annotate_ecm_niches(tf_spe(u), markers = m, assay = "logcounts",
                             layer = NULL)
  m2 <- m; m2$interstitial$positive <- u$genes[15:18]
  expect_error(
    annotate_ecm_niches(obj, markers = m2, assay = "logcounts", layer = NULL),
    "overwrite = TRUE")
  expect_no_error(
    annotate_ecm_niches(obj, markers = m2, assay = "logcounts", layer = NULL,
                        overwrite = TRUE))
})

test_that("get_matrisome_scores returns a requested subset (ordered) or errors", {
  skip_if_not_installed("SpatialExperiment")
  skip_if_not_installed("UCell")
  u <- tf_universe(); sig <- tf_signatures(u$genes)$signatures
  obj <- score_matrisome(tf_spe(u), signatures = sig, assay = "logcounts",
                         layer = NULL)
  sub <- get_matrisome_scores(obj, signatures = c("proteoglycans", "collagens"))
  expect_equal(rownames(sub), c("proteoglycans", "collagens"))   # requested order
  expect_equal(ncol(sub), ncol(obj))
  expect_error(get_matrisome_scores(obj, signatures = "does_not_exist"),
               "unknown signatures")
})

test_that("get_ecm_niche_signature_scores supports a niche subset", {
  skip_if_not_installed("SpatialExperiment")
  skip_if_not_installed("UCell")
  u <- tf_universe(); sig <- tf_signatures(u$genes)$signatures
  obj <- score_ecm_niche_signatures(tf_spe(u), signatures = sig,
                                    assay = "logcounts", layer = NULL)
  sub <- get_ecm_niche_signature_scores(obj, niches = "collagens")
  expect_equal(rownames(sub), "collagens")
  expect_error(get_ecm_niche_signature_scores(obj, niches = "nope"),
               "unknown niches")
})

test_that("overwrite guard fingerprints parameters, not just the gene set", {
  skip_if_not_installed("SpatialExperiment")
  skip_if_not_installed("UCell")
  u <- tf_universe(); sig <- list(collagens = u$genes[1:5])
  obj <- score_matrisome(tf_spe(u), signatures = sig, assay = "logcounts",
                         layer = NULL, maxRank = 10)
  # Same genes but a DIFFERENT maxRank changes the scores -> must be guarded.
  expect_error(
    score_matrisome(obj, signatures = sig, assay = "logcounts", layer = NULL,
                    maxRank = 20), "overwrite = TRUE")
  # A byte-identical computation is returned untouched (no error, no change).
  before <- as.matrix(get_matrisome_scores(obj))
  obj2 <- score_matrisome(obj, signatures = sig, assay = "logcounts",
                          layer = NULL, maxRank = 10)
  expect_equal(as.matrix(get_matrisome_scores(obj2)), before)
})

test_that("annotate_ecm_niches guard fingerprints the threshold too", {
  skip_if_not_installed("SpatialExperiment")
  u <- tf_universe(); m <- tf_markers(u$genes)
  obj <- annotate_ecm_niches(tf_spe(u), markers = m, assay = "logcounts",
                             layer = NULL, not_assigned_threshold = 0)
  # Same markers, different threshold -> different assignments -> guarded.
  expect_error(
    annotate_ecm_niches(obj, markers = m, assay = "logcounts", layer = NULL,
                        not_assigned_threshold = 0.5), "overwrite = TRUE")
})

test_that(".group_factor drops blank levels and maps blank values to NA", {
  skip_if_not_implemented(".group_factor")
  gf <- mfn(".group_factor")
  f <- factor(c("", "A", "B", ""), levels = c("", "A", "B"))
  g <- gf(f)
  expect_equal(levels(g), c("A", "B"))                 # blank level dropped
  expect_true(all(is.na(g[c(1, 4)])))                  # blank values -> NA
  # Ordered factors keep their ordered status and remaining order.
  of <- factor(c("low", "", "high"), levels = c("", "low", "high"), ordered = TRUE)
  og <- gf(of)
  expect_true(is.ordered(og))
  expect_equal(levels(og), c("low", "high"))
})

test_that("a blank factor group does not leak an unlabeled plot category", {
  skip_if_not_implemented("plot_violin")
  skip_if_not_installed("SpatialExperiment")
  skip_if_not_installed("ggplot2")
  u <- tf_universe(n_spots = 6); spe <- tf_container("spe", u)
  SummarizedExperiment::colData(spe)$grp <-
    factor(c("A", "", "B", "A", "", "B"), levels = c("", "A", "B"))
  v <- plot_violin(spe, feature = u$genes[1], group_by = "grp")
  expect_equal(levels(v$data$group), c("A", "B"))
  expect_false("" %in% as.character(v$data$group))
})
