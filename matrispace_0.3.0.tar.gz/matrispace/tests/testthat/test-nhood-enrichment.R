# Neighbourhood enrichment (arch doc s2.4, s7 gap table). Modelled on Squidpy
# 1.8.0 `nhood_enrichment` (src/squidpy/gr/_nhood.py): a label-permutation test
# over the stored graph returning a categories x categories `zscore` and
# `count`. Because the graph is symmetric the enrichment is symmetric.

# Collinear path SPE with a `group` label per spot; radius 1.5 -> path graph.
nhood_path_spe <- function(groups, images = rep("img", length(groups))) {
  n <- length(groups); spots <- paste0("s", seq_len(n))
  coords <- cbind(x = seq_len(n) - 1, y = 0); rownames(coords) <- spots
  m <- matrix(1, 2, n, dimnames = list(c("g1", "g2"), spots))
  SpatialExperiment::SpatialExperiment(
    assays = list(counts = m), spatialCoords = coords,
    colData = S4Vectors::DataFrame(group = groups, replicate_id = rep("r", n),
                                   row.names = spots),
    sample_id = images)
}

test_that("neighbourhood count matrix matches a hand graph exactly", {
  skip_if_not_implemented("build_spatial_graph", "compute_nhood_enrichment")
  skip_if_not_installed("SpatialExperiment")
  # Path s1-s2-s3-s4 with groups A,A,B,B: edges A-A (s1-s2), A-B (s2-s3),
  # B-B (s3-s4). So count[A,A]=1, count[B,B]=1, count[A,B]=count[B,A]=1.
  obj <- build_spatial_graph(nhood_path_spe(c("A", "A", "B", "B")),
                             method = "radius", radius = 1.5, graph_name = "g")
  res <- compute_nhood_enrichment(obj, group_by = "group", graph = "g",
                                  n_perm = 19, seed = 1)
  cnt <- as.matrix(res$count)
  expect_equal(res$categories, c("A", "B"))
  expect_equal(cnt["A", "A"], 1)                # same-category not doubled
  expect_equal(cnt["B", "B"], 1)
  expect_equal(cnt["A", "B"], 1)                # cross-category once per cell
  expect_equal(cnt["B", "A"], 1)
  expect_equal(res$group_by, "group")           # provenance
})

test_that("labels permute only within images (all-A / all-B -> NA z-scores)", {
  skip_if_not_implemented("build_spatial_graph", "compute_nhood_enrichment")
  skip_if_not_installed("SpatialExperiment")
  # image1 all category A, image2 all category B. Within-image permutation leaves
  # labels unchanged -> zero permutation variance -> NA z. A cross-image
  # permutation would mix A/B and produce finite variance.
  spe <- nhood_path_spe(groups = c("A", "A", "A", "B", "B", "B"),
                        images = c("i1", "i1", "i1", "i2", "i2", "i2"))
  obj <- build_spatial_graph(spe, method = "knn", k = 2, graph_name = "g")
  res <- compute_nhood_enrichment(obj, group_by = "group", graph = "g",
                                  n_perm = 50, seed = 1)
  expect_true(all(is.na(as.matrix(res$zscore))))   # zero variance everywhere
})

test_that("NA-category spots are ignored, not fatal", {
  skip_if_not_implemented("build_spatial_graph", "compute_nhood_enrichment")
  skip_if_not_installed("SpatialExperiment")
  spe <- nhood_path_spe(c("A", "A", NA, "B", "B"))  # s3 has no category
  obj <- build_spatial_graph(spe, method = "radius", radius = 1.5, graph_name = "g")
  res <- compute_nhood_enrichment(obj, group_by = "group", graph = "g",
                                  n_perm = 19, seed = 1)
  # Edges touching s3 (s2-s3, s3-s4) are ignored; only s1-s2 (A-A) and s4-s5
  # (B-B) remain.
  cnt <- as.matrix(res$count)
  expect_equal(res$categories, c("A", "B"))
  expect_equal(cnt["A", "A"], 1); expect_equal(cnt["B", "B"], 1)
  expect_equal(cnt["A", "B"], 0)
})

test_that("compute_nhood_enrichment returns K x K zscore + count matrices", {
  skip_if_not_implemented("build_spatial_graph", "compute_nhood_enrichment")
  skip_if_not_installed("SpatialExperiment")
  u <- tf_universe()
  obj <- build_spatial_graph(tf_container("spe", u), method = "knn", k = 4,
                             graph_name = "g")
  res <- compute_nhood_enrichment(obj, group_by = "group", graph = "g",
                                  n_perm = 99, seed = 1)

  groups <- sort(unique(u$metadata$group))
  K <- length(groups)
  expect_true(all(c("zscore", "count", "categories") %in% names(res)))
  # Categories are reported in a fixed sorted order (row/col order of the matrices).
  expect_equal(res$categories, groups)
  z <- as.matrix(res$zscore); cnt <- as.matrix(res$count)
  expect_equal(dim(z), c(K, K))
  expect_equal(dim(cnt), c(K, K))
  # A zero-variance pair yields NA (not 0/Inf), so finiteness is NOT required;
  # every cell is finite OR NA, and counts are non-negative.
  expect_true(all(is.finite(z) | is.na(z)))
  expect_true(all(cnt >= 0))
})

test_that("the enrichment matrices are symmetric (undirected graph)", {
  skip_if_not_implemented("build_spatial_graph", "compute_nhood_enrichment")
  skip_if_not_installed("SpatialExperiment")
  u <- tf_universe()
  obj <- build_spatial_graph(tf_container("spe", u), method = "knn", k = 4,
                             graph_name = "g")
  res <- compute_nhood_enrichment(obj, group_by = "group", graph = "g",
                                  n_perm = 99, seed = 1)
  z <- as.matrix(res$zscore)
  expect_equal(z, t(z), tolerance = TOL_LOOSE)
})

test_that("permutation p-values, if reported, lie in [0, 1]", {
  skip_if_not_implemented("build_spatial_graph", "compute_nhood_enrichment")
  skip_if_not_installed("SpatialExperiment")
  u <- tf_universe()
  obj <- build_spatial_graph(tf_container("spe", u), method = "knn", k = 4,
                             graph_name = "g")
  res <- compute_nhood_enrichment(obj, group_by = "group", graph = "g",
                                  n_perm = 99, seed = 1)
  skip_if(is.null(res$p_value), "implementation does not report permutation p-values")
  p <- as.matrix(res$p_value)
  expect_true(all(p >= 0 & p <= 1))
})

test_that("neighbourhood enrichment rejects a directed graph", {
  skip_if_not_implemented("build_spatial_graph", "compute_nhood_enrichment")
  skip_if_not_installed("SpatialExperiment")
  obj <- build_spatial_graph(tf_container("spe"), method = "knn", k = 4,
                             graph_name = "d", directed = TRUE)
  expect_error(compute_nhood_enrichment(obj, group_by = "group", graph = "d"),
               regexp = "directed|undirected")
})

test_that("neighbourhood enrichment is reproducible under a fixed seed", {
  skip_if_not_implemented("build_spatial_graph", "compute_nhood_enrichment")
  skip_if_not_installed("SpatialExperiment")
  u <- tf_universe()
  obj <- build_spatial_graph(tf_container("spe", u), method = "knn", k = 4,
                             graph_name = "g")
  a <- compute_nhood_enrichment(obj, group_by = "group", graph = "g", n_perm = 99, seed = 3)
  b <- compute_nhood_enrichment(obj, group_by = "group", graph = "g", n_perm = 99, seed = 3)
  expect_equal(a, b)
})
