# Self-tests for the test infrastructure. These do NOT depend on matrispace and
# run today: if the factories drift, the whole suite is untrustworthy.

test_that("tf_universe is internally consistent and deterministic", {
  u1 <- tf_universe(n_genes = 30, n_spots = 24, n_images = 2)
  u2 <- tf_universe(n_genes = 30, n_spots = 24, n_images = 2)

  expect_identical(dim(u1$counts), c(30L, 24L))
  expect_identical(rownames(u1$counts), u1$genes)
  expect_identical(colnames(u1$counts), u1$spots)
  expect_identical(rownames(u1$coords), u1$spots)
  expect_identical(rownames(u1$metadata), u1$spots)
  expect_true(is(u1$counts, "CsparseMatrix"))
  expect_true(all(is.finite(u1$coords)))

  # Deterministic under a fixed seed.
  expect_equal(as.matrix(u1$counts), as.matrix(u2$counts))
  expect_equal(u1$coords, u2$coords)
})

test_that("images use their own overlapping local coordinate frames", {
  u <- tf_universe(n_spots = 24, n_images = 2)
  expect_length(u$images, 2)
  i1 <- u$coords[u$image_ids == u$images[1], , drop = FALSE]
  i2 <- u$coords[u$image_ids == u$images[2], , drop = FALSE]
  # Realistic multi-FOV: each image starts near the origin, so their coordinate
  # ranges OVERLAP -- image_id, not coordinates, distinguishes them.
  expect_true(min(i1[, "x"]) < 1 && min(i2[, "x"]) < 1)
  overlap <- min(max(i1[, "x"]), max(i2[, "x"])) - max(min(i1[, "x"]), min(i2[, "x"]))
  expect_gt(overlap, 0)
  # replicate_id is a distinct biological field, one per image by default.
  expect_setequal(u$replicates, c("rep1", "rep2"))
})

test_that("multiple images can belong to one replicate (serial sections)", {
  # The declared relationship is one-replicate-to-many-images; prove it, not
  # just that the default labels differ.
  u <- tf_universe(n_spots = 24, n_images = 2, n_replicates = 1)
  expect_length(u$images, 2)
  expect_length(u$replicates, 1)
  # Both image frames map to the same biological replicate.
  map <- unique(data.frame(image = u$image_ids, replicate = u$replicate_ids))
  expect_equal(nrow(map), 2)
  expect_equal(length(unique(map$replicate)), 1)
})

test_that("tf_seurat with multiple images creates one FOV per image", {
  skip_if_not_installed("Seurat")
  skip_if_not_installed("SeuratObject")
  u <- tf_universe(n_spots = 24, n_images = 2)
  obj <- tf_seurat(u)
  expect_setequal(SeuratObject::Images(obj), u$images)
  # Per-image coordinates come back in that image's local frame.
  tc <- SeuratObject::GetTissueCoordinates(obj, image = u$images[1])
  if (!is.null(tc$cell)) rownames(tc) <- tc$cell
  keep <- u$spots[u$image_ids == u$images[1]]
  expect_setequal(rownames(tc), keep)
})

test_that("tf_seurat carries counts, data layer, coords and metadata", {
  skip_if_not_installed("Seurat")
  skip_if_not_installed("SeuratObject")
  u <- tf_universe()
  obj <- tf_seurat(u)

  expect_s4_class(obj, "Seurat")
  expect_equal(ncol(obj), length(u$spots))
  cnt <- SeuratObject::LayerData(obj, layer = "counts", assay = "Spatial")
  expect_equal(as.matrix(cnt)[u$genes, u$spots], as.matrix(u$counts))

  tc <- SeuratObject::GetTissueCoordinates(obj)
  if (!is.null(tc$cell)) rownames(tc) <- tc$cell
  expect_equal(as_xy(tc[u$spots, ]), as_xy(u$coords), tolerance = TOL_COORD)
})

test_that("tf_spe carries counts, logcounts, coords and metadata", {
  skip_if_not_installed("SpatialExperiment")
  u <- tf_universe()
  spe <- tf_spe(u)

  expect_s4_class(spe, "SpatialExperiment")
  expect_equal(ncol(spe), length(u$spots))
  expect_equal(
    as.matrix(SummarizedExperiment::assay(spe, "counts"))[u$genes, u$spots],
    as.matrix(u$counts)
  )
  sc <- SpatialExperiment::spatialCoords(spe)
  expect_equal(as_xy(sc)[u$spots, ], as_xy(u$coords), tolerance = TOL_COORD)
  # SPE's reserved sample_id IS the library/image; replicate is a separate col.
  expect_identical(as.character(spe$sample_id), u$image_ids)
  expect_true("replicate_id" %in% colnames(SummarizedExperiment::colData(spe)))
})

test_that("both containers project the SAME ground truth", {
  skip_if_not_installed("Seurat")
  skip_if_not_installed("SpatialExperiment")
  u <- tf_universe()
  obj <- tf_seurat(u); spe <- tf_spe(u)

  s_counts <- as.matrix(
    SeuratObject::LayerData(obj, "counts", assay = "Spatial"))[u$genes, u$spots]
  e_counts <- as.matrix(
    SummarizedExperiment::assay(spe, "counts"))[u$genes, u$spots]
  expect_equal(s_counts, e_counts)
})

test_that("statistical oracles reproduce the hand-derived toy values", {
  g <- tf_toy_graph()
  expect_equal(ref_morans_i(g$x, g$connectivities), g$expected_morans_i,
               tolerance = TOL)
  expect_equal(ref_gearys_c(g$x, g$connectivities), g$expected_gearys_c,
               tolerance = TOL)
})

test_that("tf_universe_with_outlier isolates exactly one far spot", {
  u <- tf_universe_with_outlier(n_spots = 12)
  d_to_cluster <- sqrt(rowSums((u$coords - matrix(u$coords[u$outlier, ],
                     nrow = nrow(u$coords), ncol = 2, byrow = TRUE))^2))
  # The outlier is ~1400 away from the origin cluster; the rest are within a
  # few units of each other.
  expect_gt(min(d_to_cluster[rownames(u$coords) != u$outlier]), 500)
  cluster <- u$coords[rownames(u$coords) != u$outlier, ]
  expect_lt(max(dist(cluster)), 10)
})

test_that("tf_universe_with_ties has a centre equidistant from four neighbours", {
  u <- tf_universe_with_ties()
  d <- sqrt(rowSums((u$coords - matrix(u$coords[u$centre, ], nrow(u$coords), 2,
                     byrow = TRUE))^2))
  d_nbrs <- d[names(d) != u$centre]
  expect_equal(unname(d_nbrs), rep(1, 4), tolerance = TOL)  # exact ties at d=1
})

test_that("tf_expr_args / tf_counts_args give container-native handles", {
  expect_equal(tf_expr_args("seurat"), list(assay = "Spatial", layer = "data"))
  expect_equal(tf_expr_args("spe"), list(assay = "logcounts", layer = NULL))
  expect_equal(tf_counts_args("spe"), list(assay = "counts"))
  # A non-default Seurat assay name flows through (guards the 'RNA' hardcode).
  expect_equal(tf_expr_args("seurat", assay = "RNA")$assay, "RNA")
})

test_that("tf_seurat honours a non-default assay name", {
  skip_if_not_installed("Seurat")
  obj <- tf_seurat(tf_universe(), assay = "RNA")
  expect_true("RNA" %in% SeuratObject::Assays(obj))
  expect_false("Spatial" %in% SeuratObject::Assays(obj))
})

test_that("reference biology fixtures are well-formed and self-contained", {
  sig <- tf_signatures()
  expect_true(all(names(sig$signatures) %in% names(sig$labels)))
  # Keys are lower_snake, labels are human-facing -> they must differ.
  expect_false(any(names(sig$labels) == unname(sig$labels)))

  mk <- tf_markers()
  expect_true(all(vapply(mk, function(m) all(c("positive", "negative") %in% names(m)),
                         logical(1))))

  lr <- tf_lr_pairs()
  expect_named(lr, c("gene_1", "gene_2"))
  expect_gt(nrow(lr), 0)
})
