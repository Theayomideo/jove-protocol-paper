# Distance-binned categorical co-occurrence (SPATIAL_EXTENSIONS_IMPLEMENTATION
# _SPEC s4): the descriptive counting kernel, within-image permutation inference
# (Stage 2b, appended below), and plot_cooccurrence().

# Minimal labelled SPE from explicit coords + per-spot category labels + images.
cooc_spe <- function(coords, labels, images = rep("img1", nrow(coords))) {
  spots <- rownames(coords)
  cnt <- matrix(seq_len(3L * length(spots)) %% 5 + 1, 3L,
                dimnames = list(paste0("g", 1:3), spots))
  SpatialExperiment::SpatialExperiment(
    assays = list(counts = cnt), spatialCoords = coords,
    colData = S4Vectors::DataFrame(grp = labels, row.names = spots),
    sample_id = images)
}

# Convenience: pull one ratio cell.
cell <- function(d, f, t, dmax) {
  d$ratio[as.character(d$from) == f & as.character(d$to) == t &
            d$distance_max == dmax]
}

# The canonical A,A,B,B-on-a-line fixture with hand-derived ratios (see below).
line_spe <- function(images = rep("img1", 4)) {
  coords <- rbind(s1 = c(0, 0), s2 = c(1, 0), s3 = c(2, 0), s4 = c(3, 0))
  colnames(coords) <- c("x", "y")
  cooc_spe(coords, c("A", "A", "B", "B"), images)
}

# ---- hand-calculated annular + cumulative oracle ----------------------------

test_that("annular ratios match a hand-calculated two-category oracle", {
  skip_if_not_implemented("compute_cooccurrence")
  skip_if_not_installed("SpatialExperiment")
  # Points A(0) A(1) B(2) B(3); breaks (0,1.5,3.5]. Bin1 pairs: AA, AB, BB (d=1);
  # bin2 pairs: AB, AB, AB (d=2,3,2). Hand: ratio[A,A,1]=4/3, [A,B,1]=2/3,
  # [A,B,2]=2, [A,A,2]=0.
  d <- compute_cooccurrence(line_spe(), "grp", distance_breaks = c(0, 1.5, 3.5),
                            mode = "annular")
  expect_equal(cell(d, "A", "A", 1.5), 4 / 3)
  expect_equal(cell(d, "A", "B", 1.5), 2 / 3)
  expect_equal(cell(d, "B", "B", 1.5), 4 / 3)      # symmetric same-category
  expect_equal(cell(d, "A", "B", 3.5), 2)
  expect_equal(cell(d, "A", "A", 3.5), 0)          # zero conditional
  # A zero conditional keeps ratio 0 and log2 -Inf (never dropped).
  lr <- d$log2_ratio[as.character(d$from) == "A" & as.character(d$to) == "A" &
                       d$distance_max == 3.5]
  expect_identical(lr, -Inf)
  expect_equal(nrow(d), 2L * 2L * 2L)              # from x to x bins
})

test_that("cumulative ratios match the Squidpy-compatible hand oracle", {
  skip_if_not_implemented("compute_cooccurrence")
  skip_if_not_installed("SpatialExperiment")
  # Cumulative bin2 = (0,3.5] pools all pairs: counts AA=2, AB=4, BA=4, BB=2 ->
  # ratio[A,A]=2/3, ratio[A,B]=4/3. Bin1 equals the annular bin1.
  d <- compute_cooccurrence(line_spe(), "grp", distance_breaks = c(0, 1.5, 3.5),
                            mode = "cumulative")
  expect_true(all(d$distance_min == 0))            # cumulative bins start at 0
  expect_equal(cell(d, "A", "A", 3.5), 2 / 3)
  expect_equal(cell(d, "A", "B", 3.5), 4 / 3)
  expect_equal(cell(d, "A", "A", 1.5), 4 / 3)      # bin1 == annular bin1
})

# ---- direction, self-category counting, denominators ------------------------

test_that("ordered directions and same-category double counting are correct", {
  skip_if_not_implemented("compute_cooccurrence")
  skip_if_not_installed("SpatialExperiment")
  d <- compute_cooccurrence(line_spe(), "grp", distance_breaks = c(0, 1.5, 3.5),
                            mode = "annular")
  prov <- attr(d, "matrispace")
  # n_pairs_total in bin1 counts every ordered eligible pair (3 unordered x2 = 6).
  expect_equal(unique(d$n_pairs_total[d$distance_max == 1.5]), 6)
  expect_equal(prov$producer, "compute_cooccurrence")
  expect_equal(prov$categories, c("A", "B"))
})

test_that("undefined denominators yield NA, not zero or Inf", {
  skip_if_not_implemented("compute_cooccurrence")
  skip_if_not_installed("SpatialExperiment")
  # A single far B spot: within breaks only A-A pairs exist, so category B has no
  # eligible neighbor pairs -> marginal(B) defined only via ... actually B never
  # appears as a focal with eligible pairs -> conditional[B,*] undefined -> NA.
  coords <- rbind(a1 = c(0, 0), a2 = c(1, 0), a3 = c(0, 1), b1 = c(100, 100))
  colnames(coords) <- c("x", "y")
  d <- compute_cooccurrence(cooc_spe(coords, c("A", "A", "A", "B")), "grp",
                            distance_breaks = c(0, 2), mode = "annular")
  expect_true(all(is.na(cell(d, "B", "A", 2))))    # B has no eligible focal pair
  expect_true(all(is.na(d$conditional_probability[as.character(d$from) == "B"])))
})

# ---- label handling ---------------------------------------------------------

test_that("numeric-valued labels order naturally and blanks/NA are excluded", {
  skip_if_not_implemented("compute_cooccurrence")
  skip_if_not_installed("SpatialExperiment")
  coords <- cbind(x = (0:9), y = rep(0, 10)); rownames(coords) <- paste0("s", 0:9)
  colnames(coords) <- c("x", "y")
  labels <- c("0", "1", "2", "10", "0", "1", "2", "10", "", NA)
  d <- compute_cooccurrence(cooc_spe(coords, labels), "grp",
                            distance_breaks = c(0, 100), mode = "cumulative")
  # Numeric-aware category order, blank + NA dropped.
  expect_equal(levels(d$from), c("0", "1", "2", "10"))
  prov <- attr(d, "matrispace")
  expect_equal(unname(prov$omitted_labels["img1"]), 2L)   # "" and NA
  expect_equal(unname(prov$usable_spots["img1"]), 8L)
})

# ---- image isolation --------------------------------------------------------

test_that("co-occurrence never pairs spots across images (overlapping frames)", {
  skip_if_not_implemented("compute_cooccurrence")
  skip_if_not_installed("SpatialExperiment")
  # Two images share the SAME local coordinates; image1 is all A, image2 all B.
  # If frames were mixed, cross-image A-B pairs would appear; isolated, C[A,B]=0.
  one <- rbind(c(0, 0), c(1, 0), c(0, 1));
  coords <- rbind(one, one)
  rownames(coords) <- c("a1", "a2", "a3", "b1", "b2", "b3")
  colnames(coords) <- c("x", "y")
  images <- c(rep("i1", 3), rep("i2", 3))
  labels <- c("A", "A", "A", "B", "B", "B")
  d <- compute_cooccurrence(cooc_spe(coords, labels, images), "grp",
                            distance_breaks = c(0, 2), image_id = NULL,
                            distance_scale = c(i1 = 1, i2 = 1),
                            coordinate_units = "px", mode = "annular")
  # No A-B association exists -> conditional 0 (or NA), ratio 0/NA; within-group
  # A-A and B-B associations are positive.
  expect_true(all(cell(d, "A", "B", 2) %in% c(0, NA_real_)))
  expect_true(all(cell(d, "B", "A", 2) %in% c(0, NA_real_)))
  expect_gt(cell(d, "A", "A", 2), 0)
  expect_gt(cell(d, "B", "B", 2), 0)
})

# ---- multi-image scale / unit validation ------------------------------------

test_that("multiple images require distance_scale and coordinate_units", {
  skip_if_not_implemented("compute_cooccurrence")
  skip_if_not_installed("SpatialExperiment")
  spe <- line_spe(images = c("i1", "i1", "i2", "i2"))
  # Each image has only 2 spots (one A, one B) -> 1 eligible pair; fine.
  expect_error(
    compute_cooccurrence(spe, "grp", distance_breaks = c(0, 2)),
    "distance_scale.*required")
  expect_error(
    compute_cooccurrence(spe, "grp", distance_breaks = c(0, 2),
                         distance_scale = c(i1 = 1, i2 = 1)),
    "coordinate_units.*required")
  expect_error(
    compute_cooccurrence(spe, "grp", distance_breaks = c(0, 2),
                         distance_scale = c(i1 = 1, wrong = 1),
                         coordinate_units = "px"),
    "names must be exactly")
})

# ---- pooled vs equal-image aggregation --------------------------------------

test_that("pooled_pairs and equal_image differ on an unbalanced two-image fixture", {
  skip_if_not_implemented("compute_cooccurrence")
  skip_if_not_installed("SpatialExperiment")
  # image i1 = the 4-point line (ratio[A,B,bin1] = 2/3); image i2 = one A + one
  # near B + one far B (only 1 eligible A-B pair -> ratio[A,B,bin1] = 2). Pooled
  # counts give ratio 1; equal-image averages 2/3 and 2 to 4/3.
  c1 <- rbind(s1 = c(0, 0), s2 = c(1, 0), s3 = c(2, 0), s4 = c(3, 0))
  c2 <- rbind(t1 = c(0, 0), t2 = c(1, 0), t3 = c(1, 5))
  coords <- rbind(c1, c2); colnames(coords) <- c("x", "y")
  labels <- c("A", "A", "B", "B", "A", "B", "B")
  images <- c(rep("i1", 4), rep("i2", 3))
  spe <- cooc_spe(coords, labels, images)
  args <- list(spe, "grp", distance_breaks = c(0, 1.5, 3.5),
               distance_scale = c(i1 = 1, i2 = 1), coordinate_units = "px")

  pooled <- do.call(compute_cooccurrence, c(args, aggregation = "pooled_pairs"))
  equal  <- do.call(compute_cooccurrence, c(args, aggregation = "equal_image"))
  expect_equal(cell(pooled, "A", "B", 1.5), 1)
  expect_equal(cell(equal,  "A", "B", 1.5), (2 / 3 + 2) / 2)   # 4/3
  # equal-image reports between-image SD and per-cell image counts.
  sd_ab <- equal$ratio_sd[as.character(equal$from) == "A" &
                            as.character(equal$to) == "B" & equal$distance_max == 1.5]
  expect_equal(sd_ab, stats::sd(c(2 / 3, 2)))
  n_ab1 <- equal$n_images_used[as.character(equal$from) == "A" &
                                 as.character(equal$to) == "B" & equal$distance_max == 1.5]
  expect_equal(n_ab1, 2L)
  # image i2 has no bin2 pairs -> that cell is defined by only 1 image (no imputation).
  n_ab2 <- equal$n_images_used[as.character(equal$from) == "A" &
                                 as.character(equal$to) == "B" & equal$distance_max == 3.5]
  expect_equal(n_ab2, 1L)
})

# ---- invariance to host reorder + chunk_size --------------------------------

test_that("result is invariant to host spot ordering and chunk_size", {
  skip_if_not_implemented("compute_cooccurrence")
  skip_if_not_installed("SpatialExperiment")
  coords <- cbind(x = c(0, 1, 2, 3, 1, 2), y = c(0, 0, 0, 0, 2, 2))
  rownames(coords) <- paste0("s", 1:6); colnames(coords) <- c("x", "y")
  spe <- cooc_spe(coords, c("A", "B", "A", "B", "A", "B"))
  base <- compute_cooccurrence(spe, "grp", distance_breaks = c(0, 1.5, 3),
                               chunk_size = 512)
  small <- compute_cooccurrence(spe, "grp", distance_breaks = c(0, 1.5, 3),
                                chunk_size = 2)
  reord <- compute_cooccurrence(spe[, c(4, 1, 6, 2, 5, 3)], "grp",
                                distance_breaks = c(0, 1.5, 3), chunk_size = 3)
  expect_equal(base$ratio, small$ratio)
  expect_equal(base$ratio, reord$ratio)
})

# ---- bounded memory ---------------------------------------------------------

test_that("counting never allocates a condensed/full distance object", {
  skip_if_not_implemented("compute_cooccurrence")
  skip_if_not_installed("SpatialExperiment")
  skip_if(!capabilities("profmem"),
          "this R was built without memory profiling (Rprofmem unavailable)")
  n <- 1000L; set.seed(3)
  coords <- cbind(x = runif(n, 0, 100), y = runif(n, 0, 100))
  rownames(coords) <- sprintf("s%04d", seq_len(n)); colnames(coords) <- c("x", "y")
  spe <- cooc_spe(coords, rep(c("A", "B"), length.out = n))
  threshold <- floor(0.9 * n * (n - 1) / 2 * 8)
  tf <- tempfile(fileext = ".out"); on.exit(unlink(tf), add = TRUE)
  utils::Rprofmem(tf, threshold = threshold)
  compute_cooccurrence(spe, "grp", distance_breaks = c(0, 40), chunk_size = 256L)
  utils::Rprofmem(NULL)
  lines <- if (file.exists(tf)) readLines(tf, warn = FALSE) else character(0)
  nums <- suppressWarnings(as.numeric(sub("^([0-9]+).*$", "\\1", lines)))
  expect_length(lines[!is.na(nums) & nums >= threshold], 0)
})

# ---- argument validation ----------------------------------------------------

test_that("input validation is strict and actionable", {
  skip_if_not_implemented("compute_cooccurrence")
  skip_if_not_installed("SpatialExperiment")
  spe <- line_spe()
  expect_error(compute_cooccurrence(spe, "grp", distance_breaks = c(1, 2)),
               "first distance break must be 0")
  expect_error(compute_cooccurrence(spe, "grp", distance_breaks = c(0, 2, 1)),
               "strictly increasing")
  expect_error(compute_cooccurrence(spe, "grp", distance_breaks = 0),
               "at least two")
  expect_error(compute_cooccurrence(spe, "grp", distance_breaks = c(0, 2),
                                    chunk_size = 0), "chunk_size")
  expect_error(compute_cooccurrence(spe, "grp", distance_breaks = c(0, 2),
                                    bogus = TRUE), "unknown argument")
})

test_that("numeric controls reject malformed, out-of-range, and logical inputs", {
  skip_if_not_implemented("compute_cooccurrence")
  skip_if_not_installed("SpatialExperiment")
  spe <- line_spe()
  cc <- function(...) compute_cooccurrence(spe, "grp", distance_breaks = c(0, 2), ...)
  # Lists must not leak base-R errors.
  expect_error(cc(n_perm = list(0)), "n_perm")
  expect_error(cc(chunk_size = list(2)), "chunk_size")
  # Above the integer range must be a package diagnostic, not a coercion NA.
  expect_error(cc(n_perm = 3e9), "n_perm")
  expect_error(cc(seed = 3e9), "seed")
  # Logical is not a number here.
  expect_error(cc(n_perm = TRUE), "n_perm")
  expect_error(cc(seed = TRUE), "seed")
  expect_error(cc(chunk_size = TRUE), "chunk_size")
})

test_that("non-finite scaled coordinates error, naming the image and a spot", {
  skip_if_not_implemented("compute_cooccurrence")
  skip_if_not_installed("SpatialExperiment")
  # A huge scale factor overflows finite stored coordinates to Inf; the per-image
  # coordinate validation must catch it rather than silently drop the pairs.
  err <- tryCatch(
    compute_cooccurrence(line_spe(), "grp", distance_breaks = c(0, 2),
                         distance_scale = c(img1 = 1e308), coordinate_units = "um"),
    error = function(e) conditionMessage(e))
  expect_match(err, "non-finite coordinates after scaling")
  expect_match(err, "img1")                        # names the image
  expect_match(err, "s[0-9]")                       # names an affected spot
})

# ---- distance scaling + boundary contracts ----------------------------------

test_that("distance_scale changes pair eligibility (physical-unit bins)", {
  skip_if_not_implemented("compute_cooccurrence")
  skip_if_not_installed("SpatialExperiment")
  # Stored distances s1-s2 = 2, s2-s3 = 1, s1-s3 = 3. With breaks (0, 2.5] in
  # physical units: scale 1 keeps the first two pairs (4 ordered); scale 2
  # doubles distances so only s2-s3 (physical 2) survives (2 ordered).
  coords <- rbind(s1 = c(0, 0), s2 = c(2, 0), s3 = c(3, 0)); colnames(coords) <- c("x", "y")
  spe <- cooc_spe(coords, c("A", "B", "A"))
  d1 <- compute_cooccurrence(spe, "grp", distance_breaks = c(0, 2.5),
                             distance_scale = c(img1 = 1), coordinate_units = "um")
  d2 <- compute_cooccurrence(spe, "grp", distance_breaks = c(0, 2.5),
                             distance_scale = c(img1 = 2), coordinate_units = "um")
  expect_equal(unique(d1$n_pairs_total[d1$distance_max == 2.5]), 4)
  expect_equal(unique(d2$n_pairs_total[d2$distance_max == 2.5]), 2)
})

test_that("bin boundaries are (lower, upper]: internal break to lower bin, max included", {
  skip_if_not_implemented("compute_cooccurrence")
  skip_if_not_installed("SpatialExperiment")
  coords <- rbind(p = c(0, 0), q = c(2, 0)); colnames(coords) <- c("x", "y")
  spe <- cooc_spe(coords, c("A", "B"))
  # d = 2 exactly at the internal break 2 -> belongs to (0, 2], not (2, 4].
  d <- compute_cooccurrence(spe, "grp", distance_breaks = c(0, 2, 4), mode = "annular")
  expect_equal(unique(d$n_pairs_total[d$distance_max == 2]), 2)
  expect_equal(unique(d$n_pairs_total[d$distance_max == 4]), 0)
  # d = 2 exactly at the maximum break is included (right-closed).
  d2 <- compute_cooccurrence(spe, "grp", distance_breaks = c(0, 2), mode = "annular")
  expect_equal(unique(d2$n_pairs_total[d2$distance_max == 2]), 2)
})

# ============================================================================
# Stage 2b: within-image permutation inference + plot_cooccurrence().
# ============================================================================

# Aesthetic-target of a mapping (container/version independent).
cooc_map_var <- function(p, aesthetic) {
  m <- p$mapping[[aesthetic]]
  if (is.null(m)) return(NA_character_)
  sub('^\\.data\\[\\["(.*)"\\]\\]$', "\\1", rlang::as_label(m))
}
cooc_geoms <- function(p) vapply(p$layers, function(l) class(l$geom)[1], character(1))

# Two spatially segregated categories in one image: A-A/B-B enriched at short
# range, A-B depleted -- a fixture with a clear, testable permutation signal.
segregated_spe <- function(seed = 1L) {
  set.seed(seed)
  a <- cbind(x = runif(10, 0, 3), y = runif(10, 0, 3))
  b <- cbind(x = runif(10, 20, 23), y = runif(10, 20, 23))
  coords <- rbind(a, b); rownames(coords) <- sprintf("s%02d", 1:20)
  colnames(coords) <- c("x", "y")
  cooc_spe(coords, rep(c("A", "B"), each = 10))
}

# ---- permutation inference --------------------------------------------------

test_that("permutation p-values are reproducible and independent of chunk_size", {
  skip_if_not_implemented("compute_cooccurrence")
  skip_if_not_installed("SpatialExperiment")
  spe <- segregated_spe()
  a1 <- compute_cooccurrence(spe, "grp", distance_breaks = c(0, 5, 30),
                             n_perm = 199, seed = 42)
  a2 <- compute_cooccurrence(spe, "grp", distance_breaks = c(0, 5, 30),
                             n_perm = 199, seed = 42)               # same seed
  a3 <- compute_cooccurrence(spe, "grp", distance_breaks = c(0, 5, 30),
                             n_perm = 199, seed = 42, chunk_size = 3)
  expect_identical(a1$p_value, a2$p_value)
  expect_identical(a1$p_value, a3$p_value)                          # chunk-independent
  expect_equal(unique(a1$n_perm), 199L)
})

test_that("n_perm = 0 leaves all p-value columns NA", {
  skip_if_not_implemented("compute_cooccurrence")
  skip_if_not_installed("SpatialExperiment")
  d <- compute_cooccurrence(line_spe(), "grp", distance_breaks = c(0, 1.5, 3.5))
  expect_true(all(is.na(d$p_value)) && all(is.na(d$p_enrich)) &&
                all(is.na(d$p_deplete)) && all(is.na(d$p_adjusted)))
})

test_that("p-values respect the plus-one floor, [0,1] range, and BH monotonicity", {
  skip_if_not_implemented("compute_cooccurrence")
  skip_if_not_installed("SpatialExperiment")
  d <- compute_cooccurrence(segregated_spe(), "grp", distance_breaks = c(0, 5, 30),
                            n_perm = 199, seed = 7)
  def <- !is.na(d$p_value)
  expect_true(all(d$p_value[def] > 0 & d$p_value[def] <= 1))
  expect_true(all(d$p_enrich[def] >= 1 / (199 + 1) - 1e-12))        # plus-one floor
  expect_true(all(d$p_deplete[def] >= 1 / (199 + 1) - 1e-12))
  # BH adjustment is over the defined family and never below the raw p-value.
  expect_true(all(d$p_adjusted[def] >= d$p_value[def] - 1e-9))
  expect_true(all(d$p_adjusted[def] <= 1))
  # Segregation is detected: same-category short-range association is enriched.
  aa <- d[as.character(d$from) == "A" & as.character(d$to) == "A" &
            d$distance_max == 5, ]
  expect_lt(aa$p_value, 0.05)
  expect_gt(aa$ratio, 1)
})

test_that("permutation shuffles labels WITHIN each image, never across images", {
  skip_if_not_implemented("compute_cooccurrence")
  skip_if_not_installed("SpatialExperiment")
  # image i1 all A, image i2 all B (identical frames). A within-image shuffle is
  # the identity here, so every permutation equals the observed statistic and all
  # defined p-values are 1. A cross-image shuffle would instead create variation.
  one <- rbind(c(0, 0), c(1, 0), c(0, 1))
  coords <- rbind(one, one)
  rownames(coords) <- c("a1", "a2", "a3", "b1", "b2", "b3")
  colnames(coords) <- c("x", "y")
  spe <- cooc_spe(coords, c("A", "A", "A", "B", "B", "B"),
                  c("i1", "i1", "i1", "i2", "i2", "i2"))
  d <- compute_cooccurrence(spe, "grp", distance_breaks = c(0, 2),
                            distance_scale = c(i1 = 1, i2 = 1),
                            coordinate_units = "px", n_perm = 99, seed = 1)
  def <- !is.na(d$p_value)
  expect_true(all(d$p_value[def] == 1))
})

# ---- plot_cooccurrence ------------------------------------------------------

test_that("plot_cooccurrence returns a ggplot with a reference line and to-color", {
  skip_if_not_implemented("plot_cooccurrence", "compute_cooccurrence")
  skip_if_not_installed("SpatialExperiment")
  skip_if_not_installed("ggplot2")
  d <- compute_cooccurrence(segregated_spe(), "grp", distance_breaks = c(0, 5, 30))
  p <- plot_cooccurrence(d, value = "log2_ratio")
  expect_s3_class(p, "ggplot")
  expect_true("GeomHline" %in% cooc_geoms(p))          # no-association reference
  expect_equal(cooc_map_var(p, "colour"), "to")
  expect_equal(cooc_map_var(p, "x"), "distance_mid")
  # Vertical panel grid lines removed; horizontal guide retained.
  expect_s3_class(p$theme$panel.grid.major.x, "element_blank")
  # Faceted by focal category when several are shown.
  expect_s3_class(p$facet, "FacetWrap")
})

test_that("plot_cooccurrence ref line follows the value and single-from is unfaceted", {
  skip_if_not_implemented("plot_cooccurrence", "compute_cooccurrence")
  skip_if_not_installed("SpatialExperiment")
  skip_if_not_installed("ggplot2")
  d <- compute_cooccurrence(segregated_spe(), "grp", distance_breaks = c(0, 5, 30))
  pr <- plot_cooccurrence(d, value = "ratio")
  hl <- pr$layers[[which(cooc_geoms(pr) == "GeomHline")]]
  expect_equal(hl$data$yintercept %||% hl$aes_params$yintercept %||%
                 environment(hl$geom$draw_panel)$yintercept, 1, tolerance = 0)
  one <- plot_cooccurrence(d, from = "A")
  expect_s3_class(one$facet, "FacetNull")
})

test_that("plot_cooccurrence preserves requested from/to order and rejects unknowns", {
  skip_if_not_implemented("plot_cooccurrence", "compute_cooccurrence")
  skip_if_not_installed("SpatialExperiment")
  skip_if_not_installed("ggplot2")
  d <- compute_cooccurrence(segregated_spe(), "grp", distance_breaks = c(0, 5, 30))
  p <- plot_cooccurrence(d, from = c("B", "A"), to = c("B", "A"))
  expect_equal(levels(p$data$from), c("B", "A"))
  expect_equal(levels(p$data$to), c("B", "A"))
  expect_error(plot_cooccurrence(d, from = "Z"), "unknown from")
  dd <- rbind(d, d[1, ])
  expect_error(plot_cooccurrence(dd), "duplicate")
})

test_that("plot_cooccurrence floors zero ratios but the data keeps -Inf", {
  skip_if_not_implemented("plot_cooccurrence", "compute_cooccurrence")
  skip_if_not_installed("SpatialExperiment")
  skip_if_not_installed("ggplot2")
  # The A,A,B,B line has ratio[A,A,bin2] = 0 -> log2 = -Inf.
  d <- compute_cooccurrence(line_spe(), "grp", distance_breaks = c(0, 1.5, 3.5))
  expect_true(any(is.infinite(d$log2_ratio)))          # -Inf retained in data
  p <- plot_cooccurrence(d, value = "log2_ratio")
  b <- ggplot2::ggplot_build(p)
  ys <- b$data[[which(cooc_geoms(p) == "GeomPoint")]]$y
  expect_true(all(is.finite(ys)))                       # floored, no -Inf plotted
})

test_that("plot_cooccurrence de-emphasizes non-significant rows without removing them", {
  skip_if_not_implemented("plot_cooccurrence", "compute_cooccurrence")
  skip_if_not_installed("SpatialExperiment")
  skip_if_not_installed("ggplot2")
  d <- compute_cooccurrence(segregated_spe(), "grp", distance_breaks = c(0, 5, 30),
                            n_perm = 99, seed = 1)
  plain <- plot_cooccurrence(d)
  faint <- plot_cooccurrence(d, significance = 0.05)
  # Same rows plotted (nothing dropped), but an alpha scale is added.
  expect_equal(nrow(plain$data), nrow(faint$data))
  expect_true(any(vapply(faint$scales$scales,
                         function(s) "alpha" %in% s$aesthetics, logical(1))))
  expect_error(plot_cooccurrence(d, significance = 2), "significance")
})

test_that("plot_cooccurrence guards dense defaults and labels distance units", {
  cats <- as.character(0:8)
  d <- expand.grid(from = cats, to = cats, distance_mid = c(1, 2),
                   KEEP.OUT.ATTRS = FALSE, stringsAsFactors = FALSE)
  d$distance_min <- d$distance_mid - 0.5
  d$distance_max <- d$distance_mid + 0.5
  d$ratio <- 1
  d$log2_ratio <- 0
  d$coordinate_units <- "microns"
  expect_error(plot_cooccurrence(d), "select `from`.*`to`")
  p <- plot_cooccurrence(d, from = cats[1:2], to = cats[1:2])
  expect_equal(ggplot2::get_labs(p)$x, "distance (microns)")
})

# Two unbalanced images, both segregated, for the equal_image null path.
seg_two_image_spe <- function(seed = 2L) {
  set.seed(seed)
  a1 <- cbind(runif(8, 0, 3), runif(8, 0, 3))
  b1 <- cbind(runif(8, 20, 23), runif(8, 20, 23))
  a2 <- cbind(runif(5, 0, 3), runif(5, 0, 3))
  b2 <- cbind(runif(5, 20, 23), runif(5, 20, 23))
  coords <- rbind(a1, b1, a2, b2)
  rownames(coords) <- sprintf("s%02d", seq_len(26)); colnames(coords) <- c("x", "y")
  cooc_spe(coords, c(rep("A", 8), rep("B", 8), rep("A", 5), rep("B", 5)),
           c(rep("i1", 16), rep("i2", 10)))
}

test_that("permutation p-values use a fixed n_perm + 1 denominator (no hidden N)", {
  skip_if_not_implemented("compute_cooccurrence")
  skip_if_not_installed("SpatialExperiment")
  np <- 199L
  d <- compute_cooccurrence(segregated_spe(), "grp", distance_breaks = c(0, 5, 30),
                            n_perm = np, seed = 11)
  def <- !is.na(d$p_enrich)
  # Every reported p is (integer + 1)/(n_perm + 1): the denominator is fixed.
  scaled <- d$p_enrich[def] * (np + 1)
  expect_true(all(abs(scaled - round(scaled)) < 1e-9))
  scaled2 <- d$p_deplete[def] * (np + 1)
  expect_true(all(abs(scaled2 - round(scaled2)) < 1e-9))
})

test_that("equal_image permutation inference runs and BH matches exactly", {
  skip_if_not_implemented("compute_cooccurrence")
  skip_if_not_installed("SpatialExperiment")
  d <- compute_cooccurrence(seg_two_image_spe(), "grp",
                            distance_breaks = c(0, 5, 30),
                            aggregation = "equal_image",
                            distance_scale = c(i1 = 1, i2 = 1),
                            coordinate_units = "px", n_perm = 199, seed = 5)
  def <- !is.na(d$p_value)
  expect_true(any(def))
  expect_true(all(d$p_value[def] > 0 & d$p_value[def] <= 1))
  # p_adjusted is EXACTLY BH over the defined returned family.
  expect_equal(d$p_adjusted[def], stats::p.adjust(d$p_value[def], "BH"))
  # Same-category short-range association is still detected under equal_image.
  aa <- d[as.character(d$from) == "A" & as.character(d$to) == "A" &
            d$distance_max == 5, ]
  expect_lt(aa$p_value, 0.05)
})

# ---- plot_cooccurrence schema-value validation ------------------------------

test_that("plot_cooccurrence validates value types/ranges and selector uniqueness", {
  skip_if_not_implemented("plot_cooccurrence", "compute_cooccurrence")
  skip_if_not_installed("SpatialExperiment")
  skip_if_not_installed("ggplot2")
  d <- compute_cooccurrence(segregated_spe(), "grp", distance_breaks = c(0, 5, 30))
  bad_dist <- d; bad_dist$distance_mid <- as.character(bad_dist$distance_mid)
  expect_error(plot_cooccurrence(bad_dist), "distance_mid.*numeric")
  bad_ratio <- d; bad_ratio$ratio[1] <- -1
  expect_error(plot_cooccurrence(bad_ratio), "ratio.*non-negative")
  bad_log2 <- d; bad_log2$log2_ratio[1] <- Inf
  expect_error(plot_cooccurrence(bad_log2), "log2_ratio")
  # Duplicate selectors are a package diagnostic, not a leaked factor error.
  expect_error(plot_cooccurrence(d, from = c("A", "A")), "duplicate")
  expect_error(plot_cooccurrence(d, to = c("B", "B")), "duplicate")
  # Out-of-range p-values are rejected when significance is requested.
  bad_p <- d; bad_p$p_value <- 2
  expect_error(plot_cooccurrence(bad_p, significance = 0.05,
                                 p_column = "p_value"), "p_value")
})

test_that("a cell left undefined by any permutation returns NA inference", {
  skip_if_not_implemented("compute_cooccurrence")
  skip_if_not_installed("SpatialExperiment")
  # Five clustered spots + one far-isolated spot; category C has a single spot.
  # In some permutations C lands on the isolated spot (no eligible pairs) -> that
  # cell's permuted ratio is undefined -> its p-values must be NA (the fixed
  # n_perm + 1 denominator is never quietly shrunk).
  coords <- rbind(c1 = c(0, 0), c2 = c(1, 0), c3 = c(0, 1), c4 = c(1, 1),
                  c5 = c(0.5, 0.5), c6 = c(1000, 1000))
  colnames(coords) <- c("x", "y")
  spe <- cooc_spe(coords, c("A", "A", "A", "A", "C", "A"))
  d <- compute_cooccurrence(spe, "grp", distance_breaks = c(0, 3),
                            n_perm = 199, seed = 1)
  ca <- d[as.character(d$from) == "C" & as.character(d$to) == "A", ]
  expect_false(is.na(ca$ratio))                     # observed IS defined
  expect_true(is.na(ca$p_value) && is.na(ca$p_enrich) &&
                is.na(ca$p_deplete) && is.na(ca$p_adjusted))
  aa <- d[as.character(d$from) == "A" & as.character(d$to) == "A", ]
  expect_false(is.na(aa$p_value))                   # common category still tested
})

test_that("plot_cooccurrence rejects infinite/NaN ratios", {
  skip_if_not_implemented("plot_cooccurrence", "compute_cooccurrence")
  skip_if_not_installed("SpatialExperiment")
  skip_if_not_installed("ggplot2")
  d <- compute_cooccurrence(segregated_spe(), "grp", distance_breaks = c(0, 5, 30))
  inf_ratio <- d; inf_ratio$ratio[1] <- Inf
  expect_error(plot_cooccurrence(inf_ratio, value = "ratio"), "finite")
  nan_ratio <- d; nan_ratio$ratio[1] <- NaN
  expect_error(plot_cooccurrence(nan_ratio, value = "ratio"), "finite")
})
