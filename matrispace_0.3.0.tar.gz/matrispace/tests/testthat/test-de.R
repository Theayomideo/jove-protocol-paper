# Differential expression (SPEC s10). Two public entry points: find_ecm_markers
# (within-object, container-independent Wilcoxon) and find_ecm_de (cross-
# REPLICATE pseudobulk, DESeq2). Results restrict to matrisome genes and are
# annotated with matrisome category. Condition is a property of the biological
# `replicate_id`, never of a spot; spot-level condition testing is rejected.

# Give each replicate a single condition (rep1..repK -> A/A/.../B/B...).
tf_set_condition_by_replicate <- function(u) {
  reps <- u$replicates
  half <- ceiling(length(reps) / 2)
  cond <- setNames(c(rep("A", half), rep("B", length(reps) - half)), reps)
  u$metadata$group <- unname(cond[u$replicate_ids])
  u
}

test_that("find_ecm_markers returns a table annotated with matrisome category", {
  skip_if_not_implemented("find_ecm_markers")
  skip_if_not_installed("Seurat")
  u <- tf_universe()
  obj <- tf_container("seurat", u)
  res <- find_ecm_markers(obj, group_by = "group", ident.1 = "A", ident.2 = "B",
                          assay = "Spatial", layer = "data",
                          matrisome = u$genes[1:10])
  expect_s3_class(res, "data.frame")
  expect_true("matrisome_category" %in% colnames(res) ||
              "category" %in% colnames(res))
  gene_col <- intersect(c("gene", "feature"), colnames(res))[1]
  expect_true(all(res[[gene_col]] %in% u$genes[1:10]))
})

test_that("find_ecm_markers all-vs-all mode runs when ident.1 is NULL", {
  skip_if_not_implemented("find_ecm_markers")
  skip_if_not_installed("Seurat")
  u <- tf_universe()
  obj <- tf_container("seurat", u)
  res <- find_ecm_markers(obj, group_by = "group", ident.1 = NULL,
                          assay = "Spatial", layer = "data",
                          matrisome = u$genes[1:10])
  expect_s3_class(res, "data.frame")
  expect_true(any(grepl("adj", tolower(colnames(res)))))
})

test_that("find_ecm_markers also runs on SpatialExperiment (container-independent)", {
  skip_if_not_implemented("find_ecm_markers")
  skip_if_not_installed("SpatialExperiment")
  u <- tf_universe()
  obj <- tf_container("spe", u)
  res <- find_ecm_markers(obj, group_by = "group", ident.1 = "A", ident.2 = "B",
                          assay = "logcounts", layer = NULL,
                          matrisome = u$genes[1:10])
  expect_s3_class(res, "data.frame")
})

# SPE with an explicit logcounts = log1p(counts) layer, for exact DE oracles.
de_oracle_spe <- function(counts, group) {
  spots <- colnames(counts)
  logcounts <- log1p(counts)
  SpatialExperiment::SpatialExperiment(
    assays = list(counts = counts, logcounts = logcounts),
    spatialCoords = cbind(x = seq_along(spots), y = 0),
    colData = S4Vectors::DataFrame(group = group, replicate_id = spots,
                                   row.names = spots),
    sample_id = rep("img", length(spots)))
}

test_that("find_ecm_markers avg_log2FC, detection fractions, and FDR match the oracle", {
  skip_if_not_implemented("find_ecm_markers")
  skip_if_not_installed("SpatialExperiment")
  # G1 up in A (counts 3,3,0,0); G2 up in B (0,0,7,7). Groups A={s1,s2}, B={s3,s4}.
  counts <- rbind(G1 = c(3, 3, 0, 0), G2 = c(0, 0, 7, 7))
  colnames(counts) <- paste0("s", 1:4)
  spe <- de_oracle_spe(counts, group = c("A", "A", "B", "B"))
  res <- find_ecm_markers(spe, group_by = "group", ident.1 = "A", ident.2 = "B",
                          assay = "logcounts", layer = NULL, matrisome = c("G1", "G2"))
  res <- res[match(c("G1", "G2"), res$feature), ]
  # avg_log2FC = log2(mean(expm1(A))+1) - log2(mean(expm1(B))+1):
  #   G1 = log2(4) - log2(1) = 2 ; G2 = log2(1) - log2(8) = -3.
  expect_equal(res$avg_log2FC, c(2, -3), tolerance = TOL)
  expect_equal(res$pct.1, c(1, 0), tolerance = TOL)
  expect_equal(res$pct.2, c(0, 1), tolerance = TOL)
  expect_equal(res$p_adjusted, stats::p.adjust(res$p_value, "BH"), tolerance = TOL)
})

test_that("find_ecm_markers is container-independent (Seurat == SPE)", {
  skip_if_not_implemented("find_ecm_markers")
  skip_if_not_installed("Seurat")
  skip_if_not_installed("SpatialExperiment")
  u <- tf_universe()
  s <- find_ecm_markers(tf_container("seurat", u), group_by = "group",
         ident.1 = "A", ident.2 = "B", assay = "Spatial", layer = "data",
         matrisome = u$genes[1:10])
  e <- find_ecm_markers(tf_container("spe", u), group_by = "group",
         ident.1 = "A", ident.2 = "B", assay = "logcounts", layer = NULL,
         matrisome = u$genes[1:10])
  s <- s[order(s$feature), ]; e <- e[order(e$feature), ]
  expect_equal(s$avg_log2FC, e$avg_log2FC, tolerance = TOL_LOOSE)
  expect_equal(s$p_value, e$p_value, tolerance = TOL_LOOSE)
})

test_that("find_ecm_markers records matrisome/definition provenance", {
  skip_if_not_implemented("find_ecm_markers")
  skip_if_not_installed("SpatialExperiment")
  u <- tf_universe()
  res <- find_ecm_markers(tf_container("spe", u), group_by = "group", ident.1 = "A",
           ident.2 = "B", assay = "logcounts", layer = NULL, matrisome = u$genes[1:10])
  prov <- attr(res, "matrispace")
  expect_equal(prov$producer, "compare_ecm_groups")
  expect_equal(prov$assay, "logcounts")
  expect_true(nzchar(prov$matrisome_digest))
})

test_that("find_ecm_de rejects too-few-replicates-per-condition", {
  skip_if_not_implemented("find_ecm_de")
  skip_if_not_installed("SpatialExperiment")
  # Two replicates, each a single condition -> only ONE replicate per condition,
  # which is not valid cross-replicate inference.
  u <- tf_set_condition_by_replicate(tf_universe(n_spots = 24, n_images = 2))
  obj <- tf_container("spe", u)
  expect_error(
    find_ecm_de(obj, condition = "group", replicate = "replicate_id",
                counts_assay = "counts", matrisome = u$genes[1:10]),
    regexp = "replicate|design|condition"
  )
})

test_that("find_ecm_de rejects condition varying within a replicate (pseudoreplication)", {
  skip_if_not_implemented("find_ecm_de")
  skip_if_not_installed("SpatialExperiment")
  # Default factory: `group` alternates A/B WITHIN each replicate, so condition
  # is a spot property, not a replicate property -> must be rejected.
  u <- tf_universe(n_spots = 24, n_images = 2)
  obj <- tf_container("spe", u)
  expect_error(
    find_ecm_de(obj, condition = "group", replicate = "replicate_id",
                counts_assay = "counts", matrisome = u$genes[1:10]),
    regexp = "replicate|condition|design"
  )
})

test_that("pseudobulk aggregation sums counts within replicate x condition", {
  skip_if_not_implemented(".pseudobulk")
  skip_if_not_installed("SpatialExperiment")
  u <- tf_set_condition_by_replicate(tf_universe(n_spots = 24, n_images = 4))
  obj <- tf_container("spe", u)
  pb <- mfn(".pseudobulk")(obj, group = c("replicate_id", "group"), assay = "counts")
  # Column totals equal the sum of member spot totals (counts are additive).
  expect_equal(sum(Matrix::colSums(pb)), sum(Matrix::colSums(u$counts)),
               tolerance = TOL)
})

test_that("find_ecm_de rejects a single-condition design", {
  skip_if_not_implemented("find_ecm_de")
  skip_if_not_installed("SpatialExperiment")
  u <- tf_universe(n_spots = 24, n_images = 4)
  u$metadata$group <- "A"                             # only one condition
  obj <- tf_container("spe", u)
  expect_error(
    find_ecm_de(obj, condition = "group", replicate = "replicate_id",
                counts_assay = "counts", matrisome = u$genes[1:10]),
    regexp = "condition")
})

test_that(".pseudobulk aggregates without densifying (sparse indicator)", {
  skip_if_not_implemented(".pseudobulk")
  skip_if_not_installed("SpatialExperiment")
  skip_if(!capabilities("profmem"), "no memory profiling")
  u <- tf_set_condition_by_replicate(tf_universe(n_genes = 50, n_spots = 400, n_images = 4))
  obj <- tf_container("spe", u)
  n_genes <- length(u$genes); n_spots <- length(u$spots)
  threshold <- n_genes * n_spots * 8                 # a dense genes x spots copy
  tf <- tempfile(fileext = ".out"); on.exit(unlink(tf), add = TRUE)
  utils::Rprofmem(tf, threshold = threshold)
  mfn(".pseudobulk")(obj, group = c("replicate_id", "group"), assay = "counts")
  utils::Rprofmem(NULL)
  lines <- if (file.exists(tf)) readLines(tf, warn = FALSE) else character(0)
  nums <- suppressWarnings(as.numeric(sub("^([0-9]+).*$", "\\1", lines)))
  expect_length(lines[!is.na(nums) & nums >= threshold], 0)
})

test_that("find_ecm_de runs pseudobulk DESeq2 on a valid design", {
  skip_if_not_implemented("find_ecm_de")
  skip_if_not_installed("SpatialExperiment")
  skip_if_not_installed("DESeq2")
  u <- tf_set_condition_by_replicate(tf_universe(n_spots = 40, n_images = 4))
  obj <- tf_container("spe", u)
  res <- suppressWarnings(find_ecm_de(obj, condition = "group",
           replicate = "replicate_id", counts_assay = "counts",
           matrisome = u$genes[1:10]))
  expect_s3_class(res, "data.frame")
  expect_true("matrisome_category" %in% colnames(res))
  expect_true(all(res$feature %in% u$genes[1:10]))
  prov <- attr(res, "matrispace")
  expect_equal(prov$producer, "test_ecm_pseudobulk")
  expect_equal(prov$design, "~ condition")
  expect_true(nzchar(prov$matrisome_digest))
})

test_that("find_ecm_de rejects non-integer or non-finite raw counts", {
  skip_if_not_implemented("find_ecm_de")
  skip_if_not_installed("SpatialExperiment")
  u <- tf_set_condition_by_replicate(tf_universe(n_spots = 24, n_images = 4))
  corrupt <- function(val) {
    obj <- tf_container("spe", u)
    a <- as.matrix(SummarizedExperiment::assay(obj, "counts")); a[1, 1] <- val
    SummarizedExperiment::assay(obj, "counts") <- Matrix::Matrix(a, sparse = TRUE)
    obj
  }
  expect_error(find_ecm_de(corrupt(1.5), condition = "group", replicate = "replicate_id",
    counts_assay = "counts", matrisome = u$genes[1:10]), "whole")
  expect_error(find_ecm_de(corrupt(-1), condition = "group", replicate = "replicate_id",
    counts_assay = "counts", matrisome = u$genes[1:10]), "non-negative")
  expect_error(find_ecm_de(corrupt(NA_real_), condition = "group", replicate = "replicate_id",
    counts_assay = "counts", matrisome = u$genes[1:10]), "non-finite")
})

test_that("find_ecm_de contrast direction is explicit and reversible", {
  skip_if_not_implemented("find_ecm_de")
  skip_if_not_installed("SpatialExperiment")
  skip_if_not_installed("DESeq2")
  u <- tf_set_condition_by_replicate(tf_universe(n_spots = 40, n_images = 4))
  obj <- tf_container("spe", u)
  de <- function(n1, n2) suppressWarnings(find_ecm_de(obj, condition = "group",
    replicate = "replicate_id", counts_assay = "counts", matrisome = u$genes[1:10],
    condition.1 = n1, condition.2 = n2))
  ab <- de("A", "B"); ba <- de("B", "A")
  ab <- ab[order(ab$feature), ]; ba <- ba[order(ba$feature), ]
  expect_equal(ab$log2FoldChange, -ba$log2FoldChange, tolerance = TOL_LOOSE)
  expect_equal(attr(ab, "matrispace")$numerator, "A")
  expect_equal(attr(ba, "matrispace")$numerator, "B")
})

test_that(".pseudobulk is container-independent (Seurat == SPE)", {
  skip_if_not_implemented(".pseudobulk")
  skip_if_not_installed("Seurat")
  skip_if_not_installed("SpatialExperiment")
  u <- tf_universe()
  ps <- mfn(".pseudobulk")(tf_container("seurat", u), group = "replicate_id", assay = "Spatial")
  pe <- mfn(".pseudobulk")(tf_container("spe", u), group = "replicate_id", assay = "counts")
  cols <- sort(colnames(ps)); rows <- sort(rownames(ps))
  expect_equal(as.matrix(ps)[rows, cols], as.matrix(pe)[rows, cols])
})

test_that(".matrisome_digest is sensitive to category reassignment", {
  skip_if_not_implemented(".matrisome_digest")
  d <- mfn(".matrisome_digest")
  m1 <- data.frame(gene = c("G1", "G2"), category = c("Collagens", "Glyco"),
                   stringsAsFactors = FALSE)
  m2 <- data.frame(gene = c("G1", "G2"), category = c("Glyco", "Collagens"),
                   stringsAsFactors = FALSE)
  expect_false(identical(d(m1), d(m2)))               # same genes, swapped categories
  # A consistent duplicate row is semantically identical to its deduplicated form.
  dup <- data.frame(gene = c("G1", "G1", "G2"),
                    category = c("Collagens", "Collagens", "Glyco"),
                    stringsAsFactors = FALSE)
  expect_identical(d(dup), d(m1))                      # redundant rows -> same provenance
})

test_that(".group_key is injective across digits, colons, and empty strings", {
  skip_if_not_implemented(".group_key")
  gk <- mfn(".group_key")
  # Values chosen so a naive paste(sep=":"/"_") would collide: e.g. ("1","2:3")
  # vs ("1:2","3"), and ("", "a") vs ("a", "").
  gdf <- data.frame(
    a = c("1",   "1:2", "",  "a",  "12", "1"),
    b = c("2:3", "3",   "a", "",   "3",  "23"),
    stringsAsFactors = FALSE)
  keys <- gk(gdf)
  expect_equal(anyDuplicated(keys), 0L)                # every distinct row -> distinct key
})

test_that("find_ecm_de fits DESeq2 on all genes but returns only matrisome rows", {
  skip_if_not_implemented("find_ecm_de")
  skip_if_not_installed("SpatialExperiment")
  skip_if_not_installed("DESeq2")
  u <- tf_set_condition_by_replicate(tf_universe(n_genes = 30, n_spots = 40, n_images = 4))
  obj <- tf_container("spe", u)
  target <- u$genes[1:5]
  captured <- NULL
  orig_ddsfm <- DESeq2::DESeqDataSetFromMatrix    # capture before mocking (no recursion)
  testthat::local_mocked_bindings(
    DESeqDataSetFromMatrix = function(countData, ...) {
      captured <<- rownames(countData)
      orig_ddsfm(countData = countData, ...)
    }, .package = "DESeq2")
  res <- suppressWarnings(find_ecm_de(obj, condition = "group",
           replicate = "replicate_id", counts_assay = "counts", matrisome = target))
  expect_setequal(captured, u$genes)                   # DESeq2 saw the full transcriptome
  expect_true(all(res$feature %in% target))            # output restricted to matrisome
  expect_true(nrow(res) <= length(target))
})

test_that("find_ecm_de exposes one unambiguous adjusted-p family (no DESeq2 padj)", {
  skip_if_not_implemented("find_ecm_de")
  skip_if_not_installed("SpatialExperiment")
  skip_if_not_installed("DESeq2")
  u <- tf_set_condition_by_replicate(tf_universe(n_spots = 40, n_images = 4))
  obj <- tf_container("spe", u)
  res <- suppressWarnings(find_ecm_de(obj, condition = "group",
           replicate = "replicate_id", counts_assay = "counts",
           matrisome = u$genes[1:10]))
  expect_false("padj" %in% colnames(res))              # DESeq2's own family is dropped
  expect_false("pvalue" %in% colnames(res))            # standardized to p_value
  expect_true(all(c("p_value", "p_adjusted") %in% colnames(res)))
  # BH is recomputed over exactly the returned matrisome rows, NA-safe.
  expect_equal(res$p_adjusted, stats::p.adjust(res$p_value, "BH"), tolerance = TOL)
})

test_that("find_ecm_de validates contrast labels (scalar, non-empty, non-NA)", {
  skip_if_not_implemented("find_ecm_de")
  skip_if_not_installed("SpatialExperiment")
  u <- tf_set_condition_by_replicate(tf_universe(n_spots = 24, n_images = 4))
  obj <- tf_container("spe", u)
  de <- function(...) find_ecm_de(obj, condition = "group", replicate = "replicate_id",
    counts_assay = "counts", matrisome = u$genes[1:10], ...)
  expect_error(de(condition.1 = c("A", "B")), "condition.1")     # vector
  expect_error(de(condition.1 = NA_character_), "condition.1")   # NA
  expect_error(de(condition.1 = ""), "condition.1")              # empty
  expect_error(de(condition.1 = "Z"), "observed")                # not an observed level
})

test_that("find_ecm_markers/de validate matrisome structure", {
  skip_if_not_implemented(".validate_matrisome")
  v <- mfn(".validate_matrisome")
  expect_error(v(c("G1", "", "G3")), "non-empty")               # empty gene name
  expect_error(v(c("G1", NA, "G3")), "non-empty")               # NA gene name
  expect_error(v(c("G1", "G1")), "unique")                      # duplicate in vector
  conflict <- data.frame(gene = c("G1", "G1"), category = c("Collagens", "Glyco"),
                         stringsAsFactors = FALSE)
  expect_error(v(conflict), "conflicting")                      # same gene, two categories
  ok <- data.frame(gene = c("G1", "G1", "G2"),
                   category = c("Collagens", "Collagens", "Glyco"),
                   stringsAsFactors = FALSE)
  expect_true(v(ok))                                            # consistent duplicate allowed
})

test_that("find_ecm_markers rejects ident.2 without ident.1 and single-group all-vs-all", {
  skip_if_not_implemented("find_ecm_markers")
  skip_if_not_installed("SpatialExperiment")
  u <- tf_universe()
  obj <- tf_container("spe", u)
  expect_error(
    find_ecm_markers(obj, group_by = "group", ident.1 = NULL, ident.2 = "B",
      assay = "logcounts", layer = NULL, matrisome = u$genes[1:10]),
    "ident.2")
  u1 <- u; u1$metadata$group <- "A"                    # only one non-empty group
  obj1 <- tf_container("spe", u1)
  expect_error(
    find_ecm_markers(obj1, group_by = "group", ident.1 = NULL,
      assay = "logcounts", layer = NULL, matrisome = u$genes[1:10]),
    "two non-empty groups")
})

test_that("find_ecm_de errors informatively when DESeq2 is unavailable", {
  skip_if_not_implemented("find_ecm_de")
  skip_if_not_installed("SpatialExperiment")
  # A VALID design (4 replicates, 2 per condition, condition constant within
  # replicate) that passes validation and reaches the DESeq2 requirement. We
  # force the optional dependency to appear absent via the availability seam,
  # so this branch is exercised even when DESeq2 IS installed.
  u <- tf_set_condition_by_replicate(tf_universe(n_spots = 24, n_images = 4))
  obj <- tf_container("spe", u)
  testthat::local_mocked_bindings(.has_deseq2 = function() FALSE)
  expect_error(
    find_ecm_de(obj, condition = "group", replicate = "replicate_id",
                counts_assay = "counts", matrisome = u$genes[1:10]),
    regexp = "DESeq2"
  )
})
