# ECM niche annotation (arch doc s4, s5.1). annotate_* returns the object. The
# canonical call is a score result; a grouping label is mirrored into spot
# metadata under a collision-resistant key. Markers come from bundled data, not
# a runtime Excel read.

# ---- Pure ScType scoring kernel: hand oracle + edge cases (SPEC s8) ----------

test_that(".sctype_scores matches the hand oracle with a negative-only marker", {
  skip_if_not_implemented(".sctype_scores")
  # G3 is negative in BOTH niches (occurrence 2 -> weight 1/sqrt(2), finite).
  expr <- rbind(G1 = c(2, 0), G2 = c(0, 2), G3 = c(0, 2))
  colnames(expr) <- c("s1", "s2")
  markers <- list(N1 = list(positive = "G1", negative = "G3"),
                  N2 = list(positive = "G2", negative = "G3"))
  sc <- mfn(".sctype_scores")(expr, markers)
  expect_equal(sc$scores["N1", ], c(s1 = 1.20710678, s2 = -1.20710678), tolerance = TOL)
  expect_equal(sc$scores["N2", ], c(s1 = -0.20710678, s2 = 0.20710678), tolerance = TOL)
  expect_true(all(is.finite(sc$scores)))          # negative-only marker weight finite
})

test_that(".sctype_scores normalizes each role by sqrt(#matched markers)", {
  skip_if_not_implemented(".sctype_scores")
  # Two identical positive markers -> z-sum 2*z, divided by sqrt(2) -> |1|.
  expr <- rbind(A = c(2, 0), B = c(2, 0)); colnames(expr) <- c("s1", "s2")
  sc <- mfn(".sctype_scores")(expr, list(N = list(positive = c("A", "B"),
                                                  negative = character(0))))
  expect_equal(unname(sc$scores["N", ]), c(1, -1), tolerance = TOL)
})

test_that(".sctype_call applies the threshold (unassigned when max <= threshold)", {
  skip_if_not_implemented(".sctype_scores", ".sctype_call")
  expr <- rbind(A = c(0, 2)); colnames(expr) <- c("s1", "s2")
  sc <- mfn(".sctype_scores")(expr, list(N = list(positive = "A",
                                                 negative = character(0))))
  calls <- mfn(".sctype_call")(sc$scores, sc$positive, 0)
  expect_true(is.na(calls[1]))                     # score <= 0 -> unassigned
  expect_equal(calls[2], "N")
})

test_that(".sctype_call breaks exact ties by sorted niche name", {
  skip_if_not_implemented(".sctype_scores", ".sctype_call")
  expr <- rbind(A = c(2, 0)); colnames(expr) <- c("s1", "s2")
  markers <- list(zebra = list(positive = "A", negative = character(0)),
                  alpha = list(positive = "A", negative = character(0)))
  sc <- mfn(".sctype_scores")(expr, markers)
  calls <- mfn(".sctype_call")(sc$scores, sc$positive, 0)
  expect_equal(calls[1], "alpha")                  # identical scores -> sorted name
})

test_that(".sctype_scores errors on an empty positive marker list", {
  skip_if_not_implemented(".sctype_scores")
  expr <- rbind(A = c(1, 2)); colnames(expr) <- c("s1", "s2")
  expect_error(
    mfn(".sctype_scores")(expr, list(N = list(positive = character(0),
                                             negative = "A"))),
    regexp = "empty positive")
})

test_that(".sctype_scores gives an unavailable niche an all-NA row with a warning", {
  skip_if_not_implemented(".sctype_scores")
  expr <- rbind(A = c(2, 0), B = c(0, 2)); colnames(expr) <- c("s1", "s2")
  markers <- list(avail = list(positive = "A", negative = character(0)),
                  gone  = list(positive = "ABSENT", negative = character(0)))
  expect_warning(sc <- mfn(".sctype_scores")(expr, markers), "no matched positive")
  expect_true(all(is.na(sc$scores["gone", ])))
  expect_false(any(is.na(sc$scores["avail", ])))
})

test_that(".sctype_scores counts a gene once per niche (both-role markers)", {
  skip_if_not_implemented(".sctype_scores")
  # N1 lists G1 in BOTH roles (counts once for N1); N2 lists it positive. So
  # occ[G1] = 2 -> weight 1/sqrt(2). N2's score = (1/sqrt(2)) * z_G1 = 0.5 at s1.
  # Counting raw entries (occ = 3) would give 0.408 instead.
  expr <- rbind(G1 = c(2, 0)); colnames(expr) <- c("s1", "s2")
  markers <- list(N1 = list(positive = "G1", negative = "G1"),
                  N2 = list(positive = "G1", negative = character(0)))
  sc <- mfn(".sctype_scores")(expr, markers)
  expect_equal(sc$scores["N2", "s1"], 0.5, tolerance = TOL)
})

test_that(".sctype_scores z-scales only matched marker rows, not the whole matrix", {
  skip_if_not_implemented(".sctype_scores", ".zscale_rows")
  # 200 genes, only 3 are markers: the transcriptome must not be densified.
  genes <- sprintf("G%03d", 1:200)
  expr <- Matrix::Matrix(matrix(stats::runif(200 * 4), 200, 4,
             dimnames = list(genes, paste0("s", 1:4))), sparse = TRUE)
  markers <- list(N = list(positive = genes[1:2], negative = genes[3]))
  real_z <- mfn(".zscale_rows")
  seen <- new.env(); seen$nrow <- NA_integer_
  testthat::local_mocked_bindings(
    .zscale_rows = function(m) { seen$nrow <- nrow(m); real_z(m) },
    .package = "matrispace")
  mfn(".sctype_scores")(expr, markers)
  expect_equal(seen$nrow, 3L)          # only the 3 marker rows reach z-scaling
})

test_that("annotate_ecm_niches records a reproducible marker digest", {
  skip_if_not_implemented("annotate_ecm_niches", ".get_registry")
  skip_if_not_installed("SpatialExperiment")
  u <- tf_universe()
  mk_a <- list(niche = list(positive = u$genes[1:3], negative = character(0)))
  mk_b <- list(niche = list(positive = u$genes[4:6], negative = character(0)))
  m1 <- mfn(".get_registry")(annotate_ecm_niches(tf_spe(u), markers = mk_a,
          assay = "logcounts", layer = NULL))$artifacts$ecm_niche_classification_scores
  m2 <- mfn(".get_registry")(annotate_ecm_niches(tf_spe(u), markers = mk_b,
          assay = "logcounts", layer = NULL))$artifacts$ecm_niche_classification_scores
  expect_false(identical(m1$parameters$marker_digest, m2$parameters$marker_digest))
})

test_that(".sctype_scores rejects NA or empty marker names", {
  skip_if_not_implemented(".sctype_scores")
  expr <- rbind(A = c(1, 2)); colnames(expr) <- c("s1", "s2")
  expect_error(mfn(".sctype_scores")(expr,
    list(N = list(positive = c("A", NA), negative = character(0)))), "NA or empty")
  expect_error(mfn(".sctype_scores")(expr,
    list(N = list(positive = c("A", ""), negative = character(0)))), "NA or empty")
})

test_that("annotate_ecm_niches returns the object with a canonical niche call", {
  skip_if_not_implemented("annotate_ecm_niches", "get_ecm_niches")
  skip_if_not_installed("SpatialExperiment")
  u <- tf_universe(); mk <- tf_markers(u$genes)
  obj <- annotate_ecm_niches(tf_container("spe", u), markers = mk,
                             assay = "logcounts", layer = NULL)
  calls <- get_ecm_niches(obj)
  expect_equal(length(calls), length(u$spots))
  expect_true(all(stats::na.omit(as.character(calls)) %in% names(mk)))
})

test_that("the niche label is mirrored into metadata under a namespaced key", {
  skip_if_not_implemented("annotate_ecm_niches", ".get_spot_metadata")
  skip_if_not_installed("SpatialExperiment")
  u <- tf_universe(); mk <- tf_markers(u$genes)
  obj <- annotate_ecm_niches(tf_container("spe", u), markers = mk,
                             assay = "logcounts", layer = NULL)
  md <- mfn(".get_spot_metadata")(obj)
  expect_true("matrispace_ecm_niche_classification" %in% colnames(md))
  # The old, ambiguous name is gone; no legacy duplicate alias column.
  expect_false("matrispace_ecm_niche" %in% colnames(md))
  expect_false("ecm_domain_annotation" %in% colnames(md))
})

test_that("the annotation is discoverable through the registry", {
  skip_if_not_implemented("annotate_ecm_niches", ".get_registry")
  skip_if_not_installed("SpatialExperiment")
  u <- tf_universe(); mk <- tf_markers(u$genes)
  obj <- annotate_ecm_niches(tf_container("spe", u), markers = mk,
                             assay = "logcounts", layer = NULL)
  reg <- mfn(".get_registry")(obj)
  expect_true(length(reg$artifacts) >= 1)
})

test_that("a niche whose positive markers are all absent is unavailable, not fatal", {
  skip_if_not_implemented("annotate_ecm_niches", "get_ecm_niches")
  skip_if_not_installed("SpatialExperiment")
  u <- tf_universe(); mk <- tf_markers(u$genes)
  # Make one niche's positive markers absent from the dataset entirely.
  mk$vascular$positive <- c("NotAGene1", "NotAGene2")
  expect_warning(
    obj <- annotate_ecm_niches(tf_container("spe", u), markers = mk,
                               assay = "logcounts", layer = NULL),
    "no matched positive")
  calls <- get_ecm_niches(obj)
  # The call succeeds and the unavailable niche can never win annotation.
  expect_false("vascular" %in% stats::na.omit(as.character(calls)))
})

test_that("[seurat] annotation stores the artifact and mirrors the label", {
  skip_if_not_implemented("annotate_ecm_niches", "get_ecm_niches", ".get_registry")
  skip_if_not_installed("Seurat")
  u <- tf_universe(); mk <- tf_markers(u$genes)
  obj <- annotate_ecm_niches(tf_container("seurat", u), markers = mk,
                             assay = "Spatial", layer = "data")
  calls <- get_ecm_niches(obj)
  expect_equal(length(calls), length(u$spots))
  md <- mfn(".get_spot_metadata")(obj)
  expect_true("matrispace_ecm_niche_classification" %in% colnames(md))
  reg <- mfn(".get_registry")(obj)
  expect_true("ecm_niche_classification_scores" %in% names(reg$artifacts))
})

test_that("annotation errors only when EVERY niche has zero matched markers", {
  skip_if_not_implemented("annotate_ecm_niches")
  skip_if_not_installed("SpatialExperiment")
  u <- tf_universe()
  none <- list(
    interstitial = list(positive = c("X1", "X2"), negative = character(0)),
    basement     = list(positive = c("X3", "X4"), negative = character(0)))
  expect_error(
    annotate_ecm_niches(tf_container("spe", u), markers = none,
                        assay = "logcounts", layer = NULL))
})

test_that("openxlsx is not a hard runtime dependency of the package", {
  skip_if_not_implemented("annotate_ecm_niches")
  # Static guarantee: a runtime Excel read is impossible if openxlsx is not
  # imported. (expect_no_error alone can't prove non-use when it's installed.)
  imp <- packageDescription("matrispace")$Imports %||% ""
  dep <- packageDescription("matrispace")$Depends %||% ""
  expect_false(grepl("openxlsx", paste(imp, dep)))
})

test_that("annotation succeeds even when openxlsx::read.xlsx is made to explode", {
  skip_if_not_implemented("annotate_ecm_niches")
  skip_if_not_installed("SpatialExperiment")
  skip_if_not_installed("openxlsx")
  # Behavioural proof: if annotation ever reached for the Excel reader it would
  # now fail loudly. Markers are supplied as data, so it must still succeed.
  testthat::local_mocked_bindings(
    read.xlsx = function(...) stop("openxlsx::read.xlsx must not be called at runtime"),
    .package = "openxlsx"
  )
  u <- tf_universe(); mk <- tf_markers(u$genes)
  expect_no_error(
    annotate_ecm_niches(tf_container("spe", u), markers = mk, assay = "logcounts",
                        layer = NULL)
  )
})
