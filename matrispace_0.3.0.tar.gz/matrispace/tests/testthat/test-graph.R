# Spatial graph foundation (arch doc s2.2). build_spatial_graph() constructs a
# named `matrispace_graph`, stored in the registry, consumed by every spatial
# analysis. Invariants: sparse, image-blocked (partitioned by image_id),
# deterministic, reorder-safe, fingerprinted.

GRAPH_FIELDS <- c("schema_version", "connectivities", "distances", "spot_ids",
                  "image_ids", "replicate_ids", "method", "parameters",
                  "partition_ids", "partition_within_image",
                  "directed", "symmetrize", "weight", "coordinate_system",
                  "coordinate_fingerprint")

test_that("build_spatial_graph returns the object and registers a named graph", {
  skip_if_not_implemented("build_spatial_graph", "matrispace_graphs")
  skip_if_not_installed("SpatialExperiment")
  obj <- tf_container("spe")

  obj2 <- build_spatial_graph(obj, method = "knn", k = 4, graph_name = "spatial_knn4")
  # Object-in / object-out.
  expect_s4_class(obj2, class(obj))
  expect_true("spatial_knn4" %in% matrispace_graphs(obj2))
})

test_that("a matrispace_graph carries the full required schema", {
  skip_if_not_implemented("build_spatial_graph", "get_matrispace_graph")
  skip_if_not_installed("SpatialExperiment")
  obj <- build_spatial_graph(tf_container("spe"), method = "knn", k = 4,
                             graph_name = "g")
  g <- get_matrispace_graph(obj, "g")

  expect_s3_class(g, "matrispace_graph")
  expect_true(all(GRAPH_FIELDS %in% names(g)))
  expect_true(is(g$connectivities, "CsparseMatrix"))
  expect_true(is(g$distances, "CsparseMatrix"))
  expect_equal(g$method, "knn")
  expect_true(nzchar(g$coordinate_fingerprint))
})

test_that("graph output is a sparse matrix far below dense density", {
  skip_if_not_implemented("build_spatial_graph", "get_matrispace_graph")
  skip_if_not_installed("SpatialExperiment")
  u <- tf_universe(n_spots = 60, n_images = 2)
  g <- get_matrispace_graph(
    build_spatial_graph(tf_container("spe", u), method = "knn", k = 6, graph_name = "g"),
    "g")
  # A knn graph must be far sparser than dense. (This only checks the OUTPUT;
  # the internal no-dense-dist guarantee is the Rprofmem test below.)
  expect_true(is(g$connectivities, "sparseMatrix"))
  expect_lt(Matrix::nnzero(g$connectivities), length(u$spots)^2 / 4)
})

test_that("graph construction never allocates a dense distance matrix internally", {
  # Output sparsity does NOT prove the implementation avoided a dense dist()
  # (arch doc s2.2, s5.2). A base-R dist() object is CONDENSED (~n(n-1)/2*8
  # bytes), well below n^2*8, so the threshold must target the condensed size,
  # not the full square. Large n makes the quadratic gap dwarf any legitimate
  # linear kd-tree allocation, so false positives are negligible.
  skip_if_not_implemented("build_spatial_graph")
  skip_if_not_installed("SpatialExperiment")
  skip_if(!capabilities("profmem"),
          "this R was built without memory profiling (Rprofmem unavailable)")

  u <- tf_universe(n_spots = 1000, n_images = 1)  # single partition
  obj <- tf_container("spe", u)
  n <- length(u$spots)
  # 0.9x the condensed-distance size: catches dist() (~4 MB at n=1000) with a
  # header margin; a correct sparse build allocates nothing this large.
  threshold <- floor(0.9 * n * (n - 1) / 2 * 8)

  tf <- tempfile(fileext = ".out")
  on.exit(unlink(tf), add = TRUE)
  utils::Rprofmem(tf, threshold = threshold)
  build_spatial_graph(obj, method = "knn", k = 6, graph_name = "g")
  utils::Rprofmem(NULL)

  lines <- if (file.exists(tf)) readLines(tf, warn = FALSE) else character(0)
  nums <- suppressWarnings(as.numeric(sub("^([0-9]+).*$", "\\1", lines)))
  offending <- lines[!is.na(nums) & nums >= threshold]
  expect_length(offending, 0)
})

test_that("neighbours never cross image boundaries (block-diagonal by image)", {
  skip_if_not_implemented("build_spatial_graph", "get_matrispace_graph")
  skip_if_not_installed("SpatialExperiment")
  # Two images share OVERLAPPING local coordinates; only image_id prevents
  # cross-frame edges, so this is the real test of image-aware partitioning.
  u <- tf_universe(n_spots = 24, n_images = 2)
  g <- get_matrispace_graph(
    build_spatial_graph(tf_container("spe", u), method = "knn", k = 4, graph_name = "g"),
    "g")

  W <- g$connectivities
  img <- setNames(u$image_ids, u$spots)[rownames(W)]
  ij <- Matrix::which(W != 0, arr.ind = TRUE)
  # Every edge connects two spots from the SAME image frame.
  expect_true(all(img[ij[, 1]] == img[ij[, 2]]))
})

test_that("connectivities have a zero diagonal and matching spot ids", {
  skip_if_not_implemented("build_spatial_graph", "get_matrispace_graph")
  skip_if_not_installed("SpatialExperiment")
  u <- tf_universe()
  g <- get_matrispace_graph(
    build_spatial_graph(tf_container("spe", u), method = "knn", k = 4, graph_name = "g"),
    "g")
  expect_equal(unname(Matrix::diag(g$connectivities)), rep(0, length(u$spots)))
  expect_setequal(g$spot_ids, u$spots)
  expect_setequal(rownames(g$connectivities), u$spots)
})

test_that("undirected knn connectivities are symmetric (union symmetrization)", {
  skip_if_not_implemented("build_spatial_graph", "get_matrispace_graph")
  skip_if_not_installed("SpatialExperiment")
  u <- tf_universe(n_spots = 16, n_images = 1)
  g <- get_matrispace_graph(build_spatial_graph(tf_container("spe", u),
       method = "knn", k = 3, graph_name = "g", directed = FALSE), "g")
  W <- g$connectivities
  expect_true(Matrix::isSymmetric(W))
  expect_identical(g$directed, FALSE)
  expect_equal(g$symmetrize, "union")
})

test_that("mutual knn keeps only reciprocal neighbours and may create isolates", {
  skip_if_not_installed("SpatialExperiment")
  coords <- cbind(x = c(0, 1, 3), y = c(0, 0, 0))
  rownames(coords) <- c("A", "B", "C")
  g <- get_matrispace_graph(build_spatial_graph(tf_spe_from_coords(coords),
       method = "knn", k = 1, graph_name = "g", directed = FALSE,
       symmetrize = "mutual"), "g")
  W <- as.matrix(g$connectivities)
  expect_identical(g$symmetrize, "mutual")
  expect_true(Matrix::isSymmetric(g$connectivities))
  expect_equal(W["A", "B"], 1)
  expect_equal(W["B", "A"], 1)
  expect_equal(sum(W["C", ]), 0)
})

test_that("symmetrization is accepted only for undirected knn", {
  skip_if_not_installed("SpatialExperiment")
  obj <- tf_container("spe", tf_universe(n_spots = 12, n_images = 1))
  expect_error(build_spatial_graph(obj, method = "knn", k = 2, graph_name = "d",
                                   directed = TRUE, symmetrize = "union"),
               "cannot request")
  expect_error(build_spatial_graph(obj, method = "radius", radius = 12,
                                   graph_name = "r", symmetrize = "union"),
               "do not use")
  expect_error(build_spatial_graph(obj, method = "knn", k = 2, graph_name = "x",
                                   symmetrize = "average"), "union.*mutual")
})

test_that("partition_within_image subdivides but never replaces image safety", {
  skip_if_not_installed("SpatialExperiment")
  u <- tf_universe(n_spots = 24, n_images = 2)
  obj <- tf_container("spe", u)
  region <- rep(c("left", "right"), length.out = ncol(obj))
  names(region) <- colnames(obj)
  obj <- mfn(".set_spot_metadata")(obj, "region", region)
  g <- get_matrispace_graph(build_spatial_graph(
    obj, method = "knn", k = 4, graph_name = "g",
    partition_within_image = "region"), "g")
  ij <- Matrix::which(g$connectivities != 0, arr.ind = TRUE)
  expect_identical(g$partition_within_image, "region")
  expect_identical(g$partition_ids, unname(region[g$spot_ids]))
  expect_true(all(g$image_ids[ij[, 1]] == g$image_ids[ij[, 2]]))
  expect_true(all(g$partition_ids[ij[, 1]] == g$partition_ids[ij[, 2]]))
})

test_that("within-image partition membership is fingerprinted and validated", {
  skip_if_not_installed("SpatialExperiment")
  obj <- tf_container("spe", tf_universe(n_spots = 12, n_images = 1))
  region <- rep(c("a", "b"), length.out = ncol(obj)); names(region) <- colnames(obj)
  obj <- mfn(".set_spot_metadata")(obj, "region", region)
  obj <- build_spatial_graph(obj, method = "knn", k = 2, graph_name = "g",
                             partition_within_image = "region")
  changed <- region; changed[1] <- if (changed[1] == "a") "b" else "a"
  changed_obj <- mfn(".set_spot_metadata")(obj, "region", changed)
  expect_error(mfn(".validate_graph_against")(
    get_matrispace_graph(obj, "g"), changed_obj), "stale")
  expect_error(build_spatial_graph(obj, method = "knn", k = 2, graph_name = "x",
                                   partition_within_image = "missing"), "not found")
})

test_that("directed knn preserves asymmetry and records symmetrize = NA", {
  skip_if_not_implemented("build_spatial_graph", "get_matrispace_graph")
  skip_if_not_installed("SpatialExperiment")
  # Collinear points at 0,1,3 with k = 1: A->B, B->A, C->B (C->B without B->C),
  # a hand-derived ASYMMETRIC directed graph.
  coords <- cbind(x = c(0, 1, 3), y = c(0, 0, 0)); rownames(coords) <- c("A", "B", "C")
  g <- get_matrispace_graph(build_spatial_graph(tf_spe_from_coords(coords),
       method = "knn", k = 1, graph_name = "g", directed = TRUE), "g")

  expect_identical(g$directed, TRUE)
  expect_true(is.na(g$symmetrize))
  W <- as.matrix(g$connectivities)
  expect_equal(unname(diag(W)), c(0, 0, 0))
  expect_equal(unname(Matrix::rowSums(g$connectivities)), c(1, 1, 1))  # out-degree = k
  expect_equal(W["C", "B"], 1); expect_equal(W["B", "C"], 0)           # asymmetric
  expect_false(Matrix::isSymmetric(g$connectivities))
})

test_that("KNN tie resolution examines O(n) candidates, not O(n^2)", {
  skip_if_not_implemented("build_spatial_graph")
  skip_if_not_installed("SpatialExperiment")
  # 30x30 lattice (every interior row tied at radius 1) plus a distant triple
  # whose member is tied at a HUGE radius. A single global tie-radius would
  # expand every lattice query to that radius -> O(n^2) candidates.
  side <- 30L
  gg <- expand.grid(x = 0:(side - 1), y = 0:(side - 1)); lat <- as.matrix(gg)
  Mc <- c(1e6, 1e6); R <- 1e5; a <- c(0, 2 * pi / 3, 4 * pi / 3)
  extra <- rbind(Mc, Mc + R * c(cos(a[1]), sin(a[1])),
                     Mc + R * c(cos(a[2]), sin(a[2])),
                     Mc + R * c(cos(a[3]), sin(a[3])))
  coords <- rbind(lat, extra); n <- nrow(coords)
  rownames(coords) <- sprintf("s%04d", seq_len(n)); colnames(coords) <- c("x", "y")
  spe <- tf_spe_from_coords(coords)

  real_frNN <- dbscan::frNN
  total <- 0L
  utils::assignInNamespace("frNN",
    function(...) { r <- real_frNN(...); total <<- total + sum(lengths(r$id)); r },
    ns = "dbscan")
  withr::defer(utils::assignInNamespace("frNN", real_frNN, ns = "dbscan"))

  build_spatial_graph(spe, method = "knn", k = 2, graph_name = "g")
  # Per-radius-group resolution examines ~5n candidates here; a global tie
  # radius would examine ~n per lattice row (~n^2). 50n is a wide margin.
  expect_lt(total, 50 * n)
})

test_that("equal-distance ties select the lexicographically smallest ids", {
  skip_if_not_implemented("build_spatial_graph", "get_matrispace_graph")
  skip_if_not_installed("SpatialExperiment")
  # Centre spot001 equidistant from spot002..spot005; directed k = 2 must pick
  # the two smallest ids (no union graph to obscure the selection).
  u <- tf_universe_with_ties()
  g <- get_matrispace_graph(build_spatial_graph(tf_container("spe", u),
       method = "knn", k = 2, graph_name = "g", directed = TRUE), "g")
  W <- as.matrix(g$connectivities)
  nbrs <- colnames(W)[W[u$centre, ] > 0]
  expect_setequal(nbrs, c("spot002", "spot003"))
})

test_that("k >= partition size connects to all available neighbours without error", {
  skip_if_not_implemented("build_spatial_graph", "get_matrispace_graph")
  skip_if_not_installed("SpatialExperiment")
  u <- tf_universe(n_spots = 6, n_images = 1)
  expect_no_error(
    g <- get_matrispace_graph(build_spatial_graph(tf_container("spe", u),
         method = "knn", k = 20, graph_name = "g"), "g"))
  n <- length(u$spots)
  # No self-edges, and every spot connects to every other: a COMPLETE
  # off-diagonal graph has exactly n*(n-1) nonzeros.
  expect_equal(unname(Matrix::diag(g$connectivities)), rep(0, n))
  expect_equal(Matrix::nnzero(g$connectivities), n * (n - 1))
})

test_that("graph construction is deterministic", {
  skip_if_not_implemented("build_spatial_graph", "get_matrispace_graph")
  skip_if_not_installed("SpatialExperiment")
  u <- tf_universe()
  g1 <- get_matrispace_graph(build_spatial_graph(tf_container("spe", u),
        method = "knn", k = 4, graph_name = "g"), "g")
  g2 <- get_matrispace_graph(build_spatial_graph(tf_container("spe", u),
        method = "knn", k = 4, graph_name = "g"), "g")
  expect_equal(as.matrix(g1$connectivities), as.matrix(g2$connectivities))
})

test_that("graph is reorder-safe: same edges regardless of spot column order", {
  skip_if_not_implemented("build_spatial_graph", "get_matrispace_graph")
  skip_if_not_installed("SpatialExperiment")
  u <- tf_universe()
  obj <- tf_container("spe", u)
  g_a <- get_matrispace_graph(build_spatial_graph(obj, method = "knn", k = 4,
         graph_name = "g"), "g")
  g_b <- get_matrispace_graph(build_spatial_graph(obj[, rev(seq_len(ncol(obj)))],
         method = "knn", k = 4, graph_name = "g"), "g")

  ids <- u$spots
  Wa <- as.matrix(g_a$connectivities)[ids, ids]
  Wb <- as.matrix(g_b$connectivities)[ids, ids]
  expect_equal(Wa, Wb)
})

test_that("equal-distance ties are broken reorder-safely (by spot id, not position)", {
  skip_if_not_implemented("build_spatial_graph", "get_matrispace_graph")
  skip_if_not_installed("SpatialExperiment")
  # Centre spot is exactly equidistant from four neighbours; with k = 2 the
  # implementation MUST choose deterministically by spot id, so reordering the
  # host object cannot change which two edges the centre keeps.
  u <- tf_universe_with_ties()
  obj <- tf_container("spe", u)
  g_a <- get_matrispace_graph(build_spatial_graph(obj, method = "knn", k = 2,
         graph_name = "g"), "g")
  g_b <- get_matrispace_graph(build_spatial_graph(obj[, rev(seq_len(ncol(obj)))],
         method = "knn", k = 2, graph_name = "g"), "g")
  ids <- u$spots
  expect_equal(as.matrix(g_a$connectivities)[ids, ids],
               as.matrix(g_b$connectivities)[ids, ids])
})

test_that("radius graphs connect within-radius and exclude beyond-radius", {
  skip_if_not_implemented("build_spatial_graph", "get_matrispace_graph")
  skip_if_not_installed("SpatialExperiment")
  # Grid spacing is 10; radius 12 links orthogonal neighbours, excludes the
  # ~14.1 diagonal.
  u <- tf_universe(n_spots = 16, n_images = 1)
  g <- get_matrispace_graph(build_spatial_graph(tf_container("spe", u),
       method = "radius", radius = 12, graph_name = "g"), "g")
  d <- g$distances
  nz <- d@x
  expect_true(all(nz <= 12 + TOL))
  expect_gt(Matrix::nnzero(g$connectivities), 0)
})

test_that("multiple named graphs coexist; consumers take an explicit graph", {
  skip_if_not_implemented("build_spatial_graph", "matrispace_graphs")
  skip_if_not_installed("SpatialExperiment")
  obj <- tf_container("spe")
  obj <- build_spatial_graph(obj, method = "knn", k = 6, graph_name = "spatial_knn6")
  obj <- build_spatial_graph(obj, method = "radius", radius = 12, graph_name = "spatial_r12")
  expect_setequal(matrispace_graphs(obj), c("spatial_knn6", "spatial_r12"))
})

test_that("a stale coordinate fingerprint is detected on use", {
  skip_if_not_implemented("build_spatial_graph", "get_matrispace_graph",
                          ".validate_graph_against")
  skip_if_not_installed("SpatialExperiment")
  u <- tf_universe()
  obj <- build_spatial_graph(tf_container("spe", u), method = "knn", k = 4,
                             graph_name = "g")
  g <- get_matrispace_graph(obj, "g")

  # Mutate coordinates -> fingerprint no longer matches -> validation must fail.
  moved <- tf_container("spe", u)
  SpatialExperiment::spatialCoords(moved)[] <-
    SpatialExperiment::spatialCoords(moved) + 5
  expect_error(mfn(".validate_graph_against")(g, moved),
               regexp = "fingerprint|coordinate")
})

test_that("a coordinate change smaller than 1e-6 still invalidates the graph", {
  skip_if_not_implemented("build_spatial_graph", "get_matrispace_graph",
                          ".validate_graph_against")
  skip_if_not_installed("SpatialExperiment")
  u <- tf_universe()
  obj <- build_spatial_graph(tf_container("spe", u), method = "knn", k = 4,
                             graph_name = "g")
  g <- get_matrispace_graph(obj, "g")
  moved <- tf_container("spe", u)
  sc <- SpatialExperiment::spatialCoords(moved)
  sc[1, 1] <- sc[1, 1] + 1e-9   # sub-micron nudge
  SpatialExperiment::spatialCoords(moved) <- sc
  expect_error(mfn(".validate_graph_against")(g, moved),
               regexp = "fingerprint|coordinate|stale")
})

test_that("graph stores per-spot replicate_ids aligned to spot_ids", {
  skip_if_not_implemented("build_spatial_graph", "get_matrispace_graph")
  skip_if_not_installed("SpatialExperiment")
  u <- tf_universe(n_images = 2)   # rep1, rep2
  g <- get_matrispace_graph(build_spatial_graph(tf_container("spe", u),
       method = "knn", k = 4, graph_name = "g"), "g")
  expect_equal(length(g$replicate_ids), length(g$spot_ids))
  rep_by_spot <- setNames(g$replicate_ids, g$spot_ids)
  expect_equal(unname(rep_by_spot[u$spots]), u$replicate_ids)
})

test_that(".validate_matrispace_graph rejects malformed graphs", {
  skip_if_not_implemented("build_spatial_graph", "get_matrispace_graph",
                          ".validate_matrispace_graph")
  skip_if_not_installed("SpatialExperiment")
  u <- tf_universe(n_images = 2)
  g <- get_matrispace_graph(build_spatial_graph(tf_container("spe", u),
       method = "knn", k = 4, graph_name = "g"), "g")
  validate <- mfn(".validate_matrispace_graph")

  bad_len <- g; bad_len$image_ids <- g$image_ids[-1]
  expect_error(validate(bad_len), regexp = "length")

  bad_names <- g; bad_names$spot_ids <- rev(g$spot_ids)
  expect_error(validate(bad_names), regexp = "dimnames|spot_ids")

  bad_diag <- g
  Matrix::diag(bad_diag$connectivities) <- 1
  expect_error(validate(bad_diag), regexp = "diagonal|pattern")

  bad_dir <- g; bad_dir$directed <- TRUE   # but symmetrize is "union"
  expect_error(validate(bad_dir), regexp = "symmetrize|directed")

  bad_rep <- g; bad_rep$replicate_ids[1] <- ""   # "" is not a valid missing marker
  expect_error(validate(bad_rep), regexp = "empty|replicate")
})

test_that("stored base connectivity is binary and non-binary values are rejected", {
  skip_if_not_implemented("build_spatial_graph", "get_matrispace_graph",
                          ".validate_matrispace_graph")
  skip_if_not_installed("SpatialExperiment")
  u <- tf_universe()
  g <- get_matrispace_graph(build_spatial_graph(tf_container("spe", u),
       method = "knn", k = 4, graph_name = "g"), "g")
  # A real base graph carries only 1s (spatial statistics trust these values).
  expect_true(all(g$connectivities@x == 1))

  bad <- g; bad$connectivities@x[1] <- 2
  expect_error(mfn(".validate_matrispace_graph")(bad), regexp = "binary|connectivity")
})

test_that("an isolated spot is retained with zero degree while others connect", {
  skip_if_not_implemented("build_spatial_graph", "get_matrispace_graph")
  skip_if_not_installed("SpatialExperiment")
  # One far outlier + a tight unit-spaced cluster; radius 2 connects the
  # cluster and strands the outlier.
  u <- tf_universe_with_outlier(n_spots = 12)
  g <- get_matrispace_graph(build_spatial_graph(tf_container("spe", u),
       method = "radius", radius = 2, graph_name = "g"), "g")

  W <- g$connectivities
  deg <- Matrix::rowSums(W != 0)
  # Isolated node is present (not dropped) and genuinely has no neighbours...
  expect_equal(nrow(W), length(u$spots))
  expect_equal(unname(deg[u$outlier]), 0)
  # ...while the clustered spots are connected.
  expect_gt(max(deg), 0)
})

test_that("a graph is invalidated after the host object is subset", {
  skip_if_not_implemented("build_spatial_graph", "get_matrispace_graph",
                          ".validate_graph_against")
  skip_if_not_installed("SpatialExperiment")
  u <- tf_universe()
  obj <- build_spatial_graph(tf_container("spe", u), method = "knn", k = 4,
                             graph_name = "g")
  g <- get_matrispace_graph(obj, "g")
  # Dropping spots changes the spot set the graph was built for; a consumer
  # must reject the now-stale graph rather than silently misalign.
  sub <- obj[, u$spots[1:12]]
  expect_error(mfn(".validate_graph_against")(g, sub),
               regexp = "spot|dimension|mismatch|fingerprint")
})
