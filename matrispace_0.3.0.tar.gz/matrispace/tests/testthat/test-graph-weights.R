# Weight-transform helper (arch doc s2.2). Raw edge distances and base
# connectivity are stored; standardisation / inverse-distance / Gaussian
# weighting is a shared transform so each analysis can state exactly which
# weights it used. Transforms preserve sparsity and the zero pattern.

toy_W <- function() tf_toy_graph()$connectivities
# Distances that DIFFER between edges, so a transform that ignores its distance
# argument is detectable. Path 1-2-3-4: edge (1,2)=1, (2,3)=2, (3,4)=4.
toy_D <- function() {
  spots <- tf_toy_graph()$spot_ids
  D <- matrix(0, 4, 4, dimnames = list(spots, spots))
  D[1, 2] <- D[2, 1] <- 1
  D[2, 3] <- D[3, 2] <- 2
  D[3, 4] <- D[4, 3] <- 4
  Matrix::Matrix(D, sparse = TRUE)
}

test_that("binary transform is 0/1 on the existing edge pattern", {
  skip_if_not_implemented("transform_weights")
  W <- transform_weights(toy_W(), method = "binary")
  expect_true(all(W@x %in% c(1)))
  expect_true(is(W, "sparseMatrix"))
})

test_that("row-standardised weights sum to 1 per non-isolated row", {
  skip_if_not_implemented("transform_weights")
  W <- transform_weights(toy_W(), method = "row_standardize")
  rs <- Matrix::rowSums(W)
  expect_equal(unname(rs), rep(1, nrow(W)), tolerance = TOL)
})

test_that("inverse-distance weighting is strictly monotone in distance", {
  skip_if_not_implemented("transform_weights")
  W <- transform_weights(toy_W(), distances = toy_D(), method = "inverse_distance")
  expect_true(all(W@x > 0))
  expect_equal(as.matrix(W != 0), as.matrix(toy_W() != 0))
  # The nearer edge (d=1) must weigh more than the farther edge (d=4); a
  # transform that ignores `distances` cannot satisfy this.
  Wd <- as.matrix(W)
  expect_gt(Wd["spot001", "spot002"], Wd["spot003", "spot004"])
})

test_that("gaussian kernel weighting is monotone and sparsity-preserving", {
  skip_if_not_implemented("transform_weights")
  W <- transform_weights(toy_W(), distances = toy_D(), method = "gaussian",
                         sigma = 1)
  expect_true(all(W@x > 0))
  expect_equal(Matrix::nnzero(W), Matrix::nnzero(toy_W()))
  Wd <- as.matrix(W)
  expect_gt(Wd["spot001", "spot002"], Wd["spot003", "spot004"])
})

test_that("distance-based transforms reject invalid arguments", {
  skip_if_not_implemented("transform_weights")
  # gaussian without sigma; inverse_distance on a zero-distance edge.
  expect_error(transform_weights(toy_W(), distances = toy_D(), method = "gaussian"))
  # Force an explicit zero distance on an existing edge (assigning 0 via [<- would
  # drop the sparse entry, so set the stored value directly).
  D0 <- toy_D(); D0@x[1] <- 0
  expect_error(transform_weights(toy_W(), distances = D0, method = "inverse_distance"))
})

test_that("distance transforms reject a distance matrix that doesn't match W", {
  skip_if_not_implemented("transform_weights")
  W <- toy_W()
  # A distance matrix with an EXTRA edge (different nonzero pattern).
  Dbad <- W
  Dbad[1, 3] <- Dbad[3, 1] <- 2
  expect_error(transform_weights(W, distances = Dbad, method = "inverse_distance"),
               regexp = "pattern|dimnames|dimension")
})

test_that("gaussian/inverse-distance reject invalid sigma and eps", {
  skip_if_not_implemented("transform_weights")
  expect_error(transform_weights(toy_W(), distances = toy_D(), method = "gaussian",
                                 sigma = -1), regexp = "sigma")
  expect_error(transform_weights(toy_W(), distances = toy_D(), method = "gaussian",
                                 sigma = c(1, 2)), regexp = "sigma")
  expect_error(transform_weights(toy_W(), distances = toy_D(),
                                 method = "inverse_distance", eps = -1),
               regexp = "eps")
})

test_that("gaussian preserves the edge pattern even under underflow", {
  skip_if_not_implemented("transform_weights")
  # A tiny sigma drives exp(-d^2/2sigma^2) toward zero; clamping keeps all edges.
  W <- transform_weights(toy_W(), distances = toy_D(), method = "gaussian",
                         sigma = 1e-3)
  expect_equal(Matrix::nnzero(W), Matrix::nnzero(toy_W()))
  expect_true(all(W@x > 0))
})

test_that("transforms never densify the matrix", {
  skip_if_not_implemented("transform_weights")
  for (m in c("binary", "row_standardize")) {
    W <- transform_weights(toy_W(), method = m)
    expect_true(is(W, "sparseMatrix"))
  }
})
