# ---------------------------------------------------------------------------
# Shared setup: tolerances, small utilities. Loaded before every test file.
# ---------------------------------------------------------------------------

# Numerical tolerance for cross-container / oracle comparisons.
TOL <- 1e-8
# Looser tolerance where two independent code paths (e.g. UCell on Seurat vs
# SPE) are expected to agree only up to implementation noise.
TOL_LOOSE <- 1e-4
# Seurat stores FOV/centroid coordinates in single precision, so coordinate
# round-trips through a Seurat container are only good to ~float32.
TOL_COORD <- 1e-3

# Deterministic base seed used by all factories unless overridden.
SEED <- 42L

# Deterministic string ordering, and contain the locale-change warnings some
# environments (e.g. LC_ALL=C.UTF-8) emit. Best-effort: harmless where the
# locale is already fixed, and never a hard failure.
suppressWarnings(try(Sys.setlocale("LC_COLLATE", "C"), silent = TRUE))

`%||%` <- function(a, b) if (is.null(a)) b else a

# Coerce a variety of coordinate carriers to a plain numeric matrix with the
# first two columns as x/y and rows named by spot id. Used by tests to compare
# whatever an accessor returns against the factory ground truth.
as_xy <- function(x) {
  x <- as.data.frame(x)
  cols <- if (all(c("x", "y") %in% names(x))) c("x", "y") else names(x)[1:2]
  m <- as.matrix(x[, cols, drop = FALSE])
  storage.mode(m) <- "double"
  m
}
