# Global spatial autocorrelation (arch doc s2.4, s2.6, s5.3). Kernels are
# self-implemented from cited formulas, sparse-aware, deterministic under a
# seed, and cross-checked against hand-calculated toy graphs (level-1 tests)
# and the spdep oracle (optional).

# ---- Level 1: pure numerical kernels vs hand-derived toy values -------------

test_that("Moran's I kernel matches the hand-derived toy value (1/3)", {
  skip_if_not_implemented(".morans_i")
  g <- tf_toy_graph()
  i <- mfn(".morans_i")(g$x, g$connectivities)
  expect_equal(as.numeric(i), g$expected_morans_i, tolerance = TOL)
})

test_that("Geary's C kernel matches the hand-derived toy value (0.3)", {
  skip_if_not_implemented(".gearys_c")
  g <- tf_toy_graph()
  cc <- mfn(".gearys_c")(g$x, g$connectivities)
  expect_equal(as.numeric(cc), g$expected_gearys_c, tolerance = TOL)
})

test_that("Moran's I kernel agrees with the independent test oracle", {
  skip_if_not_implemented(".morans_i")
  g <- tf_toy_graph()
  expect_equal(as.numeric(mfn(".morans_i")(g$x, g$connectivities)),
               ref_morans_i(g$x, g$connectivities), tolerance = TOL)
})

# ---- Optional: cross-check against spdep --------------------------------------

test_that("Moran's I matches spdep on the toy graph", {
  skip_if_not_implemented(".morans_i")
  skip_if_not_installed("spdep")
  g <- tf_toy_graph()
  lw <- spdep::mat2listw(as.matrix(g$connectivities), style = "B",
                         zero.policy = TRUE)
  ref <- spdep::moran(g$x, lw, n = length(g$x),
                      S0 = Matrix::nnzero(g$connectivities),
                      zero.policy = TRUE)$I
  expect_equal(as.numeric(mfn(".morans_i")(g$x, g$connectivities)), ref,
               tolerance = 1e-6)
})

# ---- Public API: provenance + reproducibility -------------------------------

PROV <- c("feature", "image_id", "morans_i", "p_value", "p_adjusted", "graph",
          "weight", "alternative", "n_perm", "seed")

test_that("compute_morans_i returns a table with full statistical provenance", {
  skip_if_not_implemented("build_spatial_graph", "compute_morans_i")
  skip_if_not_installed("SpatialExperiment")
  u <- tf_universe()  # single image -> one row per feature
  obj <- build_spatial_graph(tf_container("spe", u), method = "knn", k = 4,
                             graph_name = "g")

  res <- compute_morans_i(obj, features = u$genes[1:3], graph = "g",
                          n_perm = 49, seed = 1)
  expect_s3_class(res, "data.frame")
  expect_true(all(PROV %in% colnames(res)))
  expect_equal(nrow(res), 3)
  expect_true(all(res$p_value >= 0 & res$p_value <= 1))
  expect_true(all(res$graph == "g"))
})

test_that("global autocorrelation is reported per image", {
  skip_if_not_implemented("build_spatial_graph", "compute_morans_i")
  skip_if_not_installed("SpatialExperiment")
  u <- tf_universe(n_spots = 24, n_images = 2)
  obj <- build_spatial_graph(tf_container("spe", u), method = "knn", k = 4,
                             graph_name = "g")
  res <- compute_morans_i(obj, features = u$genes[1:3], graph = "g",
                          n_perm = 49, seed = 1)
  # One row per feature x image (3 features x 2 images).
  expect_equal(nrow(res), 6)
  expect_setequal(unique(res$image_id), u$images)
})

test_that("spatial statistics reject a directed graph", {
  skip_if_not_implemented("build_spatial_graph", "compute_morans_i")
  skip_if_not_installed("SpatialExperiment")
  obj <- build_spatial_graph(tf_container("spe"), method = "knn", k = 4,
                             graph_name = "d", directed = TRUE)
  expect_error(compute_morans_i(obj, features = tf_universe()$genes[1],
                                graph = "d"), regexp = "directed|undirected")
})

test_that("permutation inference is reproducible under a fixed seed", {
  skip_if_not_implemented("build_spatial_graph", "compute_morans_i")
  skip_if_not_installed("SpatialExperiment")
  u <- tf_universe()
  obj <- build_spatial_graph(tf_container("spe", u), method = "knn", k = 4,
                             graph_name = "g")
  a <- compute_morans_i(obj, features = u$genes[1:3], graph = "g", n_perm = 49, seed = 7)
  b <- compute_morans_i(obj, features = u$genes[1:3], graph = "g", n_perm = 49, seed = 7)
  expect_equal(a$p_value, b$p_value)
  expect_equal(a$morans_i, b$morans_i)
})

test_that("a missing / unknown graph name is a hard error, never a silent guess", {
  skip_if_not_implemented("build_spatial_graph", "compute_morans_i")
  skip_if_not_installed("SpatialExperiment")
  obj <- build_spatial_graph(tf_container("spe"), method = "knn", k = 4,
                             graph_name = "g")
  expect_error(compute_morans_i(obj, features = tf_universe()$genes[1],
                                graph = "does_not_exist"))
})

test_that("a constant feature yields NA rather than a crash", {
  skip_if_not_implemented("build_spatial_graph", "compute_morans_i")
  skip_if_not_installed("SpatialExperiment")
  u <- tf_universe()
  const_gene <- "ConstGene"
  # Zero BOTH layers: the SPE expression accessor reads `logcounts`, so renaming
  # it alone would leave a variable feature and defeat the test.
  u$counts[1, ] <- 0
  u$logcounts[1, ] <- 0
  rownames(u$counts)[1] <- const_gene
  rownames(u$logcounts)[1] <- const_gene
  u$genes[1] <- const_gene
  obj <- build_spatial_graph(tf_container("spe", u), method = "knn", k = 4,
                             graph_name = "g")
  res <- compute_morans_i(obj, features = const_gene, graph = "g", n_perm = 19, seed = 1)
  expect_true(is.na(res$morans_i))
})

test_that("compute_gearys_c returns a provenance table and is reproducible", {
  skip_if_not_implemented("build_spatial_graph", "compute_gearys_c")
  skip_if_not_installed("SpatialExperiment")
  u <- tf_universe()
  obj <- build_spatial_graph(tf_container("spe", u), method = "knn", k = 4,
                             graph_name = "g")
  gc_cols <- c("feature", "gearys_c", "p_value", "p_adjusted", "graph",
               "weight", "alternative", "n_perm", "seed")
  a <- compute_gearys_c(obj, features = u$genes[1:3], graph = "g", n_perm = 49, seed = 5)
  b <- compute_gearys_c(obj, features = u$genes[1:3], graph = "g", n_perm = 49, seed = 5)
  expect_s3_class(a, "data.frame")
  expect_true(all(gc_cols %in% colnames(a)))
  expect_true(all(a$p_value >= 0 & a$p_value <= 1))
  expect_equal(a$gearys_c, b$gearys_c)
  expect_equal(a$p_value, b$p_value)
})

test_that("missing values omit spots and yield the exact induced-subgraph statistic", {
  skip_if_not_implemented("build_spatial_graph", "compute_morans_i", ".morans_i")
  skip_if_not_installed("SpatialExperiment")
  u <- tf_universe()  # single image
  dense <- as.matrix(u$logcounts)
  na_gene <- u$genes[2]
  dense[na_gene, u$spots[1:3]] <- NA_real_
  u$logcounts <- Matrix::Matrix(dense, sparse = TRUE)
  obj <- build_spatial_graph(tf_container("spe", u), method = "knn", k = 4,
                             graph_name = "g")
  res <- compute_morans_i(obj, features = na_gene, graph = "g",
                          assay = "logcounts", layer = NULL,
                          na_action = "omit", n_perm = 19, seed = 1)

  # Reconstruct the exact expected statistic on the induced subgraph.
  g <- get_matrispace_graph(obj, "g"); sid <- g$spot_ids
  x <- as.numeric(SummarizedExperiment::assay(obj, "logcounts")[na_gene, sid])
  keep <- which(is.finite(x))
  Wt <- transform_weights(g$connectivities[keep, keep, drop = FALSE],
                          method = "row_standardize")
  manual <- mfn(".morans_i")(x[keep], Wt)

  expect_equal(res$morans_i, manual, tolerance = TOL)
  expect_equal(res$n_spots_used, length(keep))
  expect_lt(res$n_spots_used, length(u$spots))
})

test_that("Geary's C kernel agrees with the independent oracle", {
  skip_if_not_implemented(".gearys_c")
  g <- tf_toy_graph()
  expect_equal(as.numeric(mfn(".gearys_c")(g$x, g$connectivities)),
               ref_gearys_c(g$x, g$connectivities), tolerance = TOL)
})

test_that("Geary's C matches spdep on the toy graph", {
  skip_if_not_implemented(".gearys_c")
  skip_if_not_installed("spdep")
  g <- tf_toy_graph()
  lw <- spdep::mat2listw(as.matrix(g$connectivities), style = "B", zero.policy = TRUE)
  ref <- spdep::geary(g$x, lw, n = length(g$x), n1 = length(g$x) - 1,
                      S0 = Matrix::nnzero(g$connectivities), zero.policy = TRUE)$C
  expect_equal(as.numeric(mfn(".gearys_c")(g$x, g$connectivities)), ref,
               tolerance = 1e-6)
})

test_that(".perm_pvalue computes exact permutation tails", {
  skip_if_not_implemented(".perm_pvalue")
  null <- 1:9  # 9 permutations
  # greater: #{>= 8} = {8,9} -> (2+1)/10 = 0.3
  expect_equal(mfn(".perm_pvalue")(8, null, "greater"), 0.3)
  # less: #{<= 8} = 8 -> (8+1)/10 = 0.9
  expect_equal(mfn(".perm_pvalue")(8, null, "less"), 0.9)
  # two.sided: min(1, 2 * min(0.3, 0.9)) = 0.6
  expect_equal(mfn(".perm_pvalue")(8, null, "two.sided"), 0.6)
})

test_that(".with_seed restores the caller's RNG state (present and absent)", {
  skip_if_not_implemented(".with_seed")
  # Restore this test process's incoming RNG state afterwards, so intentionally
  # removing .Random.seed below does not leak into other tests.
  had <- exists(".Random.seed", envir = globalenv())
  incoming <- if (had) get(".Random.seed", envir = globalenv()) else NULL
  withr::defer({
    if (had) assign(".Random.seed", incoming, envir = globalenv())
    else if (exists(".Random.seed", envir = globalenv()))
      rm(".Random.seed", envir = globalenv())
  })

  set.seed(123)
  before <- get(".Random.seed", envir = globalenv())
  r1 <- mfn(".with_seed")(1, runif(3))
  after <- get(".Random.seed", envir = globalenv())
  expect_identical(before, after)                     # stream restored
  r2 <- mfn(".with_seed")(1, runif(3))
  expect_equal(r1, r2)                                # reproducible under seed
  # Absence of .Random.seed is also restored.
  rm(".Random.seed", envir = globalenv())
  invisible(mfn(".with_seed")(1, runif(1)))
  expect_false(exists(".Random.seed", envir = globalenv()))
})

test_that("p_adjusted is BH computed separately within each image", {
  skip_if_not_implemented("build_spatial_graph", "compute_morans_i")
  skip_if_not_installed("SpatialExperiment")
  u <- tf_universe(n_spots = 24, n_images = 2)
  obj <- build_spatial_graph(tf_container("spe", u), method = "knn", k = 4,
                             graph_name = "g")
  res <- compute_morans_i(obj, features = u$genes[1:4], graph = "g",
                          n_perm = 49, seed = 1)
  for (im in u$images) {
    sub <- res[res$image_id == im, ]
    expect_equal(sub$p_adjusted, stats::p.adjust(sub$p_value, "BH"))
  }
})

test_that("compute_morans_i validates arguments before touching data", {
  skip_if_not_implemented("build_spatial_graph", "compute_morans_i")
  skip_if_not_installed("SpatialExperiment")
  obj <- build_spatial_graph(tf_container("spe"), method = "knn", k = 4, graph_name = "g")
  f <- tf_universe()$genes[1]
  expect_error(compute_morans_i(obj, features = character(0), graph = "g"), "features")
  expect_error(compute_morans_i(obj, features = c(f, f), graph = "g"), "unique")
  expect_error(compute_morans_i(obj, features = f, graph = "g", n_perm = 0), "n_perm")
  expect_error(compute_morans_i(obj, features = f, graph = "g", na_action = "drop"),
               "na_action")
  expect_error(compute_morans_i(obj, features = f, graph = "g", weight = "bogus"),
               "weight")
  expect_error(compute_morans_i(obj, features = f, graph = "g", weight = "gaussian"),
               "sigma")
  # Irrelevant weight parameters are rejected, not silently recorded.
  expect_error(compute_morans_i(obj, features = f, graph = "g", weight = "binary",
                                sigma = 1), "sigma")
  expect_error(compute_morans_i(obj, features = f, graph = "g", weight = "gaussian",
                                sigma = 1, eps = 1), "eps")
  # Seed must be a whole number within the integer range.
  expect_error(compute_morans_i(obj, features = f, graph = "g", seed = 1.5), "seed")
  expect_error(compute_morans_i(obj, features = f, graph = "g", seed = 2^31), "seed")
})

test_that("configurable gaussian weight is forwarded and recorded", {
  skip_if_not_implemented("build_spatial_graph", "compute_morans_i")
  skip_if_not_installed("SpatialExperiment")
  u <- tf_universe()
  obj <- build_spatial_graph(tf_container("spe", u), method = "knn", k = 4,
                             graph_name = "g")
  res <- compute_morans_i(obj, features = u$genes[1:2], graph = "g",
                          weight = "gaussian", sigma = 10, n_perm = 19, seed = 1)
  expect_true(all(res$weight == "gaussian"))
  expect_true(all(res$sigma == 10))
  expect_true(all(res$p_value >= 0 & res$p_value <= 1))
})

test_that("a one-spot image reports NA statistic and NA expectation", {
  skip_if_not_implemented("build_spatial_graph", "compute_morans_i")
  skip_if_not_installed("SpatialExperiment")
  coords <- cbind(x = c(0, 1, 2, 50), y = c(0, 0, 0, 50))
  rownames(coords) <- paste0("s", 1:4)
  spe <- tf_spe_from_coords(coords, image_ids = c("i1", "i1", "i1", "i2"))
  obj <- build_spatial_graph(spe, method = "knn", k = 2, graph_name = "g")
  res <- compute_morans_i(obj, features = "g1", graph = "g", n_perm = 19, seed = 1)
  r2 <- res[res$image_id == "i2", ]
  expect_true(is.na(r2$morans_i))
  expect_true(is.na(r2$expected))
})

test_that("an all-isolated image yields an NA statistic", {
  skip_if_not_implemented("build_spatial_graph", "compute_morans_i")
  skip_if_not_installed("SpatialExperiment")
  u <- tf_universe(n_spots = 9, n_images = 1)
  # radius below the grid spacing (10) leaves every spot isolated.
  obj <- build_spatial_graph(tf_container("spe", u), method = "radius",
                             radius = 1, graph_name = "g")
  res <- compute_morans_i(obj, features = u$genes[1], graph = "g", n_perm = 19, seed = 1)
  expect_true(is.na(res$morans_i))
})

test_that("non-finite expression values are omitted like NA", {
  skip_if_not_implemented("build_spatial_graph", "compute_morans_i")
  skip_if_not_installed("SpatialExperiment")
  u <- tf_universe()
  dense <- as.matrix(u$logcounts); g2 <- u$genes[2]
  dense[g2, u$spots[1:2]] <- Inf
  u$logcounts <- Matrix::Matrix(dense, sparse = TRUE)
  obj <- build_spatial_graph(tf_container("spe", u), method = "knn", k = 4,
                             graph_name = "g")
  res <- compute_morans_i(obj, features = g2, graph = "g", assay = "logcounts",
                          layer = NULL, n_perm = 19, seed = 1)
  expect_true(is.finite(res$morans_i))
  expect_equal(res$n_spots_used, length(u$spots) - 2L)
})
