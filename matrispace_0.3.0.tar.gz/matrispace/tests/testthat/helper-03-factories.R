# ---------------------------------------------------------------------------
# Programmatic test factories (arch doc s2.6, SPEC s1.1). Deterministic,
# kilobyte-scale, self-contained (Seurat / SpatialExperiment only, never
# matrispace).
#
# Identity model (SPEC s1.1): `image_id` is the coordinate frame / library
# (Seurat FOV, SPE reserved colData$sample_id); `replicate_id` is the biological
# replicate (a non-reserved metadata column). Each image uses its OWN local
# coordinate frame starting at the origin, so frames OVERLAP across images --
# the realistic multi-FOV pattern. image_id, not coordinates, separates them.
# ---------------------------------------------------------------------------

tf_universe <- function(n_genes = 30, n_spots = 24, n_images = 1L,
                        n_replicates = n_images, genes = NULL, seed = SEED) {
  withr::with_seed(seed, {
    genes <- genes %||% sprintf("Gene%02d", seq_len(n_genes))
    spots <- sprintf("spot%03d", seq_len(n_spots))
    image_ids <- rep(sprintf("image%d", seq_len(n_images)), length.out = n_spots)
    # Map images to replicates. Default (n_replicates == n_images) is one
    # replicate per image; n_replicates < n_images makes several images share a
    # replicate (serial sections of one biological sample).
    uimg <- sprintf("image%d", seq_len(n_images))
    img_to_rep <- setNames(
      sprintf("rep%d", rep(seq_len(n_replicates), length.out = n_images)), uimg)
    replicate_ids <- unname(img_to_rep[image_ids])

    counts <- Matrix::Matrix(
      matrix(stats::rpois(n_genes * n_spots, lambda = 3), nrow = n_genes,
             dimnames = list(genes, spots)), sparse = TRUE)
    logcounts <- counts
    logcounts@x <- log1p(logcounts@x)

    # Per-image LOCAL frame from the origin (overlapping across images).
    coords <- matrix(0, nrow = n_spots, ncol = 2,
                     dimnames = list(spots, c("x", "y")))
    for (im in unique(image_ids)) {
      idx <- which(image_ids == im)
      side <- ceiling(sqrt(length(idx)))
      gx <- (seq_along(idx) - 1) %% side
      gy <- (seq_along(idx) - 1) %/% side
      coords[idx, "x"] <- gx * 10 + stats::runif(length(idx), -0.1, 0.1)
      coords[idx, "y"] <- gy * 10 + stats::runif(length(idx), -0.1, 0.1)
    }

    metadata <- data.frame(
      replicate_id = replicate_ids,
      group        = rep(c("A", "B"), length.out = n_spots),
      total_counts = Matrix::colSums(counts),
      row.names = spots, stringsAsFactors = FALSE
    )

    list(
      genes = genes, spots = spots,
      images = unique(image_ids), image_ids = image_ids,
      replicates = unique(replicate_ids), replicate_ids = replicate_ids,
      counts = counts, logcounts = logcounts, coords = coords,
      metadata = metadata
    )
  })
}

# Seurat container: counts + a known `data` layer, ONE FOV per image_id (each in
# its own local frame), biological metadata. Defaults to the "Spatial" assay.
tf_seurat <- function(truth = tf_universe(), assay = "Spatial") {
  obj <- SeuratObject::CreateSeuratObject(
    counts = truth$counts, meta.data = truth$metadata, assay = assay
  )
  SeuratObject::LayerData(obj, layer = "data", assay = assay) <- truth$logcounts

  for (im in truth$images) {
    idx <- truth$image_ids == im
    cc <- truth$coords[idx, , drop = FALSE]
    cents <- SeuratObject::CreateCentroids(
      data.frame(x = cc[, "x"], y = cc[, "y"], cell = rownames(cc)))
    fov <- SeuratObject::CreateFOV(cents, type = "centroids", assay = assay,
                                   key = paste0(im, "_"))
    obj[[im]] <- fov
  }
  attr(obj, "truth") <- truth
  obj
}

# SpatialExperiment container: SPE's reserved sample_id IS the library/image;
# biological replicate lives in a non-reserved colData column.
tf_spe <- function(truth = tf_universe()) {
  spe <- SpatialExperiment::SpatialExperiment(
    assays = list(counts = truth$counts, logcounts = truth$logcounts),
    spatialCoords = truth$coords,
    colData = S4Vectors::DataFrame(truth$metadata),
    sample_id = truth$image_ids
  )
  attr(spe, "truth") <- truth
  spe
}

tf_container <- function(type, truth = tf_universe()) {
  switch(type,
    seurat = tf_seurat(truth),
    spe = tf_spe(truth),
    stop("unknown container type: ", type))
}

tf_available_containers <- function() {
  ct <- c()
  if (requireNamespace("SeuratObject", quietly = TRUE) &&
      requireNamespace("Seurat", quietly = TRUE)) ct <- c(ct, "seurat")
  if (requireNamespace("SpatialExperiment", quietly = TRUE)) ct <- c(ct, "spe")
  ct
}

# Container-native handles for the SAME logical data (SPEC s4). Seurat uses
# (assay, layer); SPE uses assayNames and ignores `layer`.
tf_expr_args <- function(ct, assay = "Spatial") {
  switch(ct,
    seurat = list(assay = assay, layer = "data"),
    spe    = list(assay = "logcounts", layer = NULL),
    stop("unknown container type: ", ct))
}
tf_counts_args <- function(ct, assay = "Spatial") {
  switch(ct,
    seurat = list(assay = assay),
    spe    = list(assay = "counts"),
    stop("unknown container type: ", ct))
}

# A single-image universe with one deliberate spatial outlier: spot 1 sits far
# from a tight unit-spaced cluster, so a moderate radius strands it.
tf_universe_with_outlier <- function(n_spots = 12, seed = SEED) {
  withr::with_seed(seed, {
    genes <- sprintf("Gene%02d", seq_len(8))
    spots <- sprintf("spot%03d", seq_len(n_spots))
    counts <- Matrix::Matrix(
      matrix(stats::rpois(length(genes) * n_spots, 3), nrow = length(genes),
             dimnames = list(genes, spots)), sparse = TRUE)
    logcounts <- counts; logcounts@x <- log1p(logcounts@x)
    coords <- cbind(
      x = c(1000, ((seq_len(n_spots - 1) - 1) %% 3)),
      y = c(1000, ((seq_len(n_spots - 1) - 1) %/% 3)))
    rownames(coords) <- spots
    metadata <- data.frame(replicate_id = rep("rep1", n_spots),
                           group = rep("A", n_spots),
                           row.names = spots, stringsAsFactors = FALSE)
    list(genes = genes, spots = spots, images = "image1",
         image_ids = rep("image1", n_spots), replicates = "rep1",
         replicate_ids = rep("rep1", n_spots), counts = counts,
         logcounts = logcounts, coords = coords, metadata = metadata,
         outlier = spots[1])
  })
}

# A single-image universe engineered for EXACT KNN distance ties: a centre spot
# equidistant (distance 1) from four neighbours. Used to prove reorder-safe
# tie-breaking (ties resolved by spot_id, not input position).
tf_universe_with_ties <- function(seed = SEED) {
  withr::with_seed(seed, {
    genes <- sprintf("Gene%02d", seq_len(8))
    spots <- sprintf("spot%03d", 1:5)
    counts <- Matrix::Matrix(
      matrix(stats::rpois(length(genes) * 5, 3), nrow = length(genes),
             dimnames = list(genes, spots)), sparse = TRUE)
    logcounts <- counts; logcounts@x <- log1p(logcounts@x)
    coords <- rbind(c(0, 0), c(1, 0), c(-1, 0), c(0, 1), c(0, -1))
    colnames(coords) <- c("x", "y"); rownames(coords) <- spots
    metadata <- data.frame(replicate_id = rep("rep1", 5),
                           group = rep(c("A", "B"), length.out = 5),
                           row.names = spots, stringsAsFactors = FALSE)
    list(genes = genes, spots = spots, images = "image1",
         image_ids = rep("image1", 5), replicates = "rep1",
         replicate_ids = rep("rep1", 5), counts = counts, logcounts = logcounts,
         coords = coords, metadata = metadata, centre = spots[1])
  })
}

# Minimal single- or multi-image SPE built from explicit coordinates, with
# varied (non-constant) counts and a matching logcounts layer.
tf_spe_from_coords <- function(coords, image_ids = rep("img", nrow(coords)),
                               replicate_ids = rep("r", nrow(coords))) {
  spots <- rownames(coords)
  ng <- 3L
  counts <- Matrix::Matrix(
    matrix(seq_len(ng * length(spots)) %% 7 + 1, nrow = ng,
           dimnames = list(paste0("g", seq_len(ng)), spots)), sparse = TRUE)
  logcounts <- counts; logcounts@x <- log1p(logcounts@x)
  SpatialExperiment::SpatialExperiment(
    assays = list(counts = counts, logcounts = logcounts),
    spatialCoords = coords,
    colData = S4Vectors::DataFrame(replicate_id = replicate_ids, row.names = spots),
    sample_id = image_ids)
}

# ---- Self-contained reference biology (NOT the old package's data) ----------

tf_signatures <- function(genes = tf_universe()$genes) {
  list(
    signatures = list(
      collagens        = genes[1:5],
      glycoproteins    = genes[6:10],
      proteoglycans    = genes[11:14]
    ),
    labels = c(collagens = "Collagens",
               glycoproteins = "ECM Glycoproteins",
               proteoglycans = "Proteoglycans")
  )
}

tf_markers <- function(genes = tf_universe()$genes) {
  list(
    interstitial = list(positive = genes[1:4],  negative = genes[20:22]),
    basement     = list(positive = genes[5:8],  negative = genes[23:25]),
    vascular     = list(positive = genes[9:12], negative = genes[26:28])
  )
}

tf_lr_pairs <- function(genes = tf_universe()$genes) {
  data.frame(
    gene_1 = genes[c(1, 2, 3, 4, 5)],
    gene_2 = genes[c(10, 11, 12, 13, 14)],
    stringsAsFactors = FALSE
  )
}

# ---- Hand-written statistical oracles ---------------------------------------

ref_morans_i <- function(x, W, row_standardized = FALSE) {
  W <- as.matrix(W)
  if (row_standardized) {
    rs <- rowSums(W); rs[rs == 0] <- 1
    W <- W / rs
  }
  n <- length(x)
  z <- x - mean(x)
  S0 <- sum(W)
  (n / S0) * (as.numeric(t(z) %*% W %*% z) / sum(z^2))
}

ref_gearys_c <- function(x, W) {
  W <- as.matrix(W)
  n <- length(x)
  z <- x - mean(x)
  S0 <- sum(W)
  num <- sum(W * outer(x, x, function(a, b) (a - b)^2))
  ((n - 1) / (2 * S0)) * (num / sum(z^2))
}

# Tiny hand-checkable graph: 4-node path 1-2-3-4 (binary, symmetric), x = 1:4.
# Moran's I = 1/3, Geary's C = 0.3 (derived by hand).
tf_toy_graph <- function() {
  spots <- sprintf("spot%03d", 1:4)
  W <- matrix(0, 4, 4, dimnames = list(spots, spots))
  W[1, 2] <- W[2, 1] <- 1
  W[2, 3] <- W[3, 2] <- 1
  W[3, 4] <- W[4, 3] <- 1
  x <- c(1, 2, 3, 4)
  names(x) <- spots
  coords <- cbind(x = c(0, 1, 2, 3), y = c(0, 0, 0, 0))
  rownames(coords) <- spots
  list(
    spot_ids = spots,
    connectivities = Matrix::Matrix(W, sparse = TRUE),
    coords = coords,
    x = x,
    expected_morans_i = 1 / 3,
    expected_gearys_c = 0.3
  )
}
