library(testthat)
library(matrispace)

test_check("matrispace")
